// Synaptix CRM - Auth Middleware
// middleware.js

const jwt = require('jsonwebtoken');
const db = require('./db');

// This middleware function protects routes by verifying the JWT.
const protect = async (req, res, next) => {
    let token;
    
    // Check for token in the Authorization header
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            // Get token from header (e.g., "Bearer eyJhbGci...")
            token = req.headers.authorization.split(' ')[1];

            // Verify the token using the secret key
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            // Fetch the user from the database using the ID from the token
            // This ensures the user still exists and attaches their info to the request object
            const { rows } = await db.query(
                'SELECT id, name, email, role, company_id FROM users WHERE id = $1',
                [decoded.id]
            );

            if (rows.length > 0) {
                req.user = rows[0]; // Attach user data to the request object
                next(); // Proceed to the next middleware or route handler
            } else {
                res.status(401).json({ message: 'Not authorized, user not found' });
            }
        } catch (error) {
            console.error(error);
            res.status(401).json({ message: 'Not authorized, token failed' });
        }
    }

    if (!token) {
        res.status(401).json({ message: 'Not authorized, no token' });
    }
};

module.exports = { protect };
