const express = require('express');
const cors = require('cors');
const path = require('path');
const authRoutes = require('./auth');
const apiRoutes = require('./api');
const { protect } = require('./middleware');

const app = express();
const PORT = process.env.PORT || 3001;

// --- Middleware ---
// Enable Cross-Origin Resource Sharing for the React frontend
app.use(cors());
// Parse incoming JSON requests
app.use(express.json());

// --- API Routes ---
// Mount authentication routes (e.g., /auth/register, /auth/login)
app.use('/auth', authRoutes);
// Mount protected API routes (e.g., /api/clients, /api/tasks)
// The 'protect' middleware ensures only authenticated users can access these routes.
app.use('/api', protect, apiRoutes);


// --- Serve Frontend for Production ---
// In a production environment, the Express server will also serve the built React app.
if (process.env.NODE_ENV === 'production') {
  // Serve static files from the React build directory
  app.use(express.static(path.join(__dirname, 'client/build')));

  // For any request that doesn't match an API route, send back the React app's index.html file.
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'client/build', 'index.html'));
  });
}

// --- Start Server ---
app.listen(PORT, () => {
  console.log(`Synaptix API server running on port ${PORT}`);
});
