// Synaptix CRM - Authentication Routes
// auth.js

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./db'); // Database connection pool

const router = express.Router();

// --- Helper function to generate JWT ---
const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '30d', // Token will be valid for 30 days
    });
};

// --- Route for New Company/User Registration ---
// POST /auth/register
router.post('/register', async (req, res) => {
    const { companyName, name, email, password } = req.body;

    // Basic validation
    if (!companyName || !name || !email || !password) {
        return res.status(400).json({ message: 'Please provide all required fields.' });
    }

    const client = await db.connect();
    try {
        await client.query('BEGIN'); // Start transaction

        // 1. Create the new company (tenant)
        const companyResult = await client.query(
            'INSERT INTO companies (name) VALUES ($1) RETURNING id',
            [companyName]
        );
        const companyId = companyResult.rows[0].id;

        // 2. Hash the user's password
        const salt = await bcrypt.genSalt(10);
        const passwordHash = await bcrypt.hash(password, salt);

        // 3. Create the new user and associate them with the new company
        const userResult = await client.query(
            'INSERT INTO users (company_id, name, email, password_hash, role) VALUES ($1, $2, $3, $4, $5) RETURNING id, name, email, role, company_id',
            [companyId, name, email, passwordHash, 'Admin'] // The first user is always an Admin
        );
        
        await client.query('COMMIT'); // Commit transaction

        const newUser = userResult.rows[0];
        
        // 4. Respond with user info and a new token
        res.status(201).json({
            ...newUser,
            token: generateToken(newUser.id),
        });

    } catch (error) {
        await client.query('ROLLBACK'); // Rollback transaction on error
        console.error('Registration error:', error);
        // Check for unique constraint violation (email already exists)
        if (error.code === '23505') {
            return res.status(400).json({ message: 'A user with this email already exists.' });
        }
        res.status(500).json({ message: 'Server error during registration.' });
    } finally {
        client.release(); // Release the client back to the pool
    }
});


// --- Route for User Login ---
// POST /auth/login
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: 'Please provide email and password.' });
    }

    try {
        // Find the user by email
        const { rows } = await db.query(
            'SELECT * FROM users WHERE email = $1',
            [email]
        );
        
        const user = rows[0];

        // If user exists and password is correct
        if (user && (await bcrypt.compare(password, user.password_hash))) {
            const userPayload = {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role,
                company_id: user.company_id,
                token: generateToken(user.id),
            };
            res.json(userPayload);
        } else {
            res.status(401).json({ message: 'Invalid credentials.' });
        }

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ message: 'Server error during login.' });
    }
});

module.exports = router;
