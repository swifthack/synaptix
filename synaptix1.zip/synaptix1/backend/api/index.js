
const express = require('express');
const db = require('../db'); // Your database connection pool
const router = express.Router();

// This file aggregates all API routes and exports them for use in server.js

// --- Client Routes ---
router.get('/clients', async (req, res) => {
    try {
        // req.user is attached by the 'protect' middleware and contains the authenticated user's info
        const { company_id } = req.user;
        const { rows } = await db.query(
            'SELECT * FROM clients WHERE company_id = $1 ORDER BY name', 
            [company_id]
        );
        res.json(rows);
    } catch (error) {
        console.error('Error fetching clients:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Add more routes for other resources (tasks, contacts, etc.) here...
// Example for tasks:
router.get('/tasks', async (req, res) => {
    try {
        const { company_id } = req.user;
        const { rows } = await db.query(
            'SELECT * FROM tasks WHERE company_id = $1 ORDER BY due_date',
            [company_id]
        );
        res.json(rows);
    } catch (error) {
        console.error('Error fetching tasks:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
