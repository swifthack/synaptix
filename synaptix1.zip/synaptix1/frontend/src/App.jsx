import { useState } from "react";
import LeftNavRail from "./components/LeftNavRail";
import AIAssistant from "./components/AIAssistant";

import DashboardView from "./views/DashboardView";
import ClientsView from "./views/ClientsView";
import Client360View from "./views/Client360View";
import TasksView from "./views/TasksView";
import LeadsView from "./views/LeadsView";
import ProspectsView from "./views/ProspectsView";
import CampaignsView from "./views/CampaignsView";
import MarketingEventsView from "./views/MarketingEventsView";
import SettingsView from "./views/SettingsView";

// If your data was refactored out, import it:
import {
  mockClients,
  mockLeads,
} from "./data/mockData";

export default function App() {
  const [clients, setClients] = useState(mockClients);
  const [leads, setLeads] = useState(mockLeads);
  const [currentView, setCurrentView] = useState("dashboard");
  const [selectedClientId, setSelectedClientId] = useState(null);
  const [activeClientTab, setActiveClientTab] = useState("overview");

  const [dealFormState, setDealFormState] = useState({
    dealName: "",
    dealValue: "",
    dealStatus: "Pending",
    dealCloseDate: new Date().toISOString().split("T")[0],
    editingDealId: null,
  });
  const [contactFormState, setContactFormState] = useState({
    contactName: "",
    contactRole: "",
    contactEmail: "",
    editingContactId: null,
  });
  const [meetingFormState, setMeetingFormState] = useState({
    meetingTitle: "",
    meetingNotes: "",
  });

  const handleViewClient = (clientId) => {
    setSelectedClientId(clientId);
    setCurrentView("client360");
    setActiveClientTab("overview");
  };

  const handleBackToClients = () => {
    setCurrentView("clients");
    setSelectedClientId(null);
  };

  const updateClientData = (clientId, updateFn) => {
    setClients((prev) =>
      prev.map((client) =>
        client.id === clientId ? updateFn(client) : client
      )
    );
  };

  const handleAddMeeting = (clientId, newMeeting) =>
    updateClientData(clientId, (client) => ({
      ...client,
      meetings: [newMeeting, ...(client.meetings || [])],
    }));

  const handleAddDeal = (clientId, newDeal) =>
    updateClientData(clientId, (client) => ({
      ...client,
      deals: [newDeal, ...(client.deals || [])],
    }));

  const handleAddContact = (clientId, newContact) =>
    updateClientData(clientId, (client) => ({
      ...client,
      contacts: [newContact, ...(client.contacts || [])],
    }));

  const handleUpdateDeal = (clientId, updatedDeal) =>
    updateClientData(clientId, (client) => ({
      ...client,
      deals: (client.deals || []).map((d) =>
        d.id === updatedDeal.id ? updatedDeal : d
      ),
    }));

  const handleUpdateContact = (clientId, updatedContact) =>
    updateClientData(clientId, (client) => ({
      ...client,
      contacts: (client.contacts || []).map((c) =>
        c.id === updatedContact.id ? updatedContact : c
      ),
    }));

  // Assistant → fill Deal form
  const handleParseDealFromAssistant = (parsedData) => {
    setDealFormState({
      dealName: parsedData.name || "",
      dealValue: parsedData.value || "",
      dealStatus: parsedData.status || "Pending",
      dealCloseDate: new Date().toISOString().split("T")[0],
      editingDealId: null,
    });
    setActiveClientTab("deals");
  };

  // Assistant → fill Contact form
  const handleParseContactFromAssistant = (parsedData) => {
    setContactFormState({
      contactName: parsedData.name || "",
      contactRole: parsedData.role || "",
      contactEmail: parsedData.email || "",
      editingContactId: null,
    });
    setActiveClientTab("contacts");
  };

  // Assistant → fill Meeting form (title = first sentence)
  const handleParseMeetingFromAssistant = (prompt) => {
    const firstSentenceEnd = prompt.indexOf(".");
    const title =
      firstSentenceEnd !== -1 ? prompt.substring(0, firstSentenceEnd) : prompt;
    const notes =
      firstSentenceEnd !== -1
        ? prompt.substring(firstSentenceEnd + 1).trim()
        : prompt;
    setMeetingFormState({ meetingTitle: title, meetingNotes: notes });
    setActiveClientTab("meetings");
  };

  const renderContent = () => {
    switch (currentView) {
      case "dashboard":
        return (
          <DashboardView
            clients={clients}
            onViewClient={handleViewClient}
            setCurrentView={setCurrentView}
          />
        );
      case "clients":
        return (
          <ClientsView clients={clients} onViewClient={handleViewClient} />
        );
      case "client360": {
        const client = clients.find((c) => c.id === selectedClientId);
        return (
          <Client360View
            client={client}
            onBack={handleBackToClients}
            onAddMeeting={handleAddMeeting}
            onAddDeal={handleAddDeal}
            onUpdateDeal={handleUpdateDeal}
            onAddContact={handleAddContact}
            onUpdateContact={handleUpdateContact}
            activeTab={activeClientTab}
            setActiveTab={setActiveClientTab}
            dealFormState={dealFormState}
            setDealFormState={setDealFormState}
            contactFormState={contactFormState}
            setContactFormState={setContactFormState}
            meetingFormState={meetingFormState}
            setMeetingFormState={setMeetingFormState}
          />
        );
      }
      case "tasks":
        return <TasksView />;
      case "leads":
        return <LeadsView leads={leads} />;
      case "prospects":
        return <ProspectsView />;
      case "campaigns":
        return <CampaignsView />;
      case "marketingEvents":
        return <MarketingEventsView />;
      case "settings":
        return <SettingsView />;
      default:
        return (
          <DashboardView
            clients={clients}
            onViewClient={handleViewClient}
            setCurrentView={setCurrentView}
          />
        );
    }
  };

  return (
    <div className="h-screen w-screen bg-white flex font-sans text-gray-900 overflow-hidden">
      <LeftNavRail
        currentView={currentView}
        setCurrentView={setCurrentView}
        currentUser={{ role: "RM" }} // keep your existing prop; change as needed
        onLogout={() => {}}
      />
      <main className="flex-1 bg-gray-100/50 overflow-y-auto">
        {renderContent()}
      </main>
      <AIAssistant
        onNavigate={handleViewClient}
        clients={clients}
        setCurrentView={setCurrentView}
        currentView={currentView}
        selectedClientId={selectedClientId}
        onParseDeal={handleParseDealFromAssistant}
        onParseContact={handleParseContactFromAssistant}
        onParseMeeting={handleParseMeetingFromAssistant}
        setActiveClientTab={setActiveClientTab}
      />
    </div>
  );
}
