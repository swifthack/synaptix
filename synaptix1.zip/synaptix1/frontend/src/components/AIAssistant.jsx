import { useState } from "react";
import BotIcon from "../icons/BotIcon";
import HomeIcon from "../icons/HomeIcon";
import ChevronRightIcon from "../icons/ChevronRightIcon";

export default function AIAssistant({
  onNavigate,
  clients,
  setCurrentView,
  currentView,
  selectedClientId,
  onParseDeal,
  onParseContact,
  onParseMeeting,
  setActiveClientTab,
}) {
  const [prompt, setPrompt] = useState("");
  const [message, setMessage] = useState("");

  const handlePromptSubmit = (e) => {
    e.preventDefault();
    const trimmedPrompt = prompt.trim();
    const lowerCasePrompt = trimmedPrompt.toLowerCase();
    if (!trimmedPrompt) return;

    const checkAndHandleAction = (
      regex,
      onParse,
      tabName,
      successMsg,
      failureMsg
    ) => {
      const match = trimmedPrompt.match(regex);
      // match[2] is the "info" part (post command)
      if (match && match[2]) {
        if (currentView === "client360" && selectedClientId) {
          onParse(match[2].trim());
          setMessage(successMsg);
          setActiveClientTab(tabName);
        } else {
          setMessage(failureMsg);
        }
        return true;
      }
      return false;
    };

    // DEALS: "create deal <info>" (name, value, status)
    if (
      checkAndHandleAction(
        /^(create|add|new)\s+deal\s+(.*)/i,
        (info) => {
          let name = "",
            value = "",
            status = "Pending";
          const valueMatch = info.match(
            /\$?(\d{1,3}(,\d{3})*(\.\d+)?|\d+(\.\d+)?)/
          );
          if (valueMatch)
            value = parseFloat(valueMatch[0].replace(/[^0-9.]/g, ""));
          const forMatch = info.match(
            /for\s+(.*?)(?:\s+worth|\s+valued|\s+valued\s+at|[$,]|$)/i
          );
          if (forMatch && forMatch[1])
            name = forMatch[1].trim().replace(/,$/, "");
          else
            name = info
              .split(",")[0]
              .split(" worth")[0]
              .split(" valued")[0]
              .trim();
          if (info.toLowerCase().includes("won")) status = "Won";
          if (info.toLowerCase().includes("lost")) status = "Lost";
          onParseDeal({ name, value, status });
        },
        "deals",
        "Deal form populated. Review and save.",
        "Go to a client's page to create a deal."
      )
    ) {
      setPrompt("");
      setTimeout(() => setMessage(""), 4000);
      return;
    }

    // CONTACTS: "create contact Jane Doe, CEO, jane@example.com"
    if (
      checkAndHandleAction(
        /^(create|add|new)\s+contact\s+(.*)/i,
        (info) => {
          const parts = info.split(",").map((p) => p.trim());
          const [name, role, email] = parts;
          onParseContact({ name, role, email });
        },
        "contacts",
        "Contact form populated. Review and save.",
        "Go to a client's page to create a contact."
      )
    ) {
      setPrompt("");
      setTimeout(() => setMessage(""), 4000);
      return;
    }

    // MEETINGS: "create meeting Title. Notes..."
    if (
      checkAndHandleAction(
        /^(create|add|new)\s+meeting\s+(.*)/i,
        (info) => {
          onParseMeeting(info);
        },
        "meetings",
        "Meeting form populated. Review and save.",
        "Go to a client's page to create a meeting."
      )
    ) {
      setPrompt("");
      setTimeout(() => setMessage(""), 4000);
      return;
    }

    // NAVIGATION / FIND CLIENT
    if (lowerCasePrompt.includes("dashboard") || lowerCasePrompt.includes("home")) {
      setMessage("Navigating to Dashboard...");
      setCurrentView("dashboard");
    } else if (lowerCasePrompt.includes("all clients") || lowerCasePrompt.includes("client list")) {
      setMessage("Showing all clients...");
      setCurrentView("clients");
    } else if (lowerCasePrompt.includes("tasks") || lowerCasePrompt.includes("my tasks")) {
      setMessage("Showing all tasks...");
      setCurrentView("tasks");
    } else if (lowerCasePrompt.includes("leads")) {
      setMessage("Showing all leads...");
      setCurrentView("leads");
    } else if (lowerCasePrompt.includes("prospects")) {
      setMessage("Showing all prospects...");
      setCurrentView("prospects");
    } else if (lowerCasePrompt.includes("campaigns")) {
      setMessage("Showing all campaigns...");
      setCurrentView("campaigns");
    } else if (lowerCasePrompt.includes("events") || lowerCasePrompt.includes("marketing")) {
      setMessage("Showing marketing events...");
      setCurrentView("marketingEvents");
    } else if (lowerCasePrompt.includes("settings")) {
      setMessage("Opening settings...");
      setCurrentView("settings");
    } else {
      const match = lowerCasePrompt.match(/(show|go to|find|open|display)\s?(?:client)?\s?(.*)/);
      if (match && match[2]) {
        const clientName = match[2];
        const foundClient = clients.find((c) =>
          c.name.toLowerCase().includes(clientName)
        );
        if (foundClient) {
          setMessage(`Navigating to ${foundClient.name}'s profile...`);
          onNavigate(foundClient.id);
        } else {
          setMessage(`Sorry, I couldn't find a client named "${clientName}".`);
        }
      } else {
        setMessage("I'm not sure how to help with that. Try 'Show client [name]'.");
      }
    }

    setPrompt("");
    setTimeout(() => setMessage(""), 4000);
  };

  return (
    <aside className="w-80 bg-gray-50 border-l border-gray-200 p-6 flex flex-col flex-shrink-0">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <BotIcon className="w-6 h-6 text-indigo-600" />
          <h2 className="text-xl font-bold text-gray-800">Synaptix Assistant</h2>
        </div>
        <button
          onClick={() => setCurrentView("dashboard")}
          className="p-2 text-gray-500 rounded-lg hover:bg-gray-200 hover:text-indigo-600"
          aria-label="Go to Dashboard"
        >
          <HomeIcon className="w-6 h-6" />
        </button>
      </div>

      <div className="text-sm text-gray-600 mb-4 bg-gray-100 p-3 rounded-lg">
        <p className="font-semibold mb-1">Try these commands:</p>
        <ul className="list-disc list-inside space-y-1">
          <li>"Find Innovate Corp"</li>
          <li>"Create contact Jane Doe, CEO, jane@example.com"</li>
          <li>"Create meeting Review Q3. Discuss KPIs."</li>
          <li>"Create deal New Website worth $15,000 won"</li>
        </ul>
      </div>

      <form onSubmit={handlePromptSubmit}>
        <div className="relative">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="How can I help you?"
            className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
          />
          <button
            type="submit"
            className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-500 hover:text-indigo-600"
          >
            <ChevronRightIcon className="w-5 h-5" />
          </button>
        </div>
      </form>

      {message && (
        <p className="mt-4 text-sm text-center bg-indigo-50 text-indigo-700 p-3 rounded-lg animate-fade-in">
          {message}
        </p>
      )}

      <style>{`
        .animate-fade-in { animation: fadeIn 0.5s ease-in-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </aside>
  );
}
