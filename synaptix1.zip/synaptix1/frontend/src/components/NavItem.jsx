export default function NavItem({ icon: Icon, label, isActive, onClick }) {
    return (
      <button
        onClick={onClick}
        className={`group relative flex items-center justify-center w-12 h-12 rounded-lg transition-colors ${
          isActive
            ? 'bg-indigo-600 text-white'
            : 'text-gray-400 hover:bg-gray-700 hover:text-white'
        }`}
      >
        <Icon className="w-6 h-6" />
        <span className="absolute left-full ml-4 px-2 py-1 text-sm bg-gray-800 text-white rounded-md invisible opacity-0 -translate-x-3 transition-all group-hover:visible group-hover:opacity-100 group-hover:translate-x-0">
          {label}
        </span>
      </button>
    );
  }
  