import HomeIcon from "../icons/HomeIcon";
import UsersIcon from "../icons/UsersIcon";
import CheckSquareIcon from "../icons/CheckSquareIcon";
import TargetIcon from "../icons/TargetIcon";
import TelescopeIcon from "../icons/TelescopeIcon";
import MegaphoneIcon from "../icons/MegaphoneIcon";
import CalendarIcon from "../icons/CalendarIcon";
import SettingsIcon from "../icons/SettingsIcon";
import ShieldIcon from "../icons/ShieldIcon";

function LogoutIcon({ className }) {
  return (
    <svg
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
      strokeWidth={2}
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6A2.25 2.25 0 005.25 5.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l3 3m0 0l-3 3m3-3H3"
      />
    </svg>
  );
}

const NavItem = ({ icon: Icon, label, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`group relative flex items-center justify-center w-12 h-12 rounded-lg transition-colors ${
      isActive
        ? "bg-indigo-600 text-white"
        : "text-gray-400 hover:bg-gray-700 hover:text-white"
    }`}
  >
    <Icon className="w-6 h-6" />
    <span className="absolute left-full ml-4 px-2 py-1 text-sm bg-gray-800 text-white rounded-md invisible opacity-0 -translate-x-3 transition-all group-hover:visible group-hover:opacity-100 group-hover:translate-x-0">
      {label}
    </span>
  </button>
);

export default function LeftNavRail({
  currentView,
  setCurrentView,
  currentUser,
  onLogout,
}) {
  let navItems = [];

  if (currentUser?.role === "Admin") {
    navItems = [
      { view: "dashboard", label: "Dashboard", icon: HomeIcon },
      { view: "admin", label: "Admin Panel", icon: ShieldIcon },
    ];
  } else {
    navItems = [
      { view: "dashboard", label: "Dashboard", icon: HomeIcon },
      { view: "clients", label: "Clients", icon: UsersIcon },
      { view: "tasks", label: "Tasks", icon: CheckSquareIcon },
      { view: "leads", label: "Leads", icon: TargetIcon },
      { view: "prospects", label: "Prospects", icon: TelescopeIcon },
      { view: "campaigns", label: "Campaigns", icon: MegaphoneIcon },
      { view: "marketingEvents", label: "Events", icon: CalendarIcon },
    ];
  }

  return (
    <nav className="w-20 bg-gray-800 p-3 flex flex-col items-center space-y-4">
      <img
        src="/Synaptix.jpg"
        alt="Synaptix Logo"
        className="w-10 h-10 rounded-lg"
      />

      <div className="flex-grow space-y-3">
        {navItems.map((item) => (
          <NavItem
            key={item.view}
            icon={item.icon}
            label={item.label}
            isActive={currentView === item.view}
            onClick={() => setCurrentView(item.view)}
          />
        ))}
      </div>

      <div className="mb-3">
        <NavItem
          icon={SettingsIcon}
          label="Settings"
          isActive={currentView === "settings"}
          onClick={() => setCurrentView("settings")}
        />
      </div>

      <div>
        <button
          onClick={onLogout}
          className="group relative flex items-center justify-center w-12 h-12 rounded-lg text-gray-400 hover:bg-red-600 hover:text-white transition-colors"
        >
          <LogoutIcon className="w-6 h-6" />
          <span className="absolute left-full ml-4 px-2 py-1 text-sm bg-red-600 text-white rounded-md invisible opacity-0 -translate-x-3 transition-all group-hover:visible group-hover:opacity-100 group-hover:translate-x-0">
            Logout
          </span>
        </button>
      </div>
    </nav>
  );
}
