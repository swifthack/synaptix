import CheckSquareIcon from "../icons/CheckSquareIcon";
import { mockTasks } from "../data/mockData";

export default function TasksView() {
  const priorityColor = (p) =>
    p === "High"
      ? "bg-red-100 text-red-800"
      : p === "Medium"
      ? "bg-yellow-100 text-yellow-800"
      : "bg-gray-100 text-gray-800";

  const statusColor = (s) =>
    s === "Completed"
      ? "bg-green-100 text-green-800"
      : s === "In Progress"
      ? "bg-blue-100 text-blue-800"
      : "bg-gray-100 text-gray-800";

  return (
    <div className="p-8">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
          <CheckSquareIcon className="w-6 h-6" />
        </div>
        <h1 className="text-3xl font-bold text-gray-800">Tasks</h1>
      </div>

      <div className="bg-white rounded-xl border overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Task</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Related To</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Due Date</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Priority</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {mockTasks.map((task) => (
              <tr key={task.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm">{task.title}</td>
                <td className="px-6 py-4 text-sm">{task.relatedTo}</td>
                <td className="px-6 py-4 text-sm">{task.dueDate}</td>
                <td className="px-6 py-4 text-sm">
                  <span className={`px-2 py-0.5 rounded-full text-xs ${priorityColor(task.priority)}`}>
                    {task.priority}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm">
                  <span className={`px-2 py-0.5 rounded-full text-xs ${statusColor(task.status)}`}>
                    {task.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
