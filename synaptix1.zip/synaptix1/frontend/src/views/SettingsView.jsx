import SettingsIcon from "../icons/SettingsIcon";

export default function SettingsView() {
  return (
    <div className="p-8">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
          <SettingsIcon className="w-6 h-6" />
        </div>
        <h1 className="text-3xl font-bold text-gray-800">Settings</h1>
      </div>

      <div className="bg-white p-6 rounded-xl border">
        <p className="text-gray-600">
          This is where application settings will be managed. User preferences,
          integrations, and other configuration options will appear here.
        </p>
      </div>
    </div>
  );
}
