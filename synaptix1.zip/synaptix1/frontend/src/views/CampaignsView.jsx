import GenericTableView from "../components/GenericTableView";
import MegaphoneIcon from "../icons/MegaphoneIcon";
import { mockCampaigns } from "../data/mockData";

export default function CampaignsView() {
  return (
    <GenericTableView
      title="Campaigns"
      icon={MegaphoneIcon}
      data={mockCampaigns}
      columns={[
        { key: "name", header: "Name", render: (r) => r.name },
        { key: "status", header: "Status", render: (r) => r.status },
        { key: "channel", header: "Channel", render: (r) => r.channel },
        { key: "budget", header: "Budget", render: (r) => `$${r.budget.toLocaleString()}` },
        { key: "roi", header: "ROI", render: (r) => r.roi },
      ]}
    />
  );
}
