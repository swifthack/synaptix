import GenericTableView from "../components/GenericTableView";
import TelescopeIcon from "../icons/TelescopeIcon";
import { mockProspects } from "../data/mockData";

export default function ProspectsView() {
  return (
    <GenericTableView
      title="Prospects"
      icon={TelescopeIcon}
      data={mockProspects}
      columns={[
        { key: "name", header: "Name", render: (r) => r.name },
        { key: "stage", header: "Stage", render: (r) => r.stage },
        { key: "value", header: "Value", render: (r) => `$${r.value.toLocaleString()}` },
        { key: "contact", header: "Primary Contact", render: (r) => r.contact },
      ]}
    />
  );
}
