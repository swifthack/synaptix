import GenericTableView from "../components/GenericTableView";
import CalendarIcon from "../icons/CalendarIcon";
import { mockMarketingEvents } from "../data/mockData";

export default function MarketingEventsView() {
  return (
    <GenericTableView
      title="Marketing Events"
      icon={CalendarIcon}
      data={mockMarketingEvents}
      columns={[
        { key: "name", header: "Event Name", render: (r) => r.name },
        { key: "type", header: "Type", render: (r) => r.type },
        { key: "date", header: "Date", render: (r) => r.date },
        { key: "status", header: "Status", render: (r) => r.status },
        { key: "attendees", header: "Attendees", render: (r) => r.attendees },
      ]}
    />
  );
}
