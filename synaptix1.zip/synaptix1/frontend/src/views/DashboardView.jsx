import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from "recharts";

import UsersIcon from "../icons/UsersIcon";
import TargetIcon from "../icons/TargetIcon";
import CheckSquareIcon from "../icons/CheckSquareIcon";
import MegaphoneIcon from "../icons/MegaphoneIcon";

import { mockClients, mockLeads, mockTasks, mockCampaigns } from "../data/mockData";

export default function DashboardView() {
  // --- KPI metrics
  const totalRevenue = mockClients.reduce((sum, c) => sum + (c.revenue || 0), 0);
  const activeClients = mockClients.filter((c) => c.status === "Active").length;
  const totalLeads = mockLeads.length;
  const openTasks = mockTasks.filter((t) => t.status !== "Completed").length;

  // --- Revenue by client chart data
  const revenueData = mockClients.map((c) => ({
    name: c.name,
    revenue: c.revenue || 0,
  }));

  // --- Lead sources pie chart
  const leadSources = mockLeads.reduce((acc, l) => {
    acc[l.source] = (acc[l.source] || 0) + 1;
    return acc;
  }, {});
  const leadSourceData = Object.entries(leadSources).map(([k, v]) => ({
    name: k,
    value: v,
  }));

  const COLORS = ["#6366F1", "#10B981", "#F59E0B", "#EF4444"];

  return (
    <div className="p-8 space-y-8">
      <h1 className="text-3xl font-bold text-gray-800 mb-4">Dashboard</h1>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <KPI
          icon={<UsersIcon className="w-6 h-6" />}
          label="Active Clients"
          value={activeClients}
          color="bg-indigo-100 text-indigo-700"
        />
        <KPI
          icon={<TargetIcon className="w-6 h-6" />}
          label="Total Leads"
          value={totalLeads}
          color="bg-green-100 text-green-700"
        />
        <KPI
          icon={<CheckSquareIcon className="w-6 h-6" />}
          label="Open Tasks"
          value={openTasks}
          color="bg-yellow-100 text-yellow-700"
        />
        <KPI
          icon={<MegaphoneIcon className="w-6 h-6" />}
          label="Revenue"
          value={`$${totalRevenue.toLocaleString()}`}
          color="bg-purple-100 text-purple-700"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Revenue by Client (Bar Chart) */}
        <div className="bg-white p-6 rounded-xl border">
          <h2 className="text-lg font-semibold mb-4">Revenue by Client</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={revenueData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="revenue" fill="#6366F1" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Lead Sources (Pie Chart) */}
        <div className="bg-white p-6 rounded-xl border">
          <h2 className="text-lg font-semibold mb-4">Lead Sources</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={leadSourceData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={100}
                label
              >
                {leadSourceData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={COLORS[index % COLORS.length]}
                  />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

// --- Reusable KPI Card ---
function KPI({ icon, label, value, color }) {
  return (
    <div className="bg-white rounded-xl border p-6 flex items-center space-x-4">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
        {icon}
      </div>
      <div>
        <p className="text-sm text-gray-500">{label}</p>
        <p className="text-xl font-bold">{value}</p>
      </div>
    </div>
  );
}
