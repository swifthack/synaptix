import { useEffect, useMemo } from "react";
import PlusIcon from "../icons/PlusIcon";

export default function Client360View({
  client,
  onBack,
  onAddMeeting,
  onAddDeal,
  onUpdateDeal,
  onAddContact,
  onUpdateContact,
  activeTab,
  setActiveTab,
  dealFormState,
  setDealFormState,
  contactFormState,
  setContactFormState,
  meetingFormState,
  setMeetingFormState,
}) {
  const { dealName, dealValue, dealStatus, dealCloseDate, editingDealId } =
    dealFormState;
  const { contactName, contactRole, contactEmail, editingContactId } =
    contactFormState;
  const { meetingTitle, meetingNotes } = meetingFormState;

  const resetDealForm = () =>
    setDealFormState({
      dealName: "",
      dealValue: "",
      dealStatus: "Pending",
      dealCloseDate: new Date().toISOString().split("T")[0],
      editingDealId: null,
    });
  const resetContactForm = () =>
    setContactFormState({
      contactName: "",
      contactRole: "",
      contactEmail: "",
      editingContactId: null,
    });
  const resetMeetingForm = () =>
    setMeetingFormState({ meetingTitle: "", meetingNotes: "" });

  useEffect(() => {
    resetDealForm();
    resetContactForm();
    resetMeetingForm();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client?.id]);

  const dealsSummary = useMemo(() => {
    if (!client || !client.deals)
      return {
        won: 0,
        lost: 0,
        pending: 0,
        totalValue: 0,
        winRate: 0,
        lossRate: 0,
        totalClosed: 0,
      };
    const wonDeals = client.deals.filter((d) => d.status === "Won");
    const lostDeals = client.deals.filter((d) => d.status === "Lost");
    const totalClosed = wonDeals.length + lostDeals.length;
    return {
      won: wonDeals.length,
      lost: lostDeals.length,
      pending: client.deals.filter((d) => d.status === "Pending").length,
      totalValue: wonDeals.reduce((sum, deal) => sum + deal.value, 0),
      winRate:
        totalClosed > 0 ? Math.round((wonDeals.length / totalClosed) * 100) : 0,
      lossRate:
        totalClosed > 0 ? Math.round((lostDeals.length / totalClosed) * 100) : 0,
      totalClosed,
    };
  }, [client]);

  const handleMeetingFormSubmit = (e) => {
    e.preventDefault();
    if (!meetingTitle || !meetingNotes) return;
    const newMeeting = {
      id: Date.now(),
      date: new Date().toISOString().split("T")[0],
      title: meetingTitle,
      notes: meetingNotes,
    };
    onAddMeeting(client.id, newMeeting);
    resetMeetingForm();
  };

  const handleContactFormSubmit = (e) => {
    e.preventDefault();
    if (!contactName || !contactRole || !contactEmail) return;
    const contactData = {
      id: editingContactId || Date.now(),
      name: contactName,
      role: contactRole,
      email: contactEmail,
    };
    if (editingContactId) {
      onUpdateContact(client.id, contactData);
    } else {
      onAddContact(client.id, contactData);
    }
    resetContactForm();
  };

  const handleDealFormSubmit = (e) => {
    e.preventDefault();
    if (!dealName || dealValue === "" || !dealStatus || !dealCloseDate) return;
    const dealData = {
      id: editingDealId || Date.now(),
      name: dealName,
      status: dealStatus,
      value: parseFloat(dealValue),
      closeDate: dealCloseDate,
    };
    if (editingDealId) {
      onUpdateDeal(client.id, dealData);
    } else {
      onAddDeal(client.id, dealData);
    }
    resetDealForm();
  };

  const handleSelectDealForEditing = (deal) =>
    setDealFormState({
      editingDealId: deal.id,
      dealName: deal.name,
      dealValue: deal.value,
      dealStatus: deal.status,
      dealCloseDate: deal.closeDate,
    });

  const handleSelectContactForEditing = (contact) =>
    setContactFormState({
      editingContactId: contact.id,
      contactName: contact.name,
      contactRole: contact.role,
      contactEmail: contact.email,
    });

  if (!client)
    return (
      <div className="p-8">
        <h1 className="text-3xl font-bold text-gray-800">Client Not Found</h1>
        <button onClick={onBack} className="mt-4 text-indigo-600 hover:underline">
          ← Back to Clients
        </button>
      </div>
    );

  const TabButton = ({ tabName, label }) => (
    <button
      onClick={() => setActiveTab(tabName)}
      className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
        activeTab === tabName
          ? "bg-indigo-600 text-white"
          : "text-gray-600 hover:bg-gray-200"
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="p-8 space-y-6">
      <div>
        <button
          onClick={onBack}
          className="text-sm text-indigo-600 hover:underline mb-2"
        >
          ← Back to Clients List
        </button>
        <h1 className="text-3xl font-bold text-gray-800">{client.name}</h1>
        <p className="text-gray-500">{client.industry}</p>
      </div>

      <div className="border-b border-gray-200">
        <nav className="flex space-x-2">
          <TabButton tabName="overview" label="Overview" />
          <TabButton tabName="deals" label="Deals" />
          <TabButton tabName="contacts" label="Contacts" />
          <TabButton tabName="meetings" label="Meetings" />
        </nav>
      </div>

      <div className="animate-fade-in">
        {activeTab === "overview" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <p className="text-gray-500 text-sm">Revenue</p>
              <p className="text-2xl font-bold text-gray-800">
                ${client.revenue.toLocaleString()}
              </p>
            </div>
            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <p className="text-gray-500 text-sm">Status</p>
              <p className="text-2xl font-bold text-gray-800">{client.status}</p>
            </div>
            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <p className="text-gray-500 text-sm">Primary Contact</p>
              <p className="text-lg font-semibold text-gray-800">
                {client.contact}
              </p>
            </div>
          </div>
        )}

        {activeTab === "contacts" && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                {editingContactId ? "Edit Contact" : "Create New Contact"}
              </h2>
              <div className="mb-4 bg-indigo-50 border-l-4 border-indigo-400 p-4 rounded-r-lg">
                <p className="text-sm text-indigo-800">
                  Use the Synaptix Assistant. Try: "Create contact John Doe, CEO,
                  john@example.com".
                </p>
              </div>
              <form onSubmit={handleContactFormSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Name
                    </label>
                    <input
                      type="text"
                      value={contactName}
                      onChange={(e) =>
                        setContactFormState({
                          ...contactFormState,
                          contactName: e.target.value,
                        })
                      }
                      className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Role
                    </label>
                    <input
                      type="text"
                      value={contactRole}
                      onChange={(e) =>
                        setContactFormState({
                          ...contactFormState,
                          contactRole: e.target.value,
                        })
                      }
                      className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                      required
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    type="email"
                    value={contactEmail}
                    onChange={(e) =>
                      setContactFormState({
                        ...contactFormState,
                        contactEmail: e.target.value,
                      })
                    }
                    className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                    required
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    type="submit"
                    className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition"
                  >
                    <PlusIcon className="w-5 h-5 mr-2" />
                    {editingContactId ? "Update Contact" : "Create Contact"}
                  </button>
                  {editingContactId && (
                    <button
                      type="button"
                      onClick={resetContactForm}
                      className="px-4 py-2 bg-gray-200 text-gray-700 font-semibold rounded-lg hover:bg-gray-300 transition"
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </form>
            </div>

            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Contact List
              </h2>
              <div className="divide-y divide-gray-200">
                {client.contacts?.map((contact) => (
                  <div
                    key={contact.id}
                    className="py-3 flex justify-between items-center hover:bg-gray-50 rounded-lg px-2 -mx-2 cursor-pointer"
                    onClick={() => handleSelectContactForEditing(contact)}
                  >
                    <div>
                      <p className="font-medium text-gray-800">{contact.name}</p>
                      <p className="text-sm text-gray-500">{contact.role}</p>
                    </div>
                    <p className="text-sm text-indigo-600">{contact.email}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "meetings" && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Add New Meeting Note
              </h2>
              <div className="mb-4 bg-indigo-50 border-l-4 border-indigo-400 p-4 rounded-r-lg">
                <p className="text-sm text-indigo-800">
                  Use the Synaptix Assistant. Try: "Create meeting Review Q3
                  performance. Client requested KPI deep-dive."
                </p>
              </div>
              <form onSubmit={handleMeetingFormSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Title
                  </label>
                  <input
                    type="text"
                    value={meetingTitle}
                    onChange={(e) =>
                      setMeetingFormState({
                        ...meetingFormState,
                        meetingTitle: e.target.value,
                      })
                    }
                    className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Notes
                  </label>
                  <textarea
                    value={meetingNotes}
                    onChange={(e) =>
                      setMeetingFormState({
                        ...meetingFormState,
                        meetingNotes: e.target.value,
                      })
                    }
                    className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                    rows="4"
                    required
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition"
                >
                  <PlusIcon className="w-5 h-5 mr-2" />
                  Save Note
                </button>
              </form>
            </div>

            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Meeting History
              </h2>
              <ul className="space-y-4">
                {client.meetings?.length > 0 ? (
                  client.meetings
                    .sort((a, b) => new Date(b.date) - new Date(a.date))
                    .map((item) => (
                      <li key={item.id} className="border-l-2 border-indigo-500 pl-4">
                        <p className="font-bold text-gray-800">{item.title}</p>
                        <p className="text-sm text-gray-500 mb-1">
                          {new Date(item.date).toLocaleDateString()}
                        </p>
                        <p className="text-gray-700">{item.notes}</p>
                      </li>
                    ))
                ) : (
                  <p className="text-gray-500">No meeting notes found.</p>
                )}
              </ul>
            </div>
          </div>
        )}

        {activeTab === "deals" && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                {editingDealId ? "Edit Deal" : "Create New Deal"}
              </h2>
              <div className="mb-4 bg-indigo-50 border-l-4 border-indigo-400 p-4 rounded-r-lg">
                <p className="text-sm text-indigo-800">
                  Use the Synaptix Assistant to populate this form. Try: "Create
                  deal New Website worth $15,000 won".
                </p>
              </div>
              <form onSubmit={handleDealFormSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Deal Name
                    </label>
                    <input
                      type="text"
                      value={dealName}
                      onChange={(e) =>
                        setDealFormState({
                          ...dealFormState,
                          dealName: e.target.value,
                        })
                      }
                      className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Value ($)
                    </label>
                    <input
                      type="number"
                      value={dealValue}
                      onChange={(e) =>
                        setDealFormState({
                          ...dealFormState,
                          dealValue: e.target.value,
                        })
                      }
                      className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Status
                    </label>
                    <select
                      value={dealStatus}
                      onChange={(e) =>
                        setDealFormState({
                          ...dealFormState,
                          dealStatus: e.target.value,
                        })
                      }
                      className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm bg-white"
                      required
                    >
                      <option>Pending</option>
                      <option>Won</option>
                      <option>Lost</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Close Date
                    </label>
                    <input
                      type="date"
                      value={dealCloseDate}
                      onChange={(e) =>
                        setDealFormState({
                          ...dealFormState,
                          dealCloseDate: e.target.value,
                        })
                      }
                      className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                      required
                    />
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    type="submit"
                    className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition"
                  >
                    <PlusIcon className="w-5 h-5 mr-2" />
                    {editingDealId ? "Update Deal" : "Create Deal"}
                  </button>
                  {editingDealId && (
                    <button
                      type="button"
                      onClick={resetDealForm}
                      className="px-4 py-2 bg-gray-200 text-gray-700 font-semibold rounded-lg hover:bg-gray-300 transition"
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </form>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <p className="text-gray-500 text-sm">Total Value Won</p>
                <p className="text-2xl font-bold text-gray-800">
                  ${dealsSummary.totalValue.toLocaleString()}
                </p>
              </div>
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <p className="text-gray-500 text-sm">Win Rate</p>
                <p className="text-2xl font-bold text-gray-800">
                  {dealsSummary.winRate}%
                </p>
              </div>
              <div className="bg-white p-6 rounded-xl border border-gray-200">
                <p className="text-gray-500 text-sm">Pending Deals</p>
                <p className="text-2xl font-bold text-gray-800">
                  {dealsSummary.pending}
                </p>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Deal Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Value
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Close Date
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {client.deals
                    ?.sort(
                      (a, b) => new Date(b.closeDate) - new Date(a.closeDate)
                    )
                    .map((deal) => (
                      <tr key={deal.id} className="hover:bg-gray-50">
                        <td
                          className="px-6 py-4 text-sm font-medium text-indigo-600 hover:text-indigo-800 hover:underline cursor-pointer"
                          onClick={() => handleSelectDealForEditing(deal)}
                        >
                          {deal.name}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <span
                            className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              deal.status === "Won"
                                ? "bg-green-100 text-green-800"
                                : deal.status === "Lost"
                                ? "bg-red-100 text-red-800"
                                : "bg-blue-100 text-blue-800"
                            }`}
                          >
                            {deal.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-500">
                          ${deal.value.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-500">
                          {deal.closeDate}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <style>{`
        .animate-fade-in { animation: fadeIn 0.5s ease-in-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
}
