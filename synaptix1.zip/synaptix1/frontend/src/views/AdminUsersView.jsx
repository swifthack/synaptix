import { useState } from "react";
import UsersIcon from "../icons/UsersIcon";
import TargetIcon from "../icons/TargetIcon";
import { mockUsers, mockClients, mockLeads } from "../data/mockData";

export default function AdminUsersView() {
  const [clients, setClients] = useState(mockClients);
  const [leads, setLeads] = useState(mockLeads);

  const [newClient, setNewClient] = useState({ name: "", industry: "", contact: "", assignedTo: "" });
  const [newLead, setNewLead] = useState({ name: "", company: "", source: "", assignedTo: "" });

  const relationshipManagers = mockUsers.filter((u) => u.role === "Relationship Manager");

  const handleAddClient = () => {
    setClients([
      ...clients,
      {
        ...newClient,
        id: clients.length + 1,
        status: "Active",
        revenue: 0,
      },
    ]);
    setNewClient({ name: "", industry: "", contact: "", assignedTo: "" });
  };

  const handleAddLead = () => {
    setLeads([
      ...leads,
      {
        ...newLead,
        id: leads.length + 1,
        status: "New",
      },
    ]);
    setNewLead({ name: "", company: "", source: "", assignedTo: "" });
  };

  return (
    <div className="p-8 space-y-8">
      <h1 className="text-3xl font-bold text-gray-800">Admin Panel</h1>
      <p className="text-gray-500">Create clients and leads, assign them to Relationship Managers.</p>

      {/* Create Client */}
      <div className="bg-white p-6 rounded-xl border space-y-4">
        <h2 className="flex items-center text-xl font-semibold space-x-2">
          <UsersIcon className="w-6 h-6 text-indigo-600" />
          <span>Create Client</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input
            type="text"
            placeholder="Client Name"
            className="border p-2 rounded"
            value={newClient.name}
            onChange={(e) => setNewClient({ ...newClient, name: e.target.value })}
          />
          <input
            type="text"
            placeholder="Industry"
            className="border p-2 rounded"
            value={newClient.industry}
            onChange={(e) => setNewClient({ ...newClient, industry: e.target.value })}
          />
          <input
            type="text"
            placeholder="Contact Email"
            className="border p-2 rounded"
            value={newClient.contact}
            onChange={(e) => setNewClient({ ...newClient, contact: e.target.value })}
          />
          <select
            className="border p-2 rounded"
            value={newClient.assignedTo}
            onChange={(e) => setNewClient({ ...newClient, assignedTo: parseInt(e.target.value) })}
          >
            <option value="">Assign to RM</option>
            {relationshipManagers.map((rm) => (
              <option key={rm.id} value={rm.id}>
                {rm.name}
              </option>
            ))}
          </select>
        </div>
        <button
          onClick={handleAddClient}
          className="mt-2 px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
        >
          Add Client
        </button>
      </div>

      {/* Create Lead */}
      <div className="bg-white p-6 rounded-xl border space-y-4">
        <h2 className="flex items-center text-xl font-semibold space-x-2">
          <TargetIcon className="w-6 h-6 text-green-600" />
          <span>Create Lead</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input
            type="text"
            placeholder="Lead Name"
            className="border p-2 rounded"
            value={newLead.name}
            onChange={(e) => setNewLead({ ...newLead, name: e.target.value })}
          />
          <input
            type="text"
            placeholder="Company"
            className="border p-2 rounded"
            value={newLead.company}
            onChange={(e) => setNewLead({ ...newLead, company: e.target.value })}
          />
          <input
            type="text"
            placeholder="Source"
            className="border p-2 rounded"
            value={newLead.source}
            onChange={(e) => setNewLead({ ...newLead, source: e.target.value })}
          />
          <select
            className="border p-2 rounded"
            value={newLead.assignedTo}
            onChange={(e) => setNewLead({ ...newLead, assignedTo: parseInt(e.target.value) })}
          >
            <option value="">Assign to RM</option>
            {relationshipManagers.map((rm) => (
              <option key={rm.id} value={rm.id}>
                {rm.name}
              </option>
            ))}
          </select>
        </div>
        <button
          onClick={handleAddLead}
          className="mt-2 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        >
          Add Lead
        </button>
      </div>
    </div>
  );
}
