export const mockClients = [
    { 
      id: 1, 
      name: 'Innovate Corp', 
      industry: 'Technology', 
      status: 'Active', 
      contact: 'jane.doe@innovate.com', 
      revenue: 120000, 
      lastInteraction: '2024-07-15', 
      contacts: [
        { id: 1001, name: 'Jane Doe', role: 'CEO', email: 'jane.doe@innovate.com' },
        { id: 1002, name: 'Mark Smith', role: 'CTO', email: 'mark.smith@innovate.com' },
      ],
      meetings: [
        { id: 2001, date: '2024-08-20', title: 'Contract Signing', notes: 'Final contract signed. Project kickoff scheduled for next week.' },
        { id: 2002, date: '2024-08-01', title: 'Proposal Review', notes: 'Follow-up call to review the project proposal. Client is happy with the terms.' },
        { id: 2003, date: '2024-07-15', title: 'Initial Meeting', notes: 'Discussed Q3 goals and project scope. Sent initial discovery questionnaire.' }, 
      ],
      deals: [
        { id: 101, name: 'Q3 Platform Upgrade', status: 'Won', value: 50000, closeDate: '2024-08-15' },
        { id: 102, name: 'Analytics Package', status: 'Won', value: 70000, closeDate: '2024-07-20' },
        { id: 103, name: 'Support Contract', status: 'Lost', value: 25000, closeDate: '2024-09-01' },
        { id: 104, name: '2025 Renewal', status: 'Pending', value: 125000, closeDate: '2024-12-15' },
      ] 
    },
    { 
      id: 2, 
      name: 'Quantum Solutions', 
      industry: 'Finance', 
      status: 'Lead', 
      contact: 'john.smith@quantum.com', 
      revenue: 0, 
      lastInteraction: '2024-08-05',
      contacts: [ { id: 1003, name: 'John Smith', role: 'Lead Analyst', email: 'john.smith@quantum.com' } ],
      meetings: [ { id: 2004, date: '2024-08-05', title: 'Webinar Follow-up', notes: 'First contact via webinar. Expressed interest in our analytics platform.' } ],
      deals: [ { id: 201, name: 'Initial Analytics Setup', status: 'Pending', value: 35000, closeDate: '2024-10-01' } ]
    },
    { 
      id: 3, 
      name: 'Apex Logistics', 
      industry: 'Shipping', 
      status: 'On Hold', 
      contact: 'samantha.b@apex.com', 
      revenue: 75000, 
      lastInteraction: '2024-06-22',
      contacts: [ { id: 1004, name: 'Samantha Brown', role: 'Operations Manager', email: 'samantha.b@apex.com' } ],
      meetings: [ { id: 2005, date: '2024-06-22', title: 'Project Update', notes: 'Project paused due to internal budget constraints. Will re-evaluate in Q4.' } ],
      deals: [ { id: 301, name: 'Logistics Software Suite', status: 'Lost', value: 60000, closeDate: '2024-05-10' } ]
    },
    { 
      id: 4, 
      name: 'Stellar Health', 
      industry: 'Healthcare', 
      status: 'Active', 
      contact: 'liam.chen@stellar.com', 
      revenue: 250000, 
      lastInteraction: '2024-08-18',
      contacts: [
        { id: 1005, name: 'Liam Chen', role: 'Director of IT', email: 'liam.chen@stellar.com' },
        { id: 1006, name: 'Dr. Ava Wilson', role: 'Chief Medical Officer', email: 'ava.wilson@stellar.com' },
      ],
      meetings: [
        { id: 2006, date: '2024-08-18', title: 'Quarterly Business Review', notes: 'Presented Q2 performance metrics. Discussed upcoming feature requests.' },
        { id: 2007, date: '2024-07-10', title: 'Onboarding Completion', notes: 'Final onboarding session completed. All key users are trained on the platform.' }
      ],
      deals: [
        { id: 401, name: 'EMR Integration', status: 'Won', value: 150000, closeDate: '2024-06-01' },
        { id: 402, name: 'Patient Portal', status: 'Won', value: 100000, closeDate: '2024-08-05' },
      ]
    },
    { 
      id: 5, 
      name: 'GreenLeaf Organics', 
      industry: 'Retail', 
      status: 'Lead', 
      contact: 'emily.white@greenleaf.com', 
      revenue: 0, 
      lastInteraction: '2024-08-21',
      contacts: [ { id: 1007, name: 'Emily White', role: 'Founder', email: 'emily.white@greenleaf.com' } ],
      meetings: [ { id: 2008, date: '2024-08-21', title: 'Inbound Inquiry', notes: 'Inbound inquiry about our sustainable product line. Scheduled a demo for next week.' } ],
      deals: []
    },
  ];
  
  export const mockLeads = [
      { id: 1, name: 'David Miller', company: 'Fusion Dynamics', source: 'Website Form', status: 'New', assignedTo: 'Alex Green' },
      { id: 2, name: 'Sophia Chen', company: 'NextGen AI', source: 'LinkedIn', status: 'Contacted', assignedTo: 'Ben Carter' },
      { id: 3, name: 'Michael Rodriguez', company: 'BrightStar Solar', source: 'Referral', status: 'Qualified', assignedTo: 'Alex Green' },
  ];
  
  export const mockProspects = [
      { id: 1, name: 'BrightStar Solar', stage: 'Needs Analysis', value: 45000, contact: 'Michael Rodriguez' },
      { id: 2, name: 'DataWeave Inc.', stage: 'Proposal Sent', value: 80000, contact: 'Olivia White' },
      { id: 3, name: 'Terra Verde', stage: 'Negotiation', value: 65000, contact: 'James Taylor' },
  ];
  
  export const mockCampaigns = [
      { id: 1, name: 'Q4 Product Launch', status: 'Active', budget: 20000, roi: '150%', channel: 'Email & Social Media' },
      { id: 2, name: 'Summer Sales Event', status: 'Completed', budget: 15000, roi: '210%', channel: 'PPC Ads' },
      { id: 3, name: '2025 Brand Awareness', status: 'Planned', budget: 50000, roi: 'N/A', channel: 'Content Marketing' },
  ];
  
  export const mockMarketingEvents = [
      { id: 1, name: 'TechCon 2025', type: 'Conference', date: '2025-03-15', status: 'Planned', attendees: 0 },
      { id: 2, name: 'Innovate AI Webinar', type: 'Webinar', date: '2024-11-20', status: 'Upcoming', attendees: 150 },
      { id: 3, name: 'Annual User Summit', type: 'User Group', date: '2024-09-10', status: 'Completed', attendees: 300 },
  ];
  
  export const mockTasks = [
      { id: 1, title: 'Follow up with Innovate Corp re: 2025 Renewal', dueDate: '2024-09-15', status: 'In Progress', relatedTo: 'Innovate Corp', relatedToType: 'Client', priority: 'High' },
      { id: 2, title: 'Qualify Michael Rodriguez lead', dueDate: '2024-09-10', status: 'Not Started', relatedTo: 'Michael Rodriguez', relatedToType: 'Lead', priority: 'Medium' },
      { id: 3, title: 'Send proposal to DataWeave Inc.', dueDate: '2024-09-12', status: 'In Progress', relatedTo: 'DataWeave Inc.', relatedToType: 'Prospect', priority: 'High' },
      { id: 4, title: 'Draft email copy for Q4 Product Launch', dueDate: '2024-09-20', status: 'Not Started', relatedTo: 'Q4 Product Launch', relatedToType: 'Campaign', priority: 'Medium' },
      { id: 5, title: 'Book venue for TechCon 2025', dueDate: '2024-10-01', status: 'Completed', relatedTo: 'TechCon 2025', relatedToType: 'Event', priority: 'Low' },
      { id: 6, title: 'Onboarding call with Stellar Health', dueDate: '2024-09-18', status: 'Not Started', relatedTo: 'Stellar Health', relatedToType: 'Client', priority: 'High' },
  ];
  
  export const mockUsers = [
    { id: 1, name: "Alice Johnson", role: "Admin" },
    { id: 2, name: "Bob Smith", role: "Relationship Manager" },
    { id: 3, name: "Carol Lee", role: "Relationship Manager" },
  ];