export default function TelescopeIcon({ className }) {
    return (
      <svg
        className={className}
        xmlns="http://www.w3.org/2000/svg"
        width="24" height="24"
        viewBox="0 0 24 24"
        fill="none" stroke="currentColor"
        strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
      >
        <path d="m10.065 12.493-6.18 1.318a.934.934 0 0 1-1.108-1.108l1.318-6.18A.934.934 0 0 1 5 6.013l2.485 2.485 2.485-2.485a.934.934 0 0 1 1.488.508l1.318 6.18a.934.934 0 0 1-1.108 1.108l-6.18-1.318a.934.934 0 0 1-.508-1.488Z"/>
        <path d="m14.194 14.194 4.743 4.743"/>
        <path d="m16 6 3 3"/>
      </svg>
    );
  }

  