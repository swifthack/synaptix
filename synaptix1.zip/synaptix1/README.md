📌 Synaptix CRM (React + Vite + Tailwind)

A lightweight CRM demo application with dashboard, clients, tasks, leads, prospects, campaigns, and AI-assistant navigation. Built with React, Vite, and TailwindCSS.

🚀 Features

📊 Dashboard with revenue, active clients, leads, campaigns.

👥 Client 360 View with contacts, deals, and meetings.

✅ Task Manager with priority and status badges.

🎯 Leads & Prospects pipeline views.

📣 Campaigns & Marketing Events management.

🤖 AI Assistant to navigate and populate forms using prompts.

🎨 TailwindCSS for modern responsive UI.

📂 Project Structure

synaptix-crm/
├── public/              # Static assets (e.g., Synaptix.jpg)
├── src/
│   ├── components/      # Reusable UI + icons
│   ├── data/            # Mock data
│   ├── views/           # Page-level views
│   ├── App.jsx          # Root app
│   ├── main.jsx         # Entry point
│   └── index.css        # Tailwind styles
├── package.json
├── postcss.config.js
├── tailwind.config.js
└── vite.config.js




npm install -D tailwindcss@3 postcss autoprefixer

npx tailwindcss init -p


Installation

Clone the project (or copy files):

git clone https://github.com/your-username/synaptix-crm.git
cd synaptix-crm


Install dependencies:

npm install


Start development server:

npm run dev


Open http://localhost:5173
 in your browser 🚀

🖼 Assets

Place your Synaptix logo in public/ as:

public/Synaptix.jpg

📦 Build for Production
npm run build
npm run preview

🛠 Tech Stack

React

Vite

TailwindCSS
