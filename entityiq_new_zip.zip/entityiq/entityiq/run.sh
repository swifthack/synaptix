#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv 2>/dev/null || true
source .venv/bin/activate
pip install -q -r requirements.txt
python -c "from app import seed; print(seed.load())" >/dev/null
echo "EntityIQ on http://127.0.0.1:8000  (console /, api docs /docs, mcp /mcp)"
exec uvicorn app.api:app --host 0.0.0.0 --port 8000
