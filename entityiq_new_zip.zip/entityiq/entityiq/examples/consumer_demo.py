"""How another application or agent consumes EntityIQ.

Run the server first (./run.sh), then:  python examples/consumer_demo.py

Shows the three integration paths and, more importantly, the one behaviour every
consumer must implement: handling an abstention. The last section deliberately
asks for a product that cannot be answered and shows what a correct consumer
does with the response.
"""
from __future__ import annotations

import json
import urllib.request

BASE = "http://127.0.0.1:8000"
KEY = "demo-agent-key"


def call(path: str, method: str = "GET", body: dict | None = None, key: str = KEY):
    req = urllib.request.Request(
        BASE + path, method=method,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"content-type": "application/json", "x-api-key": key})
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())


def show(title: str, obj, depth: int = 900):
    print(f"\n{'=' * 72}\n{title}\n{'=' * 72}")
    print(json.dumps(obj, indent=2, default=str)[:depth])


def main() -> None:
    # ---------------------------------------------------------------- 1. REST
    pack = call("/v1/products/kyb-pack/CUST-1001?purpose=onboarding", key="demo-kyc-key")
    show("REST · KYB pack for a credit engine", {
        "answerable": pack["answerable"],
        "legal_identity": pack["data"]["legal_identity"],
        "directors": pack["data"]["directors"],
        "resolution": [{k: r[k] for k in ("record_id", "outcome", "score")} for r in pack["data"]["resolution"]],
        "policy": pack["policy"],
    })

    # ------------------------------------------------- 2. MCP (for LLM agents)
    tools = call("/mcp", "POST", {"method": "tools/list", "id": 1})
    show("MCP · tool manifest", [t["name"] for t in tools["result"]["tools"]])

    called = call("/mcp", "POST", {
        "method": "tools/call", "id": 2,
        "params": {"name": "get_ubo_graph", "arguments": {"customer_id": "CUST-1001"}}})
    show("MCP · UBO graph", called["result"]["structuredContent"]["data"]["ultimate_beneficial_owners"])

    # -------------------------------------------------- 3. A2A (agent-to-agent)
    card = call("/.well-known/agent.json")
    show("A2A · agent card", {"skills": [s["id"] for s in card["skills"]],
                              "guarantees": card["guarantees"]})

    # ------------------------------------------- 4. the case consumers get wrong
    gap = call("/a2a/tasks", "POST",
               {"skill": "get_screening_bundle", "args": {"customer_id": "CUST-1005"}})
    show("A2A · abstention (this is NOT an empty result)", gap)

    state = gap["state"]
    if state == "input-required":
        print("\nCorrect consumer behaviour: do not report 'no sanctions found'.")
        for action in gap["required_input"]:
            print(f"  queue -> {action['action']}")

    # -------------------------------------------------------- 5. time travel
    now = call("/v1/resolution/ext_acra_001")
    show("Time travel · current decision", {k: now[k] for k in ("outcome", "score", "decided_at")})

    # ------------------------------------------ 6. threshold change, safely
    sweep = call("/v1/resolution/replay/sweep")
    show("Replay · what each auto-link threshold would do", sweep["points"])


if __name__ == "__main__":
    main()
