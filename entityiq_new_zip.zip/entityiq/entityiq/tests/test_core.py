import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("EIQ_DB", os.path.join(tempfile.gettempdir(), "eiq_test.db"))

import pytest

from app import db, evidence, policy, products, replay, resolution, seed
from app.graph import communities, ownership_tree
from app.normalize import blocking_keys, normalize_id, normalize_name
from app.similarity import name_similarity


@pytest.fixture(scope="module", autouse=True)
def book():
    return seed.load(reset=True)


def test_name_normalization_strips_legal_form():
    assert normalize_name("ABC CONSTRUCTION PTE. LTD.") == "abc construction"
    # a name made only of legal suffixes must not normalize to empty
    assert normalize_name("Pte Ltd") == "pte ltd"


def test_id_normalization():
    assert normalize_id("CHE-114.222.333") == "CHE114222333"
    assert normalize_id(None) is None


def test_token_reordering_is_matched():
    assert name_similarity("helios holdings", "holdings helios") > 0.7


def test_blocking_keys_include_registration_and_tokens():
    keys = [k for k, _ in blocking_keys({
        "legal_name": "ABC Construction Pte Ltd", "jurisdiction": "SG",
        "registration_no": "202012345E", "address": "12 Marina Boulevard"})]
    assert any(k.startswith("reg_SG_") for k in keys)
    assert any(k.startswith("nametok_") for k in keys)


def test_registration_match_auto_links():
    d = resolution.link_as_of("ext_acra_001")
    assert d["outcome"] == "auto_link"
    assert d["customer_id"] == "CUST-1001"
    assert "registration_match" in d["rule_hits"]


def test_ambiguous_pair_is_forced_to_review():
    d = resolution.link_as_of("ext_acra_003")
    assert d["outcome"] == "needs_review", d


def test_score_is_deterministic_and_versioned():
    d = resolution.link_as_of("ext_cr_002")
    assert 0.0 <= d["score"] <= 1.0
    assert d["scorecard_version"].startswith("sc-")
    assert isinstance(d["features"], dict) and d["features"]


def test_evidence_chain_verifies():
    assert evidence.verify()["ok"] is True


def test_evidence_chain_detects_tampering():
    conn = db.connect()
    row = conn.execute("SELECT evidence_id, confidence FROM evidence ORDER BY seq LIMIT 1").fetchone()
    conn.execute("UPDATE evidence SET confidence=0.01 WHERE evidence_id=?", (row["evidence_id"],))
    conn.commit()
    result = evidence.verify()
    assert result["ok"] is False and result["broken_at"] == row["evidence_id"]
    conn.execute("UPDATE evidence SET confidence=? WHERE evidence_id=?",
                 (row["confidence"], row["evidence_id"]))
    conn.commit()
    assert evidence.verify()["ok"] is True


def test_product_abstains_without_screening_evidence():
    out = products.screening_bundle("CUST-1005")
    assert out["answerable"] is False
    assert out["data"] is None
    assert out["sufficiency"]["remediation"]


def test_ubo_abstains_on_circular_holding():
    out = products.ubo_graph("CUST-1004")
    assert out["answerable"] is False
    assert ownership_tree("CUST-1004")["cycles"]


def test_ubo_computes_effective_percentage_through_chain():
    tree = ownership_tree("CUST-1001")
    owners = {o["owner_id"]: o["effective_percentage"] for o in tree["owners"]}
    # 55% of Helios x 62% of ABC = 34.1%
    assert abs(owners["PER-CKY"] - 34.1) < 0.01


def test_high_materiality_change_requires_human():
    events = products.change_events("CUST-1001")["data"]["events"]
    kinds = {e["change_type"]: e for e in events}
    assert kinds["registry_status_change"]["autonomy"] == "human_decision"
    assert kinds["director_change"]["autonomy"] == "client_confirm"


def test_policy_denies_marketing_purpose():
    with pytest.raises(policy.PolicyDenied):
        policy.check_purpose("marketing", "marketing")


def test_rm_redaction_leaves_receipt():
    pack = products.kyb_pack("CUST-1001")
    body, removed, receipt = policy.apply(pack["data"], "rm")
    assert removed and len(receipt) == 64
    assert "[redacted:policy]" in str(body)


def test_replay_is_read_only_and_moves_links():
    before = db.q1("SELECT COUNT(*) c FROM link_decision")["c"]
    out = replay.replay(auto_link_at=0.60, review_at=0.40)
    assert db.q1("SELECT COUNT(*) c FROM link_decision")["c"] == before
    assert out["projected"]["auto_link"] >= out["baseline"]["auto_link"]


def test_time_travel_returns_pre_override_decision():
    original = resolution.link_as_of("ext_acra_003")
    t0 = db.now()
    resolution.override("ext_acra_003", "CUST-1003", "s.mehta", "confirmed against ACRA extract")
    current = resolution.link_as_of("ext_acra_003")
    assert current["decided_by"].startswith("steward:")
    past = resolution.link_as_of("ext_acra_003", as_of=t0)
    assert past["decision_id"] == original["decision_id"]


def test_communities_are_deterministic():
    assert communities() == communities()
