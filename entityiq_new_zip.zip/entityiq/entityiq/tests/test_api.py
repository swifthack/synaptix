import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("EIQ_DB", os.path.join(tempfile.gettempdir(), "eiq_api_test.db"))

import pytest
from fastapi.testclient import TestClient

from app.api import app

client = TestClient(app)


@pytest.fixture(scope="module", autouse=True)
def seeded():
    client.post("/v1/admin/seed")


def test_health():
    assert client.get("/health").json()["status"] == "ok"


def test_kyb_pack_served_to_kyc_role():
    body = client.get("/v1/products/kyb-pack/CUST-1001",
                      headers={"x-api-key": "demo-kyc-key"}).json()
    assert body["answerable"] is True
    assert body["data"]["legal_identity"]["customer_id"] == "CUST-1001"
    assert body["policy"]["receipt"]


def test_marketing_purpose_is_refused():
    r = client.get("/v1/products/kyb-pack/CUST-1001?purpose=marketing",
                   headers={"x-api-key": "demo-marketing-key"})
    assert r.status_code == 403
    assert r.json()["rule"] == "purpose_binding"


def test_swiss_record_blocked_for_rm():
    r = client.get("/v1/products/kyb-pack/CUST-1005?purpose=servicing",
                   headers={"x-api-key": "demo-rm-key"})
    assert r.status_code == 403
    assert r.json()["rule"] == "jurisdiction_control"


def test_abstention_is_200_with_remediation():
    r = client.get("/v1/products/screening-bundle/CUST-1005?purpose=screening",
                   headers={"x-api-key": "demo-kyc-key"})
    assert r.status_code == 200
    assert r.json()["answerable"] is False
    assert r.json()["sufficiency"]["remediation"]


def test_mcp_tools_list():
    r = client.post("/mcp", json={"method": "tools/list", "id": 7},
                    headers={"x-api-key": "demo-agent-key"})
    names = [t["name"] for t in r.json()["result"]["tools"]]
    assert "get_kyb_pack" in names and "get_ubo_graph" in names


def test_mcp_call_returns_structured_envelope():
    r = client.post("/mcp", json={"method": "tools/call", "id": 8,
                                  "params": {"name": "get_kyb_pack",
                                             "arguments": {"customer_id": "CUST-1001"}}},
                    headers={"x-api-key": "demo-agent-key"})
    res = r.json()["result"]["structuredContent"]
    assert res["product"] == "kyb_pack" and res["answerable"] is True


def test_agent_card_declares_abstention():
    card = client.get("/.well-known/agent.json").json()
    assert card["capabilities"]["abstains"] is True
    assert len(card["skills"]) >= 6


def test_a2a_task_returns_input_required_on_gap():
    r = client.post("/a2a/tasks",
                    json={"skill": "get_screening_bundle", "args": {"customer_id": "CUST-1005"}},
                    headers={"x-api-key": "demo-agent-key"})
    assert r.json()["state"] == "input-required"
    assert r.json()["required_input"]


def test_agent_tool_allowlist_is_enforced():
    r = client.post("/v1/agents/ask",
                    json={"agent": "risk", "question": "find connections between them",
                          "args": {"customer_id": "CUST-1001", "other_id": "CUST-1002"}},
                    headers={"x-api-key": "demo-agent-key"})
    assert r.status_code == 403


def test_replay_endpoint_is_read_only():
    body = client.post("/v1/resolution/replay",
                       json={"auto_link_at": 0.7, "review_at": 0.5}).json()
    assert body["moved_count"] >= 0
    assert "Read-only" in body["note"]


def test_access_log_records_redactions():
    client.get("/v1/products/kyb-pack/CUST-1001?purpose=servicing",
               headers={"x-api-key": "demo-rm-key"})
    items = client.get("/v1/governance/access-log").json()["items"]
    assert any(i["consumer"] == "rm-cockpit" for i in items)
