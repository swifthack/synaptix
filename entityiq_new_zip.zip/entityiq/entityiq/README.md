# EntityIQ

Entity resolution, evidence and decision products for corporate banking.
Deterministic core, agent-accessible surface, and an API that abstains when the
evidence is thin.

Runs locally with one command and no external services: SQLite, no graph server,
no vector database, no model provider required.

```bash
./run.sh                       # venv, install, seed, serve on :8000
# or
make install && make seed && make run
# or
docker compose up --build
```

| Surface | URL |
|---|---|
| Steward console | http://127.0.0.1:8000/ |
| OpenAPI / Swagger | http://127.0.0.1:8000/docs |
| MCP endpoint (agents) | `POST http://127.0.0.1:8000/mcp` |
| MCP manifest (readable) | http://127.0.0.1:8000/mcp/tools |
| A2A agent card | http://127.0.0.1:8000/.well-known/agent.json |
| Integration walkthrough | `python examples/consumer_demo.py` |
| Tests | `make test` (30 tests) |

---

## The problem this build takes seriously

The slide deck describes a platform that acquires and stores data but does not
decide. Every team that attempts this arrives at the same architecture -
normalize, block, score, link, publish products, put agents on top - and most of
them ship something that a second line of defence will not sign off on, for
three reasons:

1. **The score cannot be defended.** A model somewhere in the chain produced a
   number nobody can reproduce twelve months later.
2. **The product cannot distinguish absence from evidence.** "No adverse media
   found" and "adverse media was never checked" serialize to the same JSON, and
   a downstream agent reports the first.
3. **The threshold cannot be changed.** Nobody can say what moving auto-link
   from 0.92 to 0.88 would do, so it never moves.

This implementation is organised around fixing those three, and the agent layer
sits on top of the result rather than in the middle of it.

## Six things here that are not in the standard build

**1. A bitemporal resolution ledger, not a link table.**
Every decision stores its full feature vector, the rules that fired, the
scorecard version and two clocks. Nothing is updated in place; a steward
override supersedes the engine row and both survive. Any product endpoint takes
`?as_of=<timestamp>` and reconstructs exactly what the bank knew at that moment.

```bash
curl "localhost:8000/v1/resolution/ext_acra_003?as_of=2026-08-01T00:00:00+00:00"
```

**2. Counterfactual replay.**
Because the feature vectors are stored, the whole book can be re-derived under a
hypothetical scorecard without re-fetching a single source record.

```bash
curl -XPOST localhost:8000/v1/resolution/replay \
  -H 'content-type: application/json' \
  -d '{"auto_link_at":0.88,"review_at":0.75}'
curl localhost:8000/v1/resolution/replay/sweep
```

Returns every link that would move, in which direction, with its explanation.
Read-only by construction. This turns a threshold change from an act of faith
into a reviewable diff.

**3. Abstention as a first-class API response.**
Every product computes evidence sufficiency before answering. Below the floor it
returns `answerable: false`, a null payload, and machine-readable remediation.

```bash
curl "localhost:8000/v1/products/screening-bundle/CUST-1005?purpose=screening" \
  -H "x-api-key: demo-kyc-key"
```

```json
{"answerable": false,
 "sufficiency": {"score": 0.0, "floor": 0.6,
   "remediation": [{"missing": "sanctions_check", "action": "run screening against the sanctions feed for this entity"}]}}
```

The UBO product does the same when it detects a circular shareholding: a nominee
loop returns "a human must confirm the ultimate parent", not a fabricated
percentage. This is the single most important property for agent safety, and it
belongs in the data layer, not in a prompt.

**4. A tamper-evident evidence chain.**
Evidence entries are append-only and hash-linked. `GET
/v1/governance/evidence/verify` recomputes the chain and names the first broken
entry. An auditor can verify a bundle without trusting the database.

**5. Policy enforced at serialization, with a receipt.**
Purpose binding, field-level entitlements and jurisdiction rules run over the
response body on the way out. The caller receives a SHA-256 receipt of exactly
what was withheld, under which rule, and it is logged.

```bash
curl "localhost:8000/v1/products/kyb-pack/CUST-1001?purpose=marketing" \
  -H "x-api-key: demo-marketing-key"          # 403 purpose_binding
curl "localhost:8000/v1/products/kyb-pack/CUST-1005?purpose=servicing" \
  -H "x-api-key: demo-rm-key"                 # 403 jurisdiction_control (CH)
```

**6. Deltas carry materiality, impact and autonomy.**
A change is not an alert. Each delta resolves through an impact graph to the
domains it touches and the autonomy it permits: `automate`, `client_confirm`, or
`human_decision`. An inference never changes an entitlement on its own.

```bash
curl localhost:8000/v1/impact-graph
curl "localhost:8000/v1/products/change-events?customer_id=CUST-1001&purpose=monitoring" \
  -H "x-api-key: demo-credit-key"
```

---

## Where the language model is, and is not

| Stage | Who decides |
|---|---|
| Normalization, blocking, candidate generation | Deterministic code |
| Deterministic rules (registration / LEI / tax id) | Deterministic code |
| Probabilistic score | Versioned weighted scorecard - **no model** |
| Auto-link / review / no-match | Threshold - **no model** |
| Explanation | Generated from the feature vector |
| Narration of an explanation | Model, marked `authoritative: false` |
| Intent routing for a natural-language request | Model, validated against an allowlist |
| Entitlement, limit, or status change | Human or deterministic policy - **never a model** |

With `EIQ_LLM_PROVIDER=none` (the default) the platform is fully functional. The
agent layer degrades to a rule-based intent router and everything else is
unchanged - which is the point: the agents are an interface, not the engine.

## Agents on rails

Four agents (`orchestrator`, `kyc`, `risk`, `investigation`), each with a tool
allowlist scoped to its role. The runtime enforces three things that prompt text
cannot:

- an agent cannot call a tool outside its allowlist, whatever it decides to do
- when a product abstains, the runtime stops and surfaces the gap rather than
  letting the agent narrate around it
- every step, its arguments and the evidence head at call time are traced back
  to the caller

```bash
curl -XPOST localhost:8000/v1/agents/ask -H 'content-type: application/json' \
  -H 'x-api-key: demo-agent-key' \
  -d '{"agent":"kyc","question":"what changed for CUST-1001 since last review?"}'
```

## Consuming from another app or agent

Three doors, one core, identical policy on all of them.

**REST** - services and back ends. OpenAPI at `/docs`.

**MCP** - any MCP-capable client. Point it at `POST /mcp` with an `x-api-key`
header. Tool descriptions are written for a model and state the abstention
contract explicitly.

```json
{"mcpServers": {"entityiq": {"url": "http://127.0.0.1:8000/mcp",
                             "headers": {"x-api-key": "demo-agent-key"}}}}
```

**A2A** - another team's agent discovers capability from
`/.well-known/agent.json` and submits typed tasks to `/a2a/tasks`. The card
advertises `"abstains": true`; a task that cannot be answered returns state
`input-required` with the list of what to acquire, which is the correct
machine-to-machine contract for missing evidence.

Demo keys map to policy roles: `demo-kyc-key`, `demo-credit-key`, `demo-rm-key`,
`demo-agent-key`, `demo-marketing-key`.

---

## Demo book

Seeded to exercise the hard cases, not the happy path.

| Subject | What it demonstrates |
|---|---|
| CUST-1001 | Registration-number match, auto-linked at 1.0; later dissolved by a registry refresh, producing a high-materiality delta routed to `human_decision` |
| CUST-1002 | Fuzzy match only - reordered name, no shared identifier |
| CUST-1003 | Two internal entities within 0.02 of each other; the engine refuses to auto-link an ambiguous top-two and forces review |
| CUST-1004 | Circular shareholding through nominees; the UBO product abstains |
| CUST-1005 | No screening evidence at all; the screening product abstains. Also a Swiss record, blocked for the RM role by jurisdiction control |

## Layout

```
app/
  config.py       versioned scorecard, thresholds, sufficiency floor
  db.py           bitemporal SQLite schema
  normalize.py    name / id / address normalization, blocking keys
  similarity.py   Jaro-Winkler, token set, date proximity - pinned, no deps
  resolution.py   candidate generation, rules, scoring, decisioning, ledger
  evidence.py     append-only hash chain
  graph.py        knowledge graph, ownership traversal, communities
  policy.py       purpose binding, field redaction, receipts
  products.py     KYB pack, screening, UBO, evidence bundle, change events
  delta.py        change detection, impact graph, materiality, autonomy
  replay.py       counterfactual threshold replay
  agents.py       tool registry, allowlists, abstention guardrail
  llm.py          pluggable provider (none | anthropic | azure)
  mcp.py          MCP over HTTP
  a2a.py          agent card and task interface
  api.py          FastAPI app
web/index.html    steward console
```

To move to production scale, three seams are already in place: `GraphStore` in
`graph.py` swaps to Neo4j without touching callers, `db.py` holds the only SQL,
and `llm.py` is the sole model boundary.

## Traceability to the deck

| Slide | Implementation |
|---|---|
| Normalization Engine | `normalize.py` - name, id, address, blocking keys |
| Internal Match Index | `match_index` table; identifiers only, no profile or financial data |
| Entity Resolution Core | `resolution.py` - candidates, deterministic rules, probabilistic scoring, decision, explanation |
| Resolution Thresholds 0.92 / 0.78 | `config.Scorecard`, versioned and replayable |
| Link & Evidence Store | `link_decision` + `evidence`; no raw payloads, digests only |
| Change Detection & Eventing | `delta.py` with the impact graph |
| Policy Engine | `policy.py` - purpose binding, field-level, jurisdiction |
| Standardized Products | `products.py` - all five, each evidence-gated |
| Knowledge Graph | `graph.py` - Organization / Person / Document, OWNS / DIRECTS / SUBSIDIARY_OF / MENTIONS |
| GraphRAG community detection | `graph.communities` - deterministic label propagation |
| Hybrid retrieval | Graph traversal and keyword paths implemented; vector search is the documented extension point |
| Agentic AI Layer | `agents.py` - orchestrator, KYC, risk, investigation, on allowlists |
| Journey Aggregator | `api.py` product routes plus MCP and A2A surfaces |

## Configuration

Copy `.env.example` to `.env`. The knobs that matter:

- `EIQ_AUTO_LINK_AT`, `EIQ_REVIEW_AT` - thresholds. Bump
  `EIQ_SCORECARD_VERSION` whenever either changes; past decisions keep their own
  version so they stay reproducible.
- `EIQ_SUFFICIENCY_FLOOR` - how much evidence coverage a product needs before it
  will answer.
- `EIQ_LLM_PROVIDER` - `none`, `anthropic`, or `azure`. Narration and intent
  routing only.
