"""Model Context Protocol surface (JSON-RPC 2.0 over HTTP).

Any MCP-capable client - Claude, an internal agent mesh, another bank system -
points at POST /mcp and gets the same tools the REST API exposes, with the same
policy enforcement and the same abstention behaviour.

The tool descriptions are written for a model, not for a developer: each one
states what the tool will refuse to do, because that is the information an agent
needs to plan around. A tool that can return `answerable: false` must say so, or
the agent will treat an abstention as an empty result.
"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from . import policy
from .agents import TOOLS
from .config import settings

mcp_router = APIRouter(tags=["mcp"])

ROLE_BY_KEY = {
    "demo-kyc-key": "kyc_analyst",
    "demo-credit-key": "credit_officer",
    "demo-agent-key": "agent",
    "demo-rm-key": "rm",
}

PURPOSE_BY_TOOL = {
    "get_kyb_pack": "onboarding",
    "get_screening_bundle": "screening",
    "get_ubo_graph": "onboarding",
    "get_evidence_bundle": "investigation",
    "get_change_events": "monitoring",
    "find_connections": "investigation",
    "get_group_exposure": "credit_assessment",
    "resolve_record": "onboarding",
}

_JSON_TYPE = {"str": "string", "str?": "string", "int": "integer", "float": "number"}


def _schema(args: dict[str, str]) -> dict:
    props = {k: {"type": _JSON_TYPE.get(v, "string")} for k, v in args.items()}
    required = [k for k, v in args.items() if not v.endswith("?")]
    return {"type": "object", "properties": props, "required": required}


def tool_manifest() -> list[dict]:
    out = []
    for name, spec in TOOLS.items():
        out.append({
            "name": name,
            "description": (
                f"{spec['description']} Returns an envelope with `answerable`. "
                "When `answerable` is false the payload is null and `sufficiency.remediation` "
                "lists what must be acquired first - do not infer a result from an abstention. "
                "Fields removed by policy appear as '[redacted:policy]'."),
            "inputSchema": _schema(spec["args"]),
        })
    return out


class RPC(BaseModel):
    jsonrpc: str = "2.0"
    id: Any = 1
    method: str
    params: dict = {}


@mcp_router.post("/mcp")
def mcp(req: RPC, x_api_key: str = Header(default="demo-agent-key")):
    role = ROLE_BY_KEY.get(x_api_key)
    if role is None:
        raise HTTPException(401, "unknown api key")

    if req.method == "initialize":
        return {"jsonrpc": "2.0", "id": req.id, "result": {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": "entityiq", "version": settings.version}}}

    if req.method in ("tools/list", "listTools"):
        return {"jsonrpc": "2.0", "id": req.id, "result": {"tools": tool_manifest()}}

    if req.method in ("tools/call", "callTool"):
        name = req.params.get("name")
        args = req.params.get("arguments", {}) or {}
        if name not in TOOLS:
            return _err(req.id, -32601, f"unknown tool '{name}'")
        purpose = PURPOSE_BY_TOOL.get(name, "investigation")
        try:
            policy.check_purpose(role, purpose)
        except policy.PolicyDenied as e:
            return _err(req.id, -32001, f"{e.rule}: {e.reason}")
        try:
            envelope = TOOLS[name]["fn"](**args)
        except TypeError as e:
            return _err(req.id, -32602, f"bad arguments: {e}")
        redacted, removed, receipt = policy.apply(envelope.get("data") or {}, role)
        policy.log_access(consumer=f"mcp:{role}", purpose=purpose, product=name,
                          subject=args.get("customer_id"), answerable=envelope.get("answerable", True),
                          redactions=removed, receipt=receipt)
        payload = {**envelope, "data": redacted if envelope.get("answerable") else None,
                   "policy": {"role": role, "redacted_paths": removed, "receipt": receipt}}
        import json as _j
        return {"jsonrpc": "2.0", "id": req.id, "result": {
            "content": [{"type": "text", "text": _j.dumps(payload, default=str)}],
            "isError": not envelope.get("answerable", True),
            "structuredContent": payload}}

    return _err(req.id, -32601, f"unsupported method '{req.method}'")


def _err(rid, code, message):
    return {"jsonrpc": "2.0", "id": rid, "error": {"code": code, "message": message}}


@mcp_router.get("/mcp/tools")
def tools_readable():
    """Human-readable mirror of the manifest, for wiring things up."""
    return {"tools": tool_manifest(), "endpoint": "POST /mcp",
            "auth": "x-api-key header", "protocol": "JSON-RPC 2.0 / MCP 2024-11-05"}
