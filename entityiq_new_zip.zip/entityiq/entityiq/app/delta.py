"""Change detection, impact mapping and autonomy routing.

A change on its own is noise. What a bank needs is the triple:

    Delta  ->  Impact (what this touches)  ->  Autonomy (who is allowed to act)

Materiality decides autonomy. Low materiality is automated; medium goes back to
the client as a confirmation ("has this changed?"); high goes to a human
decision-maker. An inference never changes an entitlement on its own - the
observation/interpretation/decision/action boundary is enforced in code by
keeping `state` separate from `actions`.
"""
from __future__ import annotations

import json
import uuid

from . import db, evidence

# change_type -> (materiality, impacted domains, suggested actions)
IMPACT_GRAPH = {
    "registry_status_change": ("high",
        ["kyb", "credit_mandate", "product_eligibility", "payment_authority", "risk_rating"],
        ["freeze_new_facilities", "notify_credit", "notify_rm", "open_review_case"]),
    "director_change": ("medium",
        ["kyb", "kyc", "signing_authority", "payment_authority"],
        ["trigger_kyc_review", "revalidate_signatories", "client_confirmation"]),
    "ubo_change": ("high",
        ["kyc", "ubo", "group_exposure", "sanctions_exposure", "risk_rating"],
        ["update_group_exposure", "rescreen_new_owners", "notify_compliance"]),
    "sanctions_hit": ("high",
        ["screening", "payment_authority", "product_eligibility"],
        ["block_payments", "escalate_compliance", "open_investigation"]),
    "address_change": ("low",
        ["kyb", "servicing"],
        ["update_record", "client_confirmation"]),
    "name_change": ("medium",
        ["kyb", "kyc", "documentation", "screening"],
        ["rescreen_entity", "client_confirmation", "update_documents"]),
    "lei_change": ("low", ["reference_data", "reporting"], ["update_record"]),
    "shareholding_percentage_change": ("medium",
        ["ubo", "group_exposure"], ["recompute_ubo", "notify_credit"]),
}

AUTONOMY = {"low": "automate", "medium": "client_confirm", "high": "human_decision"}

WATCHED_FIELDS = {
    "status": "registry_status_change",
    "legal_name": "name_change",
    "address": "address_change",
    "lei": "lei_change",
}


def raise_delta(subject: str, change_type: str, before, after, evidence_id: str | None = None) -> dict:
    materiality, impacts, actions = IMPACT_GRAPH.get(
        change_type, ("medium", ["unclassified"], ["human_triage"]))
    did = f"dlt_{uuid.uuid4().hex[:12]}"
    with db.tx() as conn:
        conn.execute(
            """INSERT INTO delta (delta_id, subject, change_type, before, after, materiality,
                 autonomy, impacts, actions, evidence_id, state, detected_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,'open',?)""",
            (did, subject, change_type, json.dumps(before), json.dumps(after), materiality,
             AUTONOMY[materiality], json.dumps(impacts), json.dumps(actions), evidence_id, db.now()))
    return get_delta(did)


def detect_from_records(record_id: str, new_rec: dict, old_rec: dict | None) -> list[dict]:
    """Compare a freshly retrieved external record with the previous version."""
    if not old_rec:
        return []
    out = []
    for field, change_type in WATCHED_FIELDS.items():
        before, after = old_rec.get(field), new_rec.get(field)
        if before and after and str(before).strip() != str(after).strip():
            if field == "status" and str(after).lower() in {"dissolved", "struck_off", "liquidation"}:
                change_type = "registry_status_change"
            ev = evidence.record(
                subject=record_id, kind="change_observation", source=new_rec.get("source", "external"),
                claim={"field": field, "before": before, "after": after},
                confidence=0.95, observed_at=db.now())
            out.append(raise_delta(record_id, change_type, before, after, ev))

    old_off = set(json.loads(old_rec.get("officers") or "[]") if isinstance(old_rec.get("officers"), str)
                  else old_rec.get("officers") or [])
    new_off = set(new_rec.get("officers") or [])
    if old_off != new_off:
        ev = evidence.record(subject=record_id, kind="change_observation",
                             source=new_rec.get("source", "external"),
                             claim={"field": "officers", "added": sorted(new_off - old_off),
                                    "removed": sorted(old_off - new_off)},
                             confidence=0.95, observed_at=db.now())
        out.append(raise_delta(record_id, "director_change",
                               sorted(old_off), sorted(new_off), ev))
    return out


def get_delta(delta_id: str) -> dict | None:
    r = db.q1("SELECT * FROM delta WHERE delta_id=?", (delta_id,))
    return _row(r) if r else None


def _row(r) -> dict:
    return {"delta_id": r["delta_id"], "subject": r["subject"], "change_type": r["change_type"],
            "before": json.loads(r["before"]) if r["before"] else None,
            "after": json.loads(r["after"]) if r["after"] else None,
            "materiality": r["materiality"], "autonomy": r["autonomy"],
            "impacts": json.loads(r["impacts"]), "suggested_actions": json.loads(r["actions"]),
            "evidence_id": r["evidence_id"], "state": r["state"],
            "detected_at": r["detected_at"], "closed_at": r["closed_at"]}


def list_deltas(subject: str | None = None, since: str | None = None, state: str | None = None) -> list[dict]:
    sql, args = "SELECT * FROM delta WHERE 1=1", ()
    if subject:
        # a delta on a linked external record belongs to the resolved customer too
        from .resolution import links_for_customer
        subjects = [subject] + [l["record_id"] for l in links_for_customer(subject)]
        sql += f" AND subject IN ({','.join('?' * len(subjects))})"
        args += tuple(subjects)
    if since:
        sql += " AND detected_at>=?"
        args += (since,)
    if state:
        sql += " AND state=?"
        args += (state,)
    return [_row(r) for r in db.q(sql + " ORDER BY detected_at DESC", args)]


def close_delta(delta_id: str, resolution_note: str, actor: str) -> dict:
    with db.tx() as conn:
        conn.execute("UPDATE delta SET state='closed', closed_at=? WHERE delta_id=?", (db.now(), delta_id))
    evidence.record(subject=delta_id, kind="delta_closure", source="entityiq",
                    claim={"actor": actor, "note": resolution_note}, confidence=1.0,
                    observed_at=db.now())
    return get_delta(delta_id)
