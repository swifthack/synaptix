"""Counterfactual replay.

Changing a matching threshold in a live bank is normally an act of faith: nobody
can say how many links flip until it ships. Because every decision stored its
full feature vector, EntityIQ can re-derive the outcome of the entire book under
a hypothetical scorecard without re-fetching a single source record.

Two uses:
  * `replay(...)`   before you change a threshold, see exactly which links move.
  * `sweep(...)`    plot review-queue volume against auto-link rate to pick one.

The stored decisions are never modified. Replay is read-only by construction.
"""
from __future__ import annotations

from dataclasses import replace

from . import db, resolution
from .config import settings


def _outcome(score: float, auto_at: float, review_at: float) -> str:
    if score >= auto_at:
        return resolution.AUTO
    if score >= review_at:
        return resolution.REVIEW
    return resolution.NONE


def replay(auto_link_at: float, review_at: float, reweight: dict | None = None) -> dict:
    """Re-derive outcomes for every current decision under a hypothetical scorecard."""
    rows = db.q("SELECT * FROM link_decision WHERE valid_to IS NULL")
    sc = settings.scorecard
    weights = sc.weights()
    if reweight:
        weights = {**weights, **reweight}
        total = sum(weights.values())
        weights = {k: v / total for k, v in weights.items()}

    moved, tally = [], {"auto_link": 0, "needs_review": 0, "no_match": 0}
    for r in rows:
        d = resolution._decision_row(r)
        if d["rule_hits"] and any(h.endswith("_match") for h in d["rule_hits"]):
            score = 1.0  # identifier agreement is threshold-independent
        elif reweight and d["features"]:
            score = round(sum(d["features"].get(k, 0.0) * w for k, w in weights.items()), 4)
        else:
            score = d["score"]
        new = _outcome(score, auto_link_at, review_at)
        tally[new] += 1
        if new != d["outcome"]:
            moved.append({"record_id": d["record_id"], "customer_id": d["customer_id"],
                          "from": d["outcome"], "to": new,
                          "old_score": d["score"], "new_score": score,
                          "explanation": d["explanation"]})
    baseline = {"auto_link": 0, "needs_review": 0, "no_match": 0}
    for r in rows:
        baseline[r["outcome"]] += 1
    return {
        "hypothesis": {"auto_link_at": auto_link_at, "review_at": review_at,
                       "reweight": reweight or {}},
        "current_scorecard": sc.version,
        "population": len(rows),
        "baseline": baseline,
        "projected": tally,
        "moved_count": len(moved),
        "moved": moved[:200],
        "note": "Read-only projection. No stored decision was modified.",
    }


def sweep(review_at: float | None = None, steps: int = 11) -> dict:
    """Auto-link rate and review volume across candidate auto-link thresholds."""
    review_at = review_at if review_at is not None else settings.scorecard.review_at
    points = []
    for i in range(steps):
        auto = round(review_at + (1.0 - review_at) * i / max(steps - 1, 1), 4)
        r = replay(auto, review_at)
        points.append({"auto_link_at": auto, **r["projected"], "moved": r["moved_count"]})
    return {"review_at": review_at, "points": points,
            "guidance": "Pick the point where review volume matches steward capacity, "
                        "then bump the scorecard version before applying it."}
