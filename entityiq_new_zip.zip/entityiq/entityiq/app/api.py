"""HTTP surface.

Three ways in, one core:

  /v1/...            REST for humans and services (OpenAPI at /docs)
  /mcp               Model Context Protocol, for LLM agents (see mcp.py)
  /a2a/...           Agent-to-agent task interface with a published agent card

They all funnel through the same product functions, so an agent cannot reach a
capability a service could not, and every route emits the same envelope:
answerable / sufficiency / policy_receipt / evidence_head.
"""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import db, delta, evidence, graph, policy, products, replay, resolution, seed
from .config import settings

# API key -> (consumer name, policy role)
CONSUMERS = {
    "demo-kyc-key": ("onboarding-service", "kyc_analyst"),
    "demo-credit-key": ("credit-engine", "credit_officer"),
    "demo-agent-key": ("agent-mesh", "agent"),
    "demo-rm-key": ("rm-cockpit", "rm"),
    "demo-marketing-key": ("campaign-tool", "marketing"),
}


def caller(x_api_key: str = Header(default="demo-agent-key")) -> tuple[str, str]:
    if x_api_key not in CONSUMERS:
        raise HTTPException(401, "unknown api key")
    return CONSUMERS[x_api_key]


router = APIRouter(prefix="/v1")


# ------------------------------------------------------------------- schemas
class InternalEntity(BaseModel):
    customer_id: str
    legal_name: str
    jurisdiction: str | None = None
    registration_no: str | None = None
    lei: str | None = None
    tax_id: str | None = None
    incorporated_on: str | None = None
    address: str | None = None
    aliases: list[str] = []
    officers: list[str] = []
    source_system: str = "core"


class ExternalRecord(BaseModel):
    record_id: str | None = None
    source: str
    source_ref: str | None = None
    legal_name: str
    jurisdiction: str | None = None
    registration_no: str | None = None
    lei: str | None = None
    status: str | None = None
    incorporated_on: str | None = None
    address: str | None = None
    aliases: list[str] = []
    officers: list[str] = []


class OverrideIn(BaseModel):
    customer_id: str | None = None
    steward: str
    rationale: str = Field(min_length=5)


class ReplayIn(BaseModel):
    auto_link_at: float = Field(ge=0, le=1)
    review_at: float = Field(ge=0, le=1)
    reweight: dict[str, float] | None = None


class AgentAsk(BaseModel):
    agent: str = "orchestrator"
    question: str
    args: dict = {}


# --------------------------------------------------------------------- ingest
@router.post("/entities", tags=["ingest"])
def add_internal(e: InternalEntity):
    return {"customer_id": resolution.upsert_internal(e.model_dump())}


@router.post("/records", tags=["ingest"])
def add_external(r: ExternalRecord, resolve_now: bool = True):
    prev = None
    if r.record_id:
        row = db.q1("SELECT * FROM external_record WHERE record_id=?", (r.record_id,))
        prev = dict(row) if row else None
    rid = resolution.ingest_external(r.model_dump())
    deltas = delta.detect_from_records(rid, r.model_dump(), prev)
    out = {"record_id": rid, "deltas": deltas}
    if resolve_now:
        out["resolution"] = resolution.resolve(rid)
    return out


# ----------------------------------------------------------------- resolution
@router.post("/resolve/{record_id}", tags=["resolution"])
def do_resolve(record_id: str):
    try:
        return resolution.resolve(record_id)
    except KeyError:
        raise HTTPException(404, f"no external record {record_id}")


@router.get("/resolution/review-queue", tags=["resolution"])
def queue():
    return {"items": resolution.review_queue()}


@router.post("/resolution/{record_id}/override", tags=["resolution"])
def do_override(record_id: str, body: OverrideIn):
    return resolution.override(record_id, body.customer_id, body.steward, body.rationale)


@router.get("/resolution/{record_id}", tags=["resolution"])
def get_link(record_id: str, as_of: str | None = Query(None, description="ISO timestamp for time travel")):
    link = resolution.link_as_of(record_id, as_of)
    if not link:
        raise HTTPException(404, "no decision at that point in time")
    return link


@router.post("/resolution/replay", tags=["resolution"])
def do_replay(body: ReplayIn):
    return replay.replay(body.auto_link_at, body.review_at, body.reweight)


@router.get("/resolution/replay/sweep", tags=["resolution"])
def do_sweep(review_at: float | None = None):
    return replay.sweep(review_at)


# ------------------------------------------------------------------- products
def _serve(product: str, subject: str | None, fn, who, purpose: str, as_of: str | None):
    consumer, role = who
    try:
        policy.check_purpose(role, purpose)
        if subject:
            row = db.q1("SELECT jurisdiction FROM internal_entity WHERE customer_id=?", (subject,))
            if row:
                policy.check_jurisdiction(role, row["jurisdiction"])
    except policy.PolicyDenied as e:
        policy.log_access(consumer=consumer, purpose=purpose, product=product, subject=subject,
                          answerable=False, redactions=["*"], receipt="denied")
        return JSONResponse(status_code=403, content={
            "product": product, "answerable": False, "reason": "policy_denied",
            "rule": e.rule, "detail": e.reason})

    envelope = fn()
    redacted, removed, receipt = policy.apply(envelope.get("data") or {}, role)
    policy.log_access(consumer=consumer, purpose=purpose, product=product, subject=subject,
                      answerable=envelope["answerable"], redactions=removed, receipt=receipt)
    envelope["data"] = redacted if envelope["answerable"] else None
    envelope["policy"] = {"role": role, "purpose": purpose, "redacted_paths": removed,
                          "receipt": receipt}
    status = 200 if envelope["answerable"] else 200  # abstention is a valid answer, not an error
    return JSONResponse(status_code=status, content=envelope)


@router.get("/products/kyb-pack/{customer_id}", tags=["products"])
def kyb(customer_id: str, purpose: str = "onboarding", as_of: str | None = None, who=Depends(caller)):
    return _serve("kyb_pack", customer_id, lambda: products.kyb_pack(customer_id, as_of), who, purpose, as_of)


@router.get("/products/screening-bundle/{customer_id}", tags=["products"])
def screening(customer_id: str, purpose: str = "screening", as_of: str | None = None, who=Depends(caller)):
    return _serve("screening_bundle", customer_id, lambda: products.screening_bundle(customer_id, as_of),
                  who, purpose, as_of)


@router.get("/products/ubo-graph/{customer_id}", tags=["products"])
def ubo(customer_id: str, purpose: str = "onboarding", as_of: str | None = None, who=Depends(caller)):
    return _serve("ubo_graph", customer_id, lambda: products.ubo_graph(customer_id, as_of), who, purpose, as_of)


@router.get("/products/evidence-bundle/{customer_id}", tags=["products"])
def ev_bundle(customer_id: str, purpose: str = "investigation", as_of: str | None = None, who=Depends(caller)):
    return _serve("evidence_bundle", customer_id, lambda: products.evidence_bundle(customer_id, as_of),
                  who, purpose, as_of)


@router.get("/products/change-events", tags=["products"])
def changes(customer_id: str | None = None, since: str | None = None,
            purpose: str = "monitoring", who=Depends(caller)):
    return _serve("change_events", customer_id, lambda: products.change_events(customer_id, since),
                  who, purpose, since)


# ---------------------------------------------------------------------- graph
@router.get("/graph/ownership/{customer_id}", tags=["graph"])
def ownership(customer_id: str, as_of: str | None = None):
    return graph.ownership_tree(customer_id, as_of)


@router.get("/graph/communities", tags=["graph"])
def comms(as_of: str | None = None):
    return graph.communities(as_of)


@router.get("/graph/connections", tags=["graph"])
def conn(a: str, b: str, max_depth: int = 5, as_of: str | None = None):
    return graph.connections(a, b, max_depth, as_of)


# --------------------------------------------------------------------- deltas
@router.get("/deltas", tags=["change"])
def list_deltas(subject: str | None = None, since: str | None = None, state: str | None = None):
    return {"items": delta.list_deltas(subject, since, state)}


@router.post("/deltas/{delta_id}/close", tags=["change"])
def close_delta(delta_id: str, note: str, actor: str):
    d = delta.close_delta(delta_id, note, actor)
    if not d:
        raise HTTPException(404, "no such delta")
    return d


@router.get("/impact-graph", tags=["change"])
def impact_graph():
    return {"map": {k: {"materiality": v[0], "impacts": v[1], "actions": v[2],
                        "autonomy": delta.AUTONOMY[v[0]]}
                    for k, v in delta.IMPACT_GRAPH.items()}}


# ---------------------------------------------------------------- governance
@router.get("/governance/evidence/verify", tags=["governance"])
def verify_chain():
    return evidence.verify()


@router.get("/governance/access-log", tags=["governance"])
def access_log(limit: int = 50):
    return {"items": policy.recent_access(limit)}


@router.get("/governance/scorecard", tags=["governance"])
def scorecard():
    return {"version": settings.scorecard.version,
            "auto_link_at": settings.scorecard.auto_link_at,
            "review_at": settings.scorecard.review_at,
            "weights": settings.scorecard.weights(),
            "sufficiency_floor": settings.sufficiency_floor}


# ------------------------------------------------------------------- agents
@router.get("/agents", tags=["agents"])
def list_agents():
    from .agents import AGENTS, TOOLS
    return {"agents": {k: {**v, "tool_specs": {t: TOOLS[t]["description"] for t in v["tools"]}}
                       for k, v in AGENTS.items()}}


@router.post("/agents/ask", tags=["agents"])
def ask(body: AgentAsk, who=Depends(caller)):
    from .agents import ToolDenied, run
    try:
        return run(body.agent, body.question, body.args, consumer=who[0])
    except KeyError:
        raise HTTPException(404, f"no agent '{body.agent}'")
    except ToolDenied as e:
        raise HTTPException(403, str(e))
    except policy.PolicyDenied as e:
        raise HTTPException(403, f"{e.rule}: {e.reason}")


# --------------------------------------------------------------------- admin
@router.post("/admin/seed", tags=["admin"])
def do_seed(reset: bool = True):
    return seed.load(reset)


@router.get("/admin/stats", tags=["admin"])
def stats():
    counts = {t: db.q1(f"SELECT COUNT(*) c FROM {t}")["c"] for t in
              ("internal_entity", "external_record", "link_decision", "evidence", "node", "edge",
               "delta", "access_log")}
    by_outcome = {r["outcome"]: r["c"] for r in
                  db.q("SELECT outcome, COUNT(*) c FROM link_decision WHERE valid_to IS NULL GROUP BY outcome")}
    return {"counts": counts, "current_outcomes": by_outcome,
            "evidence_head": evidence.head(), "scorecard": settings.scorecard.version}


# ----------------------------------------------------------------------- app
def create_app() -> FastAPI:
    app = FastAPI(
        title="EntityIQ",
        version=settings.version,
        description="Entity resolution, evidence and decision products for corporate banking. "
                    "Deterministic core, agent-accessible surface, abstention when evidence is thin.",
    )
    app.include_router(router)

    from .mcp import mcp_router
    from .a2a import a2a_router
    app.include_router(mcp_router)
    app.include_router(a2a_router)

    @app.get("/health", tags=["admin"])
    def health():
        return {"status": "ok", "version": settings.version,
                "scorecard": settings.scorecard.version,
                "llm_provider": settings.llm_provider}

    web = Path(__file__).resolve().parent.parent / "web"
    if web.exists():
        app.mount("/console", StaticFiles(directory=str(web), html=True), name="console")

        @app.get("/", include_in_schema=False)
        def root():
            return FileResponse(str(web / "index.html"))

    return app


app = create_app()
