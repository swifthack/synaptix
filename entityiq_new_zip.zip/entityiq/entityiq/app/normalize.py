"""Normalization engine.

Turns messy registry text into comparable strings and into blocking keys, so
candidate generation touches tens of rows instead of the whole book.
"""
from __future__ import annotations

import re
import unicodedata

LEGAL_SUFFIXES = {
    "pte", "ltd", "limited", "llc", "inc", "incorporated", "corp", "corporation",
    "plc", "gmbh", "sa", "sarl", "bv", "nv", "ag", "spa", "srl", "pty", "co",
    "company", "holdings", "holding", "group", "llp", "lp", "kk", "ab", "oy",
    "as", "aps", "sdn", "bhd", "fzco", "fze", "dmcc", "pvt", "private",
}

_PUNCT = re.compile(r"[^\w\s]", re.UNICODE)
_WS = re.compile(r"\s+")

STREET_ABBR = {
    "street": "st", "road": "rd", "avenue": "ave", "boulevard": "blvd",
    "drive": "dr", "lane": "ln", "building": "bldg", "floor": "fl",
    "suite": "ste", "level": "lvl", "unit": "u", "number": "no",
}


def _fold(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(c for c in s if not unicodedata.combining(c))
    return s.lower()


def normalize_name(raw: str, keep_suffix: bool = False) -> str:
    """ABC CONSTRUCTION PTE. LTD. -> abc construction"""
    s = _PUNCT.sub(" ", _fold(raw))
    tokens = [t for t in _WS.sub(" ", s).strip().split(" ") if t]
    if not keep_suffix:
        stripped = [t for t in tokens if t not in LEGAL_SUFFIXES]
        tokens = stripped or tokens
    return " ".join(tokens)


def normalize_id(raw: str | None) -> str | None:
    """Registration / LEI / tax id -> uppercase alphanumeric."""
    if not raw:
        return None
    out = re.sub(r"[^A-Za-z0-9]", "", raw).upper()
    return out or None


def normalize_address(raw: str | None) -> str:
    if not raw:
        return ""
    s = _PUNCT.sub(" ", _fold(raw))
    tokens = [STREET_ABBR.get(t, t) for t in _WS.sub(" ", s).strip().split(" ") if t]
    return " ".join(tokens)


def city_token(address_norm: str) -> str:
    return address_norm.split()[-1] if address_norm else ""


def blocking_keys(rec: dict) -> list[tuple[str, str]]:
    """Return (key, kind) pairs. Any shared key makes two records candidates."""
    keys: list[tuple[str, str]] = []
    juris = (rec.get("jurisdiction") or "XX").upper()

    reg = normalize_id(rec.get("registration_no"))
    if reg:
        keys.append((f"reg_{juris}_{reg}", "registration"))
    lei = normalize_id(rec.get("lei"))
    if lei:
        keys.append((f"lei_{lei}", "lei"))
    tax = normalize_id(rec.get("tax_id"))
    if tax:
        keys.append((f"tax_{juris}_{tax}", "tax"))

    name = rec.get("normalized_name") or normalize_name(rec.get("legal_name", ""))
    addr = rec.get("normalized_addr") or normalize_address(rec.get("address"))
    if name:
        keys.append((f"namecity_{name.replace(' ', '_')}_{city_token(addr) or juris.lower()}", "name_city"))
        head = "_".join(name.split()[:2])
        keys.append((f"nameprefix_{juris}_{head}", "name_prefix"))
        # sorted-token key catches word reordering
        keys.append((f"nametok_{'_'.join(sorted(name.split()))}", "name_tokens"))
    for alias in rec.get("aliases") or []:
        na = normalize_name(alias)
        if na:
            keys.append((f"nametok_{'_'.join(sorted(na.split()))}", "alias_tokens"))
    return list(dict.fromkeys(keys))


def enrich(rec: dict) -> dict:
    """Attach normalized fields in place and return the record."""
    rec["normalized_name"] = normalize_name(rec.get("legal_name", ""))
    rec["normalized_addr"] = normalize_address(rec.get("address"))
    rec["registration_no"] = rec.get("registration_no")
    return rec
