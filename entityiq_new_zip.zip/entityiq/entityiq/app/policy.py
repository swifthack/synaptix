"""Policy engine - enforced at serialization, not at the query.

Most implementations check entitlements when a request arrives and then hand the
caller a full object. Here the policy runs over the *response body* on the way
out, field by field, and emits a redaction receipt: a hash of exactly what was
withheld, from whom, and under which rule. The receipt is returned to the caller
and logged, so "the RM never saw the source document" is a provable statement
rather than a design intention.

Purpose binding is checked first: data pulled for onboarding cannot be served to
a marketing purpose regardless of who is asking.
"""
from __future__ import annotations

import hashlib
import json

from . import db

# consumer role -> allowed purposes
ROLE_PURPOSES = {
    "kyc_analyst": {"onboarding", "periodic_review", "investigation", "screening"},
    "credit_officer": {"credit_assessment", "monitoring"},
    "compliance": {"investigation", "screening", "periodic_review"},
    "rm": {"servicing", "onboarding"},
    "agent": {"onboarding", "periodic_review", "credit_assessment", "investigation", "screening", "monitoring"},
    "marketing": {"marketing"},
}

# purposes that may never touch data acquired for regulatory purposes
FORBIDDEN_PURPOSES = {"marketing"}

# field path prefixes each role may not see
FIELD_DENY = {
    "rm": ["resolution[].features", "resolution[].score", "evidence_pointers",
           "entries[].payload_digest", "adverse_media[].claim", "source_documents"],
    "credit_officer": ["pep[].source_ref", "entries[].payload_digest", "source_documents"],
    "marketing": ["*"],
}

# jurisdiction -> roles that may receive records from it
JURISDICTION_RULES = {
    "CH": {"kyc_analyst", "compliance", "agent"},   # Swiss records: restricted set
    "SG": None,                                      # None = unrestricted
}


class PolicyDenied(Exception):
    def __init__(self, reason: str, rule: str):
        super().__init__(reason)
        self.reason, self.rule = reason, rule


def check_purpose(role: str, purpose: str) -> None:
    if purpose in FORBIDDEN_PURPOSES:
        raise PolicyDenied(f"purpose '{purpose}' cannot consume regulatory-sourced data", "purpose_binding")
    allowed = ROLE_PURPOSES.get(role)
    if allowed is None:
        raise PolicyDenied(f"unknown consumer role '{role}'", "role_unknown")
    if purpose not in allowed:
        raise PolicyDenied(f"role '{role}' is not bound to purpose '{purpose}'", "purpose_binding")


def check_jurisdiction(role: str, jurisdiction: str | None) -> None:
    if not jurisdiction:
        return
    allowed = JURISDICTION_RULES.get(jurisdiction.upper(), None)
    if allowed is not None and role not in allowed:
        raise PolicyDenied(
            f"records from {jurisdiction} are not releasable to role '{role}'", "jurisdiction_control")


def _matches(path: str, pattern: str) -> bool:
    if pattern == "*":
        return True
    return path == pattern or path.startswith(pattern + ".") or path.startswith(pattern + "[")


def apply(body: dict, role: str) -> tuple[dict, list[str], str]:
    """Redact `body` for `role`. Returns (redacted, removed_paths, receipt)."""
    deny = FIELD_DENY.get(role, [])
    removed: list[str] = []

    def walk(node, path):
        if any(_matches(path, p) for p in deny) and path:
            removed.append(path)
            return "[redacted:policy]"
        if isinstance(node, dict):
            return {k: walk(v, f"{path}.{k}" if path else k) for k, v in node.items()}
        if isinstance(node, list):
            base = f"{path}[]"
            if any(_matches(base, p) for p in deny):
                removed.append(base)
                return "[redacted:policy]"
            return [walk(v, base) for v in node]
        return node

    redacted = walk(body, "")
    receipt = hashlib.sha256(
        json.dumps({"role": role, "removed": sorted(set(removed)), "at": db.now()},
                   sort_keys=True).encode()).hexdigest()
    return redacted, sorted(set(removed)), receipt


def log_access(*, consumer: str, purpose: str, product: str, subject: str | None,
               answerable: bool, redactions: list[str], receipt: str) -> None:
    with db.tx() as conn:
        conn.execute(
            "INSERT INTO access_log (at, consumer, purpose, product, subject, answerable, redactions, receipt)"
            " VALUES (?,?,?,?,?,?,?,?)",
            (db.now(), consumer, purpose, product, subject, int(answerable),
             json.dumps(redactions), receipt))


def recent_access(limit: int = 50) -> list[dict]:
    return [dict(r) | {"redactions": json.loads(r["redactions"])}
            for r in db.q("SELECT * FROM access_log ORDER BY id DESC LIMIT ?", (limit,))]
