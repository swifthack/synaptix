"""Knowledge graph over SQLite, with a pluggable driver seam for Neo4j.

Kept dependency-free so the platform runs from a clone with no graph server.
`GraphStore` is the only surface the rest of the app touches; a Neo4jStore with
the same five methods drops in without touching callers.

Ownership traversal is the part worth reading: it multiplies percentages down
the chain, handles cycles (circular shareholdings are common in offshore
structures and naive traversals hang on them), and returns the evidence id for
every hop so a UBO figure can be defended edge by edge.
"""
from __future__ import annotations

import json
import uuid
from collections import defaultdict

from . import db


class GraphStore:
    def upsert_node(self, node_id: str, label: str, props: dict | None = None) -> str:
        with db.tx() as conn:
            conn.execute(
                """INSERT INTO node (node_id, label, props) VALUES (?,?,?)
                   ON CONFLICT(node_id) DO UPDATE SET label=excluded.label, props=excluded.props""",
                (node_id, label, json.dumps(props or {}, sort_keys=True)))
        return node_id

    def upsert_edge(self, src: str, dst: str, rel: str, props: dict | None = None,
                    evidence_id: str | None = None) -> str:
        eid = f"e_{uuid.uuid4().hex[:10]}"
        ts = db.now()
        with db.tx() as conn:
            conn.execute("UPDATE edge SET valid_to=? WHERE src=? AND dst=? AND rel=? AND valid_to IS NULL",
                         (ts, src, dst, rel))
            conn.execute("INSERT INTO edge VALUES (?,?,?,?,?,?,?,NULL)",
                         (eid, src, dst, rel, json.dumps(props or {}, sort_keys=True), evidence_id, ts))
        return eid

    def retire_edge(self, src: str, dst: str, rel: str) -> None:
        with db.tx() as conn:
            conn.execute("UPDATE edge SET valid_to=? WHERE src=? AND dst=? AND rel=? AND valid_to IS NULL",
                         (db.now(), src, dst, rel))

    def edges(self, as_of: str | None = None, rel: str | None = None) -> list[dict]:
        sql = "SELECT * FROM edge WHERE 1=1"
        args: tuple = ()
        if as_of:
            sql += " AND valid_from<=? AND (valid_to IS NULL OR valid_to>?)"
            args += (as_of, as_of)
        else:
            sql += " AND valid_to IS NULL"
        if rel:
            sql += " AND rel=?"
            args += (rel,)
        return [dict(r) | {"props": json.loads(r["props"])} for r in db.q(sql, args)]

    def node(self, node_id: str) -> dict | None:
        r = db.q1("SELECT * FROM node WHERE node_id=?", (node_id,))
        return (dict(r) | {"props": json.loads(r["props"])}) if r else None

    def neighbours(self, node_id: str, as_of: str | None = None) -> list[dict]:
        return [e for e in self.edges(as_of) if e["src"] == node_id or e["dst"] == node_id]


graph = GraphStore()


# ------------------------------------------------------------------ ownership
def ownership_tree(root: str, as_of: str | None = None, max_depth: int = 8) -> dict:
    """Walk OWNS edges upward from `root` and compute effective ownership.

    Returns owners with effective percentage, the path taken, and evidence ids
    per hop. Cycles are detected and reported rather than silently truncated.
    """
    owns = defaultdict(list)
    for e in graph.edges(as_of, rel="OWNS"):
        owns[e["dst"]].append(e)  # dst is the owned entity

    effective: dict[str, float] = defaultdict(float)
    paths: dict[str, list] = {}
    cycles: list[list[str]] = []

    def walk(node: str, share: float, trail: list[str], hops: list[dict]):
        if len(trail) > max_depth:
            return
        parents = owns.get(node, [])
        if not parents:
            return
        for e in parents:
            owner = e["src"]
            pct = float(e["props"].get("percentage", 0)) / 100.0
            carried = share * pct
            if owner in trail:
                cycles.append(trail + [owner])
                continue
            hop = {"owner": owner, "owned": node, "percentage": e["props"].get("percentage"),
                   "evidence_id": e["evidence_id"]}
            label = (graph.node(owner) or {}).get("label", "Organization")
            if label == "Person" or not owns.get(owner):
                effective[owner] += carried
                paths.setdefault(owner, hops + [hop])
            walk(owner, carried, trail + [owner], hops + [hop])

    walk(root, 1.0, [root], [])
    owners = [
        {"owner_id": k, "name": (graph.node(k) or {}).get("props", {}).get("name", k),
         "type": (graph.node(k) or {}).get("label", "Organization"),
         "effective_percentage": round(v * 100, 4), "path": paths.get(k, [])}
        for k, v in sorted(effective.items(), key=lambda kv: -kv[1])
    ]
    return {"root": root, "as_of": as_of, "owners": owners, "cycles": cycles,
            "ubo_threshold_25": [o for o in owners if o["effective_percentage"] >= 25.0]}


# ---------------------------------------------------------------- communities
def communities(as_of: str | None = None, rounds: int = 20) -> dict:
    """Label propagation over the undirected projection.

    Deterministic: nodes are processed in sorted order and ties break on the
    lexicographically smallest label, so the same graph always yields the same
    communities. Non-determinism here would make corporate-group membership
    unauditable, which is the whole point of computing it.
    """
    adj = defaultdict(set)
    for e in graph.edges(as_of):
        adj[e["src"]].add(e["dst"])
        adj[e["dst"]].add(e["src"])
    labels = {n: n for n in sorted(adj)}
    for _ in range(rounds):
        changed = False
        for n in sorted(adj):
            counts = defaultdict(int)
            for m in adj[n]:
                counts[labels.get(m, m)] += 1
            if not counts:
                continue
            best = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[0][0]
            if best != labels[n]:
                labels[n] = best
                changed = True
        if not changed:
            break
    groups = defaultdict(list)
    for n, l in labels.items():
        groups[l].append(n)
    return {
        "algorithm": "label_propagation/deterministic",
        "communities": [
            {"community_id": f"grp_{k}", "members": sorted(v), "size": len(v),
             "names": [(graph.node(m) or {}).get("props", {}).get("name", m) for m in sorted(v)]}
            for k, v in sorted(groups.items(), key=lambda kv: (-len(kv[1]), kv[0]))
        ],
    }


def connections(a: str, b: str, max_depth: int = 5, as_of: str | None = None) -> dict:
    """Shortest relationship path between two nodes - the investigation primitive."""
    adj = defaultdict(list)
    for e in graph.edges(as_of):
        adj[e["src"]].append((e["dst"], e["rel"], e["evidence_id"]))
        adj[e["dst"]].append((e["src"], f"{e['rel']}_INVERSE", e["evidence_id"]))
    seen = {a}
    frontier = [(a, [])]
    for _ in range(max_depth):
        nxt = []
        for node, path in frontier:
            for dst, rel, ev in adj.get(node, []):
                if dst in seen:
                    continue
                step = path + [{"from": node, "rel": rel, "to": dst, "evidence_id": ev}]
                if dst == b:
                    return {"found": True, "hops": len(step), "path": step}
                seen.add(dst)
                nxt.append((dst, step))
        frontier = nxt
    return {"found": False, "hops": None, "path": []}
