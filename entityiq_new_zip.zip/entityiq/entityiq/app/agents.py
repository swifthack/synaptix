"""Agent runtime - narrow agents on rails.

Design position: the agent is an *interface*, not the engine. Everything an
agent can do here is a typed call into the deterministic core, taken from an
allowlist scoped to that agent's role. There is no free-form code execution, no
open tool space, and no path by which a model's output becomes a stored fact.

Three guardrails are enforced by the runtime rather than by prompt text:

  1. Allowlist       an agent that is not entitled to a tool cannot call it,
                     regardless of what it decides to do.
  2. Abstention      if a product returns answerable=false, the runtime stops
                     and surfaces the gap. It will not let the agent proceed to
                     narrate around missing evidence.
  3. Trace           every step, its arguments, and the evidence head at time of
                     call are recorded and returned with the answer.
"""
from __future__ import annotations

import json
import time

from . import delta, evidence, graph, llm, policy, products, resolution
from .config import settings


# ------------------------------------------------------------- tool registry
def _t_kyb(customer_id: str, as_of: str | None = None, **_):
    return products.kyb_pack(customer_id, as_of)


def _t_screening(customer_id: str, as_of: str | None = None, **_):
    return products.screening_bundle(customer_id, as_of)


def _t_ubo(customer_id: str, as_of: str | None = None, **_):
    return products.ubo_graph(customer_id, as_of)


def _t_evidence(customer_id: str, as_of: str | None = None, **_):
    return products.evidence_bundle(customer_id, as_of)


def _t_changes(customer_id: str | None = None, since: str | None = None, **_):
    return products.change_events(customer_id, since)


def _t_connections(customer_id: str, other_id: str, as_of: str | None = None, **_):
    return {"product": "connections", "answerable": True,
            "sufficiency": {"score": 1.0, "answerable": True, "missing": []},
            "data": graph.connections(customer_id, other_id, as_of=as_of)}


def _t_group_exposure(customer_id: str, as_of: str | None = None, **_):
    """Group exposure needs a resolved group, so it composes UBO + communities."""
    tree = graph.ownership_tree(customer_id, as_of)
    comms = graph.communities(as_of)
    group = next((c for c in comms["communities"] if customer_id in c["members"]), None)
    answerable = group is not None and not tree["cycles"]
    return {"product": "group_exposure", "answerable": answerable,
            "sufficiency": {"score": 1.0 if answerable else 0.0, "answerable": answerable,
                            "missing": [] if answerable else ["resolved_group_structure"],
                            "remediation": [] if answerable else [
                                {"missing": "resolved_group_structure",
                                 "action": "resolve circular holdings or ingest the group structure filing"}]},
            "data": {"group": group, "owners": tree["owners"]} if answerable else None}


def _t_resolve(record_id: str, **_):
    r = resolution.resolve(record_id)
    return {"product": "resolution", "answerable": r["outcome"] != "needs_review",
            "sufficiency": {"score": r["score"], "answerable": r["outcome"] != "needs_review",
                            "missing": [] if r["outcome"] != "needs_review" else ["steward_confirmation"],
                            "remediation": [] if r["outcome"] != "needs_review" else [
                                {"missing": "steward_confirmation",
                                 "action": f"decision {r['decision_id']} is in the review band; a steward must confirm"}]},
            "data": r}


TOOLS = {
    "get_kyb_pack": {"fn": _t_kyb, "args": {"customer_id": "str", "as_of": "str?"},
                     "description": "Corporate identity, registry status, directors and the resolution trail."},
    "get_screening_bundle": {"fn": _t_screening, "args": {"customer_id": "str", "as_of": "str?"},
                             "description": "Sanctions, PEP and adverse media findings with related parties."},
    "get_ubo_graph": {"fn": _t_ubo, "args": {"customer_id": "str", "as_of": "str?"},
                      "description": "Effective beneficial ownership with per-hop evidence."},
    "get_evidence_bundle": {"fn": _t_evidence, "args": {"customer_id": "str", "as_of": "str?"},
                            "description": "Every evidence entry for the subject plus chain verification."},
    "get_change_events": {"fn": _t_changes, "args": {"customer_id": "str?", "since": "str?"},
                          "description": "Deltas with materiality, impact and required autonomy."},
    "find_connections": {"fn": _t_connections, "args": {"customer_id": "str", "other_id": "str"},
                         "description": "Shortest evidenced relationship path between two parties."},
    "get_group_exposure": {"fn": _t_group_exposure, "args": {"customer_id": "str", "as_of": "str?"},
                           "description": "Corporate group membership for exposure aggregation."},
    "resolve_record": {"fn": _t_resolve, "args": {"record_id": "str"},
                       "description": "Resolve an external record to an internal customer."},
}

AGENTS = {
    "orchestrator": {
        "role": "agent", "purpose": "onboarding",
        "tools": list(TOOLS),
        "description": "Routes a request to the right specialist and assembles the answer."},
    "kyc": {
        "role": "kyc_analyst", "purpose": "onboarding",
        "tools": ["get_kyb_pack", "get_screening_bundle", "get_evidence_bundle",
                  "get_change_events", "resolve_record"],
        "description": "Onboarding and periodic review. Builds the case pack."},
    "risk": {
        "role": "credit_officer", "purpose": "credit_assessment",
        "tools": ["get_ubo_graph", "get_group_exposure", "get_change_events", "get_kyb_pack"],
        "description": "Group structure, exposure aggregation and covenant-relevant change."},
    "investigation": {
        "role": "compliance", "purpose": "investigation",
        "tools": ["find_connections", "get_screening_bundle", "get_ubo_graph",
                  "get_evidence_bundle", "get_change_events"],
        "description": "Relationship discovery and alert triage."},
}


class ToolDenied(Exception):
    pass


def run(agent: str, question: str, args: dict | None = None, consumer: str = "unknown") -> dict:
    spec = AGENTS.get(agent)
    if not spec:
        raise KeyError(agent)
    started = time.time()
    trace: list[dict] = []

    intent = llm.parse_intent(question)
    if llm.available():
        try:
            raw = llm.complete(
                f"Tools: {json.dumps({k: TOOLS[k]['args'] for k in spec['tools']})}\n"
                f"Request: {question}\nReturn JSON only.")
            parsed = json.loads(raw[raw.find("{"): raw.rfind("}") + 1])
            if parsed.get("tool") in spec["tools"]:
                intent = {"tool": parsed["tool"], "args": parsed.get("args", {}), "router": "llm"}
        except Exception as exc:
            trace.append({"step": "llm_route", "status": "fallback", "error": str(exc)})

    tool = intent["tool"]
    call_args = {**intent.get("args", {}), **(args or {})}

    if tool not in spec["tools"]:
        raise ToolDenied(f"agent '{agent}' is not entitled to call '{tool}'")

    policy.check_purpose(spec["role"], spec["purpose"])

    trace.append({"step": "route", "tool": tool, "args": call_args, "router": intent["router"],
                  "evidence_head": evidence.head()})

    result = TOOLS[tool]["fn"](**call_args)

    # Guardrail 2: abstain rather than narrate around a gap.
    if not result.get("answerable", True):
        payload = {
            "agent": agent, "question": question, "answerable": False,
            "reason": "insufficient_evidence",
            "gap": result.get("sufficiency", {}),
            "next_actions": result.get("sufficiency", {}).get("remediation", []),
            "trace": trace, "elapsed_ms": int((time.time() - started) * 1000),
        }
        policy.log_access(consumer=consumer, purpose=spec["purpose"], product=tool,
                          subject=call_args.get("customer_id"), answerable=False,
                          redactions=[], receipt="n/a")
        return payload

    redacted, removed, receipt = policy.apply(result.get("data") or {}, spec["role"])
    policy.log_access(consumer=consumer, purpose=spec["purpose"], product=tool,
                      subject=call_args.get("customer_id"), answerable=True,
                      redactions=removed, receipt=receipt)
    trace.append({"step": "policy", "role": spec["role"], "redacted_paths": removed, "receipt": receipt})

    narration = llm.narrate({"tool": tool, "explanation": _summarise(tool, result)})

    return {
        "agent": agent, "question": question, "answerable": True, "tool": tool,
        "data": redacted,
        "sufficiency": result.get("sufficiency"),
        "narration": narration,
        "policy_receipt": receipt,
        "redacted_paths": removed,
        "evidence_head": evidence.head(),
        "scorecard_version": settings.scorecard.version,
        "trace": trace,
        "elapsed_ms": int((time.time() - started) * 1000),
    }


def _summarise(tool: str, result: dict) -> str:
    d = result.get("data") or {}
    if tool == "get_kyb_pack":
        return (f"{len(d.get('directors', []))} directors on file, "
                f"{len(d.get('resolution', []))} linked source records, "
                f"status {[s.get('status') for s in d.get('registry_status', [])]}.")
    if tool == "get_ubo_graph":
        return f"{len(d.get('ultimate_beneficial_owners', []))} owners at or above 25 percent."
    if tool == "get_change_events":
        return f"{d.get('count', 0)} open or recent deltas."
    if tool == "find_connections":
        return "Path found." if d.get("found") else "No path within the depth limit."
    return f"{tool} returned."
