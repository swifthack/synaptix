"""Agent-to-agent surface.

Publishes an agent card at /.well-known/agent.json so another team's agent can
discover what EntityIQ can answer without a human integration conversation, and
accepts typed tasks at /a2a/tasks.

The card advertises `abstains: true`. That is the contract clause that matters
between autonomous systems: a consumer agent must be built to handle "I do not
have enough evidence" as a first-class response, not as an error or an empty
set.
"""
from __future__ import annotations

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from .agents import AGENTS, TOOLS, ToolDenied, run
from .config import settings
from .mcp import ROLE_BY_KEY

a2a_router = APIRouter(tags=["a2a"])


@a2a_router.get("/.well-known/agent.json")
def agent_card():
    return {
        "name": "EntityIQ",
        "version": settings.version,
        "description": "Resolves corporate identity across internal and external sources and serves "
                       "evidence-backed decision products for onboarding, credit, compliance and trade.",
        "provider": {"organization": "Bank / EntityIQ platform team"},
        "url": "/a2a/tasks",
        "capabilities": {
            "streaming": False,
            "pushNotifications": True,
            "stateTransitionHistory": True,
            "abstains": True,
        },
        "authentication": {"schemes": ["apiKey"], "header": "x-api-key"},
        "defaultInputModes": ["text", "data"],
        "defaultOutputModes": ["data"],
        "skills": [
            {"id": name, "name": name.replace("_", " ").title(),
             "description": spec["description"],
             "inputSchema": spec["args"],
             "tags": ["kyc", "entity-resolution", "evidence"]}
            for name, spec in TOOLS.items()
        ],
        "agents": {k: {"description": v["description"], "skills": v["tools"]} for k, v in AGENTS.items()},
        "guarantees": {
            "deterministic_scoring": "Match scores are computed by a versioned scorecard, not a model.",
            "evidence_gated": "Answers are withheld when evidence coverage is below the floor.",
            "policy_receipts": "Every response carries a hash of what was withheld and why.",
            "time_travel": "Pass as_of to reconstruct what the platform knew at any past moment.",
        },
    }


class Task(BaseModel):
    skill: str | None = None
    agent: str = "orchestrator"
    message: str = ""
    args: dict = {}
    session_id: str | None = None


@a2a_router.post("/a2a/tasks")
def submit_task(task: Task, x_api_key: str = Header(default="demo-agent-key")):
    role = ROLE_BY_KEY.get(x_api_key)
    if role is None:
        raise HTTPException(401, "unknown api key")

    if task.skill:
        if task.skill not in TOOLS:
            raise HTTPException(404, f"unknown skill '{task.skill}'")
        envelope = TOOLS[task.skill]["fn"](**task.args)
        state = "completed" if envelope.get("answerable") else "input-required"
        return {"id": task.session_id or "task", "state": state, "skill": task.skill,
                "artifacts": [envelope],
                "required_input": envelope.get("sufficiency", {}).get("remediation", [])
                if state == "input-required" else []}

    try:
        result = run(task.agent, task.message, task.args, consumer=f"a2a:{role}")
    except ToolDenied as e:
        raise HTTPException(403, str(e))
    except KeyError:
        raise HTTPException(404, f"no agent '{task.agent}'")
    return {"id": task.session_id or "task",
            "state": "completed" if result.get("answerable") else "input-required",
            "artifacts": [result],
            "required_input": result.get("next_actions", [])}
