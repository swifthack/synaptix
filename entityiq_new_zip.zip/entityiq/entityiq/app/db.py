"""Bitemporal SQLite store.

Two clocks are kept on every fact:

  valid_from / valid_to    when the fact was true in the world
  decided_at               when EntityIQ came to believe it

Nothing is ever updated in place. A correction closes the old row and inserts a
new one, so `as_of` reconstruction returns exactly what the bank knew on a given
date - which is the question a regulator actually asks.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from .config import settings

_local = threading.local()

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

-- ---------------------------------------------------------------- internal
CREATE TABLE IF NOT EXISTS internal_entity (
  customer_id      TEXT PRIMARY KEY,
  legal_name       TEXT NOT NULL,
  normalized_name  TEXT NOT NULL,
  jurisdiction     TEXT,
  registration_no  TEXT,
  lei              TEXT,
  tax_id           TEXT,
  incorporated_on  TEXT,
  address          TEXT,
  normalized_addr  TEXT,
  aliases          TEXT DEFAULT '[]',
  officers         TEXT DEFAULT '[]',
  source_system    TEXT,
  ingested_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_int_norm ON internal_entity(normalized_name);

-- match index: identifiers only, never customer profile or financial data
CREATE TABLE IF NOT EXISTS match_index (
  blocking_key TEXT NOT NULL,
  customer_id  TEXT NOT NULL REFERENCES internal_entity(customer_id),
  key_kind     TEXT NOT NULL,
  PRIMARY KEY (blocking_key, customer_id, key_kind)
);
CREATE INDEX IF NOT EXISTS ix_mi_key ON match_index(blocking_key);

-- ---------------------------------------------------------------- external
CREATE TABLE IF NOT EXISTS external_record (
  record_id        TEXT PRIMARY KEY,
  source           TEXT NOT NULL,
  source_ref       TEXT,
  legal_name       TEXT NOT NULL,
  normalized_name  TEXT NOT NULL,
  jurisdiction     TEXT,
  registration_no  TEXT,
  lei              TEXT,
  status           TEXT,
  incorporated_on  TEXT,
  address          TEXT,
  normalized_addr  TEXT,
  aliases          TEXT DEFAULT '[]',
  officers         TEXT DEFAULT '[]',
  payload_digest   TEXT NOT NULL,
  retrieved_at     TEXT NOT NULL,
  valid_from       TEXT NOT NULL,
  valid_to         TEXT
);
CREATE INDEX IF NOT EXISTS ix_ext_norm ON external_record(normalized_name);

-- --------------------------------------------------------- resolution ledger
CREATE TABLE IF NOT EXISTS link_decision (
  decision_id      TEXT PRIMARY KEY,
  record_id        TEXT NOT NULL,
  customer_id      TEXT,
  outcome          TEXT NOT NULL,          -- auto_link | needs_review | no_match
  score            REAL NOT NULL,
  features         TEXT NOT NULL,          -- signed feature vector (json)
  rule_hits        TEXT NOT NULL,
  explanation      TEXT NOT NULL,
  scorecard_version TEXT NOT NULL,
  decided_by       TEXT NOT NULL,          -- engine | steward:<id>
  decided_at       TEXT NOT NULL,
  valid_from       TEXT NOT NULL,
  valid_to         TEXT,
  supersedes       TEXT
);
CREATE INDEX IF NOT EXISTS ix_link_rec ON link_decision(record_id);
CREATE INDEX IF NOT EXISTS ix_link_cust ON link_decision(customer_id);

-- --------------------------------------------------------- evidence chain
CREATE TABLE IF NOT EXISTS evidence (
  seq          INTEGER PRIMARY KEY AUTOINCREMENT,
  evidence_id  TEXT UNIQUE NOT NULL,
  subject      TEXT NOT NULL,              -- customer_id or record_id
  kind         TEXT NOT NULL,
  source       TEXT NOT NULL,
  source_ref   TEXT,
  claim        TEXT NOT NULL,
  confidence   REAL NOT NULL,
  observed_at  TEXT NOT NULL,
  recorded_at  TEXT NOT NULL,
  payload_digest TEXT NOT NULL,
  prev_hash    TEXT NOT NULL,
  entry_hash   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_ev_subject ON evidence(subject);

-- --------------------------------------------------------- graph
CREATE TABLE IF NOT EXISTS node (
  node_id    TEXT PRIMARY KEY,
  label      TEXT NOT NULL,                -- Organization | Person | Document
  props      TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS edge (
  edge_id    TEXT PRIMARY KEY,
  src        TEXT NOT NULL,
  dst        TEXT NOT NULL,
  rel        TEXT NOT NULL,                -- OWNS | DIRECTS | SUBSIDIARY_OF | MENTIONS
  props      TEXT NOT NULL DEFAULT '{}',
  evidence_id TEXT,
  valid_from TEXT NOT NULL,
  valid_to   TEXT
);
CREATE INDEX IF NOT EXISTS ix_edge_src ON edge(src);
CREATE INDEX IF NOT EXISTS ix_edge_dst ON edge(dst);

-- --------------------------------------------------------- deltas
CREATE TABLE IF NOT EXISTS delta (
  delta_id     TEXT PRIMARY KEY,
  subject      TEXT NOT NULL,
  change_type  TEXT NOT NULL,
  before       TEXT,
  after        TEXT,
  materiality  TEXT NOT NULL,              -- low | medium | high
  autonomy     TEXT NOT NULL,              -- automate | client_confirm | human_decision
  impacts      TEXT NOT NULL,
  actions      TEXT NOT NULL,
  evidence_id  TEXT,
  state        TEXT NOT NULL DEFAULT 'open',
  detected_at  TEXT NOT NULL,
  closed_at    TEXT
);
CREATE INDEX IF NOT EXISTS ix_delta_subject ON delta(subject);

-- --------------------------------------------------------- access log
CREATE TABLE IF NOT EXISTS access_log (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  at           TEXT NOT NULL,
  consumer     TEXT NOT NULL,
  purpose      TEXT NOT NULL,
  product      TEXT NOT NULL,
  subject      TEXT,
  answerable   INTEGER NOT NULL,
  redactions   TEXT NOT NULL,
  receipt      TEXT NOT NULL
);
"""


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def connect() -> sqlite3.Connection:
    conn = getattr(_local, "conn", None)
    if conn is None:
        Path(settings.db_path).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(settings.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.executescript(SCHEMA)
        _local.conn = conn
    return conn


@contextmanager
def tx():
    conn = connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def q(sql: str, args: tuple = ()) -> list[sqlite3.Row]:
    return connect().execute(sql, args).fetchall()


def q1(sql: str, args: tuple = ()):
    return connect().execute(sql, args).fetchone()


def jl(row, key: str, default=None):
    """Read a JSON column off a row."""
    raw = row[key] if row and key in row.keys() else None
    return json.loads(raw) if raw else (default if default is not None else [])


def reset() -> None:
    conn = connect()
    for t in (
        "access_log", "delta", "edge", "node", "evidence", "link_decision",
        "external_record", "match_index", "internal_entity",
    ):
        conn.execute(f"DELETE FROM {t}")
    conn.commit()
