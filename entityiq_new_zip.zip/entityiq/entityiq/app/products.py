"""Standardized data products.

The interesting design choice here is abstention. Every product computes an
evidence sufficiency score before it answers. If coverage is below the floor,
the product returns `answerable: false` plus a machine-readable list of what is
missing and how to get it - it does not return a partial pack that looks
complete.

That single rule is what makes the products safe to hand to an autonomous agent.
An agent cannot tell the difference between "no adverse media found" and "adverse
media was never checked" unless the API says so, and it will confidently report
the former. So the API says so.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from . import db, evidence, resolution
from .config import settings
from .graph import graph, ownership_tree

# product -> evidence kinds that must be present, with weights
REQUIRED_EVIDENCE = {
    "kyb_pack": {"source_record": 0.4, "resolution_decision": 0.3, "registry_status": 0.3},
    "screening_bundle": {"sanctions_check": 0.4, "pep_check": 0.3, "adverse_media_check": 0.3},
    "ubo_graph": {"ownership_filing": 0.6, "resolution_decision": 0.4},
    "evidence_bundle": {"source_record": 1.0},
}

REMEDIATION = {
    "sanctions_check": "run screening against the sanctions feed for this entity",
    "pep_check": "run a PEP check for the entity and its officers",
    "adverse_media_check": "run adverse media retrieval for the entity",
    "registry_status": "refresh the corporate registry record",
    "ownership_filing": "retrieve the UBO/shareholding filing from the registry or UBO provider",
    "source_record": "ingest at least one external source record for this entity",
    "resolution_decision": "resolve the external records to an internal customer id",
}


def _fresh(ev: dict) -> bool:
    try:
        seen = datetime.fromisoformat(ev["observed_at"])
    except ValueError:
        return False
    if seen.tzinfo is None:
        seen = seen.replace(tzinfo=timezone.utc)
    return seen >= datetime.now(timezone.utc) - timedelta(days=settings.evidence_max_age_days)


def sufficiency(product: str, customer_id: str, as_of: str | None = None) -> dict:
    """Coverage over required evidence kinds, weighted, freshness-aware."""
    required = REQUIRED_EVIDENCE.get(product, {})
    pool = evidence.for_subject(customer_id, as_of)
    for link in resolution.links_for_customer(customer_id, as_of):
        pool += evidence.for_subject(link["record_id"], as_of)

    present, stale = {}, []
    for ev in pool:
        if ev["kind"] in required:
            if _fresh(ev):
                present[ev["kind"]] = max(present.get(ev["kind"], 0.0), ev["confidence"])
            else:
                stale.append(ev["kind"])
    score = round(sum(w * present.get(k, 0.0) for k, w in required.items()), 4) if required else 1.0
    missing = [k for k in required if k not in present]
    return {
        "score": score,
        "floor": settings.sufficiency_floor,
        "answerable": score >= settings.sufficiency_floor,
        "present": sorted(present),
        "missing": missing,
        "stale": sorted(set(stale)),
        "remediation": [{"missing": m, "action": REMEDIATION.get(m, "acquire this evidence")} for m in missing],
    }


def _envelope(product: str, subject: str, body: dict, suff: dict, as_of: str | None) -> dict:
    return {
        "product": product,
        "subject": subject,
        "as_of": as_of or db.now(),
        "answerable": suff["answerable"],
        "sufficiency": suff,
        "data": body if suff["answerable"] else None,
        "evidence_head": evidence.head(),
        "scorecard_version": settings.scorecard.version,
    }


def _customer(customer_id: str) -> dict | None:
    r = db.q1("SELECT * FROM internal_entity WHERE customer_id=?", (customer_id,))
    return dict(r) if r else None


def _linked_records(customer_id: str, as_of: str | None):
    out = []
    for link in resolution.links_for_customer(customer_id, as_of):
        r = db.q1("SELECT * FROM external_record WHERE record_id=?", (link["record_id"],))
        if r:
            out.append((dict(r), link))
    return out


# ------------------------------------------------------------------- products
def kyb_pack(customer_id: str, as_of: str | None = None) -> dict:
    suff = sufficiency("kyb_pack", customer_id, as_of)
    cust = _customer(customer_id)
    if not cust:
        suff = dict(suff, answerable=False, missing=suff["missing"] + ["internal_entity"])
        return _envelope("kyb_pack", customer_id, {}, suff, as_of)
    records = _linked_records(customer_id, as_of)
    officers, statuses, evs = [], [], []
    for rec, link in records:
        import json as _j
        officers += _j.loads(rec["officers"] or "[]")
        statuses.append({"source": rec["source"], "status": rec["status"], "observed_at": rec["retrieved_at"]})
        evs += [e["evidence_id"] for e in evidence.for_subject(rec["record_id"], as_of)]
    body = {
        "legal_identity": {"customer_id": customer_id, "legal_name": cust["legal_name"],
                           "jurisdiction": cust["jurisdiction"], "registration_no": cust["registration_no"],
                           "lei": cust["lei"], "incorporated_on": cust["incorporated_on"],
                           "registered_address": cust["address"]},
        "registry_status": statuses,
        "directors": sorted(set(officers)),
        "resolution": [{"record_id": l["record_id"], "source": r["source"], "outcome": l["outcome"],
                        "score": l["score"], "decided_by": l["decided_by"],
                        "explanation": l["explanation"], "features": l["features"]}
                       for r, l in records],
        "evidence_pointers": evs,
    }
    return _envelope("kyb_pack", customer_id, body, suff, as_of)


def screening_bundle(customer_id: str, as_of: str | None = None) -> dict:
    suff = sufficiency("screening_bundle", customer_id, as_of)
    pool = evidence.for_subject(customer_id, as_of)
    for link in resolution.links_for_customer(customer_id, as_of):
        pool += evidence.for_subject(link["record_id"], as_of)
    body = {
        "sanctions": [e for e in pool if e["kind"] == "sanctions_check"],
        "pep": [e for e in pool if e["kind"] == "pep_check"],
        "adverse_media": [e for e in pool if e["kind"] == "adverse_media_check"],
        "related_parties": [n for n in _related(customer_id, as_of)],
    }
    return _envelope("screening_bundle", customer_id, body, suff, as_of)


def _related(customer_id: str, as_of: str | None):
    out = []
    for e in graph.neighbours(customer_id, as_of):
        other = e["dst"] if e["src"] == customer_id else e["src"]
        node = graph.node(other) or {}
        out.append({"node_id": other, "relationship": e["rel"], "label": node.get("label"),
                    "name": node.get("props", {}).get("name", other), "evidence_id": e["evidence_id"]})
    return out


def ubo_graph(customer_id: str, as_of: str | None = None) -> dict:
    suff = sufficiency("ubo_graph", customer_id, as_of)
    tree = ownership_tree(customer_id, as_of)
    body = {
        "ultimate_beneficial_owners": tree["ubo_threshold_25"],
        "all_owners": tree["owners"],
        "circular_holdings": tree["cycles"],
        "threshold_applied": 25.0,
    }
    if tree["cycles"]:
        suff = dict(suff, answerable=False,
                    missing=suff["missing"] + ["resolved_circular_holding"],
                    remediation=suff["remediation"] + [{
                        "missing": "resolved_circular_holding",
                        "action": "circular shareholding detected; a human must confirm the ultimate parent"}])
    return _envelope("ubo_graph", customer_id, body, suff, as_of)


def evidence_bundle(customer_id: str, as_of: str | None = None) -> dict:
    suff = sufficiency("evidence_bundle", customer_id, as_of)
    pool = evidence.for_subject(customer_id, as_of)
    for link in resolution.links_for_customer(customer_id, as_of):
        pool += evidence.for_subject(link["record_id"], as_of)
    body = {
        "entries": pool,
        "chain": evidence.verify(),
        "count": len(pool),
    }
    return _envelope("evidence_bundle", customer_id, body, suff, as_of)


def change_events(customer_id: str | None = None, since: str | None = None) -> dict:
    from .delta import list_deltas
    items = list_deltas(customer_id, since)
    suff = {"score": 1.0, "floor": settings.sufficiency_floor, "answerable": True,
            "present": ["change_stream"], "missing": [], "stale": [], "remediation": []}
    return _envelope("change_events", customer_id or "*", {"events": items, "count": len(items)}, suff, since)


PRODUCTS = {
    "kyb_pack": kyb_pack,
    "screening_bundle": screening_bundle,
    "ubo_graph": ubo_graph,
    "evidence_bundle": evidence_bundle,
}
