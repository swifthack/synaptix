"""Deterministic similarity primitives.

No third-party fuzzy library, on purpose: the exact algorithm has to be pinned
and reproducible for the lifetime of every decision it influenced. These
functions are pure, side-effect free and covered by tests.
"""
from __future__ import annotations

from datetime import date


def jaro(a: str, b: str) -> float:
    if a == b:
        return 1.0
    if not a or not b:
        return 0.0
    window = max(len(a), len(b)) // 2 - 1
    window = max(window, 0)
    a_flags = [False] * len(a)
    b_flags = [False] * len(b)
    matches = 0
    for i, ch in enumerate(a):
        lo = max(0, i - window)
        hi = min(i + window + 1, len(b))
        for j in range(lo, hi):
            if not b_flags[j] and b[j] == ch:
                a_flags[i] = b_flags[j] = True
                matches += 1
                break
    if matches == 0:
        return 0.0
    k = transpositions = 0
    for i, ch in enumerate(a):
        if a_flags[i]:
            while not b_flags[k]:
                k += 1
            if ch != b[k]:
                transpositions += 1
            k += 1
    t = transpositions / 2
    return (matches / len(a) + matches / len(b) + (matches - t) / matches) / 3


def jaro_winkler(a: str, b: str, p: float = 0.1) -> float:
    j = jaro(a, b)
    prefix = 0
    for x, y in zip(a[:4], b[:4]):
        if x != y:
            break
        prefix += 1
    return j + prefix * p * (1 - j)


def token_set_ratio(a: str, b: str) -> float:
    ta, tb = set(a.split()), set(b.split())
    if not ta or not tb:
        return 0.0
    inter = ta & tb
    return len(inter) / len(ta | tb)


def name_similarity(a: str, b: str) -> float:
    """Blend of character-level and token-level agreement.

    Token overlap catches word reordering ("acme holdings" vs "holdings acme");
    Jaro-Winkler catches typos and truncation.
    """
    if not a or not b:
        return 0.0
    return round(0.6 * jaro_winkler(a, b) + 0.4 * token_set_ratio(a, b), 4)


def address_similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return round(0.5 * jaro_winkler(a, b) + 0.5 * token_set_ratio(a, b), 4)


def set_overlap(a: list[str], b: list[str]) -> float:
    sa, sb = {x.lower().strip() for x in a if x}, {x.lower().strip() for x in b if x}
    if not sa or not sb:
        return 0.0
    return round(len(sa & sb) / min(len(sa), len(sb)), 4)


def date_proximity(a: str | None, b: str | None, tolerance_days: int = 365) -> float:
    if not a or not b:
        return 0.0
    try:
        da, db = date.fromisoformat(a[:10]), date.fromisoformat(b[:10])
    except ValueError:
        return 0.0
    gap = abs((da - db).days)
    if gap == 0:
        return 1.0
    if gap >= tolerance_days:
        return 0.0
    return round(1 - gap / tolerance_days, 4)


def best_alias_similarity(a_names: list[str], b_names: list[str]) -> float:
    best = 0.0
    for x in a_names:
        for y in b_names:
            best = max(best, name_similarity(x, y))
    return best
