"""Runtime configuration.

Every knob that can change a resolution outcome lives here and is stamped onto
the decision record as `scorecard_version`. Changing a threshold without bumping
the version is treated as a bug: past decisions must stay reproducible.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field, asdict


def _f(name: str, default: float) -> float:
    return float(os.getenv(name, default))


@dataclass(frozen=True)
class Scorecard:
    """Versioned, deterministic scoring configuration."""

    version: str = os.getenv("EIQ_SCORECARD_VERSION", "sc-2026.08.1")
    auto_link_at: float = _f("EIQ_AUTO_LINK_AT", 0.92)
    review_at: float = _f("EIQ_REVIEW_AT", 0.78)

    # Feature weights. Must sum to 1.0 (validated at import).
    w_name: float = 0.34
    w_address: float = 0.16
    w_officer_overlap: float = 0.22
    w_jurisdiction: float = 0.08
    w_date_proximity: float = 0.10
    w_alias: float = 0.10

    def weights(self) -> dict[str, float]:
        return {
            "name_similarity": self.w_name,
            "address_similarity": self.w_address,
            "officer_overlap": self.w_officer_overlap,
            "jurisdiction_match": self.w_jurisdiction,
            "date_proximity": self.w_date_proximity,
            "alias_similarity": self.w_alias,
        }


@dataclass(frozen=True)
class Settings:
    app_name: str = "EntityIQ"
    version: str = "2.0.0"
    db_path: str = os.getenv("EIQ_DB", os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "entityiq.db"))
    scorecard: Scorecard = field(default_factory=Scorecard)

    # Evidence gating: a product answer is only served when evidence coverage
    # meets this floor. Below it the API abstains instead of guessing.
    sufficiency_floor: float = _f("EIQ_SUFFICIENCY_FLOOR", 0.6)
    evidence_max_age_days: int = int(os.getenv("EIQ_EVIDENCE_MAX_AGE_DAYS", "400"))

    # Narration only. The LLM never produces a score, a match or an entitlement.
    llm_provider: str = os.getenv("EIQ_LLM_PROVIDER", "none")  # none|anthropic|azure
    llm_model: str = os.getenv("EIQ_LLM_MODEL", "claude-sonnet-4-5")

    api_keys: tuple[str, ...] = tuple(
        k.strip() for k in os.getenv("EIQ_API_KEYS", "demo-kyc-key,demo-credit-key,demo-agent-key").split(",") if k.strip()
    )

    def fingerprint(self) -> dict:
        d = asdict(self)
        d.pop("api_keys", None)
        return d


settings = Settings()

_total = sum(settings.scorecard.weights().values())
assert abs(_total - 1.0) < 1e-9, f"scorecard weights must sum to 1.0, got {_total}"
