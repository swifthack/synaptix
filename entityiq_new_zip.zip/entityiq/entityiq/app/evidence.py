"""Evidence registry - append-only and tamper-evident.

Each entry hashes the previous entry's hash together with its own content, so
the whole registry is a chain. `verify()` walks it and reports the first break.
This is what lets you hand an auditor a bundle and let them check it without
trusting the database, and it is deliberately cheap: SHA-256 over canonical
JSON, no external notary required (though the head hash is designed to be
anchored externally if you want that).
"""
from __future__ import annotations

import hashlib
import json
import uuid

from . import db

GENESIS = "0" * 64


def _digest(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def head() -> str:
    row = db.q1("SELECT entry_hash FROM evidence ORDER BY seq DESC LIMIT 1")
    return row["entry_hash"] if row else GENESIS


def record(
    *,
    subject: str,
    kind: str,
    source: str,
    claim: dict,
    confidence: float,
    observed_at: str,
    source_ref: str | None = None,
    payload: dict | None = None,
) -> str:
    """Append one evidence entry. Returns its evidence_id."""
    eid = f"ev_{uuid.uuid4().hex[:12]}"
    recorded_at = db.now()
    payload_digest = _digest(payload or claim)
    prev = head()
    body = {
        "evidence_id": eid, "subject": subject, "kind": kind, "source": source,
        "source_ref": source_ref, "claim": claim, "confidence": round(confidence, 4),
        "observed_at": observed_at, "recorded_at": recorded_at,
        "payload_digest": payload_digest, "prev_hash": prev,
    }
    entry_hash = _digest(body)
    with db.tx() as conn:
        conn.execute(
            """INSERT INTO evidence (evidence_id, subject, kind, source, source_ref, claim,
                 confidence, observed_at, recorded_at, payload_digest, prev_hash, entry_hash)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (eid, subject, kind, source, source_ref, json.dumps(claim, sort_keys=True),
             round(confidence, 4), observed_at, recorded_at, payload_digest, prev, entry_hash),
        )
    return eid


def get(evidence_id: str) -> dict | None:
    row = db.q1("SELECT * FROM evidence WHERE evidence_id=?", (evidence_id,))
    return _row(row) if row else None


def for_subject(subject: str, as_of: str | None = None) -> list[dict]:
    sql = "SELECT * FROM evidence WHERE subject=?"
    args: tuple = (subject,)
    if as_of:
        sql += " AND recorded_at<=?"
        args += (as_of,)
    return [_row(r) for r in db.q(sql + " ORDER BY seq", args)]


def _row(r) -> dict:
    return {
        "evidence_id": r["evidence_id"], "subject": r["subject"], "kind": r["kind"],
        "source": r["source"], "source_ref": r["source_ref"], "claim": json.loads(r["claim"]),
        "confidence": r["confidence"], "observed_at": r["observed_at"],
        "recorded_at": r["recorded_at"], "payload_digest": r["payload_digest"],
        "prev_hash": r["prev_hash"], "entry_hash": r["entry_hash"],
    }


def verify() -> dict:
    """Recompute the chain. Returns {ok, checked, head, broken_at?}."""
    prev = GENESIS
    checked = 0
    for r in db.q("SELECT * FROM evidence ORDER BY seq"):
        e = _row(r)
        body = {
            "evidence_id": e["evidence_id"], "subject": e["subject"], "kind": e["kind"],
            "source": e["source"], "source_ref": e["source_ref"], "claim": e["claim"],
            "confidence": e["confidence"], "observed_at": e["observed_at"],
            "recorded_at": e["recorded_at"], "payload_digest": e["payload_digest"],
            "prev_hash": prev,
        }
        if _digest(body) != e["entry_hash"] or e["prev_hash"] != prev:
            return {"ok": False, "checked": checked, "broken_at": e["evidence_id"], "head": head()}
        prev = e["entry_hash"]
        checked += 1
    return {"ok": True, "checked": checked, "head": prev}
