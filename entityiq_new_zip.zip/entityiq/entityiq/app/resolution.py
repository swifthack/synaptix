"""Entity resolution core.

Pipeline: blocking -> deterministic rules -> probabilistic score -> decision ->
explanation -> ledger write.

Two rules govern this module and they are the reason the rest of the platform
can be trusted:

1. No language model participates. The score is a weighted sum of named
   features; the explanation is generated from those features. An LLM may later
   *narrate* the explanation for a human, but the narration is marked
   non-authoritative and never replaces the feature vector.
2. Nothing is overwritten. A steward override supersedes the engine decision;
   both rows survive, so `as_of` reconstruction is exact.
"""
from __future__ import annotations

import json
import uuid

from . import db, evidence
from .config import settings
from .normalize import blocking_keys, enrich, normalize_id
from .similarity import (address_similarity, best_alias_similarity, date_proximity,
                         name_similarity, set_overlap)

AUTO, REVIEW, NONE = "auto_link", "needs_review", "no_match"


# --------------------------------------------------------------------- ingest
def upsert_internal(rec: dict) -> str:
    rec = enrich(dict(rec))
    cid = rec["customer_id"]
    with db.tx() as conn:
        conn.execute(
            """INSERT INTO internal_entity (customer_id, legal_name, normalized_name, jurisdiction,
                 registration_no, lei, tax_id, incorporated_on, address, normalized_addr,
                 aliases, officers, source_system, ingested_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(customer_id) DO UPDATE SET
                 legal_name=excluded.legal_name, normalized_name=excluded.normalized_name,
                 jurisdiction=excluded.jurisdiction, registration_no=excluded.registration_no,
                 lei=excluded.lei, tax_id=excluded.tax_id, address=excluded.address,
                 normalized_addr=excluded.normalized_addr, aliases=excluded.aliases,
                 officers=excluded.officers""",
            (cid, rec["legal_name"], rec["normalized_name"], rec.get("jurisdiction"),
             rec.get("registration_no"), rec.get("lei"), rec.get("tax_id"),
             rec.get("incorporated_on"), rec.get("address"), rec["normalized_addr"],
             json.dumps(rec.get("aliases", [])), json.dumps(rec.get("officers", [])),
             rec.get("source_system", "core"), db.now()),
        )
        conn.execute("DELETE FROM match_index WHERE customer_id=?", (cid,))
        for key, kind in blocking_keys(rec):
            conn.execute("INSERT OR IGNORE INTO match_index VALUES (?,?,?)", (key, cid, kind))
    return cid


def ingest_external(rec: dict) -> str:
    rec = enrich(dict(rec))
    rid = rec.get("record_id") or f"ext_{uuid.uuid4().hex[:10]}"
    ts = rec.get("retrieved_at") or db.now()
    digest = evidence._digest(rec)
    with db.tx() as conn:
        conn.execute("UPDATE external_record SET valid_to=? WHERE record_id=? AND valid_to IS NULL", (ts, rid))
        conn.execute(
            """INSERT OR REPLACE INTO external_record (record_id, source, source_ref, legal_name,
                 normalized_name, jurisdiction, registration_no, lei, status, incorporated_on,
                 address, normalized_addr, aliases, officers, payload_digest, retrieved_at,
                 valid_from, valid_to)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL)""",
            (rid, rec["source"], rec.get("source_ref"), rec["legal_name"], rec["normalized_name"],
             rec.get("jurisdiction"), rec.get("registration_no"), rec.get("lei"),
             rec.get("status"), rec.get("incorporated_on"), rec.get("address"),
             rec["normalized_addr"], json.dumps(rec.get("aliases", [])),
             json.dumps(rec.get("officers", [])), digest, ts, ts),
        )
    evidence.record(
        subject=rid, kind="source_record", source=rec["source"],
        source_ref=rec.get("source_ref"),
        claim={"legal_name": rec["legal_name"], "status": rec.get("status"),
               "registration_no": rec.get("registration_no"), "jurisdiction": rec.get("jurisdiction")},
        confidence=0.99, observed_at=ts, payload=rec,
    )
    return rid


# ------------------------------------------------------------------- matching
def _as_dict(row) -> dict:
    d = dict(row)
    d["aliases"] = json.loads(d.get("aliases") or "[]")
    d["officers"] = json.loads(d.get("officers") or "[]")
    return d


def candidates(rec: dict, limit: int = 25) -> list[dict]:
    keys = [k for k, _ in blocking_keys(rec)]
    if not keys:
        return []
    marks = ",".join("?" * len(keys))
    rows = db.q(
        f"""SELECT i.*, COUNT(m.blocking_key) AS hits
            FROM match_index m JOIN internal_entity i ON i.customer_id=m.customer_id
            WHERE m.blocking_key IN ({marks})
            GROUP BY i.customer_id ORDER BY hits DESC LIMIT ?""",
        tuple(keys) + (limit,),
    )
    return [_as_dict(r) for r in rows]


DETERMINISTIC_RULES = (
    ("registration_match", lambda e, i: bool(normalize_id(e.get("registration_no"))
                                             and normalize_id(e.get("registration_no")) == normalize_id(i.get("registration_no"))
                                             and (e.get("jurisdiction") or "") == (i.get("jurisdiction") or ""))),
    ("lei_match", lambda e, i: bool(normalize_id(e.get("lei")) and normalize_id(e.get("lei")) == normalize_id(i.get("lei")))),
    ("tax_id_match", lambda e, i: bool(normalize_id(e.get("tax_id")) and normalize_id(e.get("tax_id")) == normalize_id(i.get("tax_id")))),
)

NEGATIVE_RULES = (
    ("jurisdiction_conflict_with_registration",
     lambda e, i: bool(e.get("registration_no") and i.get("registration_no")
                       and normalize_id(e.get("registration_no")) != normalize_id(i.get("registration_no"))
                       and (e.get("jurisdiction") or "") == (i.get("jurisdiction") or ""))),
)


def features(ext: dict, internal: dict) -> dict:
    ext_names = [ext.get("normalized_name", "")] + [n for n in ext.get("aliases", [])]
    int_names = [internal.get("normalized_name", "")] + [n for n in internal.get("aliases", [])]
    return {
        "name_similarity": name_similarity(ext.get("normalized_name", ""), internal.get("normalized_name", "")),
        "address_similarity": address_similarity(ext.get("normalized_addr", ""), internal.get("normalized_addr", "")),
        "officer_overlap": set_overlap(ext.get("officers", []), internal.get("officers", [])),
        "jurisdiction_match": 1.0 if (ext.get("jurisdiction") and ext.get("jurisdiction") == internal.get("jurisdiction")) else 0.0,
        "date_proximity": date_proximity(ext.get("incorporated_on"), internal.get("incorporated_on")),
        "alias_similarity": best_alias_similarity(ext_names, int_names),
    }


def score_pair(ext: dict, internal: dict, scorecard=None) -> dict:
    sc = scorecard or settings.scorecard
    f = features(ext, internal)
    hits = [name for name, fn in DETERMINISTIC_RULES if fn(ext, internal)]
    negatives = [name for name, fn in NEGATIVE_RULES if fn(ext, internal)]

    if hits:
        score = 1.0
    else:
        w = sc.weights()
        score = round(sum(f[k] * w[k] for k in w), 4)
    if negatives and not hits:
        score = round(score * 0.5, 4)  # documented penalty, not a veto
    return {"score": min(score, 1.0), "features": f, "rule_hits": hits, "negative_hits": negatives}


def decide(score: float, scorecard=None) -> str:
    sc = scorecard or settings.scorecard
    if score >= sc.auto_link_at:
        return AUTO
    if score >= sc.review_at:
        return REVIEW
    return NONE


def explain(ext: dict, internal: dict | None, scored: dict, outcome: str) -> str:
    if internal is None:
        return "No internal entity shared a blocking key with this record, so no comparison was possible."
    if scored["rule_hits"]:
        pretty = ", ".join(h.replace("_", " ") for h in scored["rule_hits"])
        return (f"Linked on {pretty}. Identifier agreement is treated as conclusive, "
                f"so similarity features were recorded but did not drive the outcome.")
    f = scored["features"]
    top = sorted(f.items(), key=lambda kv: -kv[1] * settings.scorecard.weights()[kv[0]])[:3]
    drivers = "; ".join(f"{k.replace('_', ' ')} {v:.2f}" for k, v in top)
    weak = [k.replace("_", " ") for k, v in f.items() if v < 0.2]
    verdict = {
        AUTO: "above the auto-link threshold",
        REVIEW: "in the review band - a steward must confirm",
        NONE: "below the review threshold",
    }[outcome]
    tail = f" Weak or missing signals: {', '.join(weak)}." if weak else ""
    penalty = " A conflicting registration number in the same jurisdiction halved the score." if scored["negative_hits"] else ""
    return (f"Score {scored['score']:.2f} is {verdict}. Strongest signals: {drivers}.{tail}{penalty}")


# --------------------------------------------------------------------- ledger
def resolve(record_id: str, decided_by: str = "engine") -> dict:
    row = db.q1("SELECT * FROM external_record WHERE record_id=?", (record_id,))
    if not row:
        raise KeyError(record_id)
    ext = _as_dict(row)

    best, best_scored = None, None
    ranked = []
    for cand in candidates(ext):
        scored = score_pair(ext, cand)
        ranked.append({"customer_id": cand["customer_id"], "legal_name": cand["legal_name"], **scored})
        if best_scored is None or scored["score"] > best_scored["score"]:
            best, best_scored = cand, scored

    if best_scored is None:
        best_scored = {"score": 0.0, "features": {}, "rule_hits": [], "negative_hits": []}
        outcome = NONE
    else:
        outcome = decide(best_scored["score"])

    # A near-tie in the auto band is not an auto-link: ambiguity is a review case.
    ranked.sort(key=lambda r: -r["score"])
    if outcome == AUTO and len(ranked) > 1 and ranked[0]["score"] - ranked[1]["score"] < 0.02:
        outcome = REVIEW
        best_scored = dict(best_scored)
        best_scored["negative_hits"] = best_scored["negative_hits"] + ["ambiguous_top_two"]

    text = explain(ext, best, best_scored, outcome)
    cid = best["customer_id"] if (best and outcome != NONE) else None
    did = _write_decision(record_id, cid, outcome, best_scored, text, decided_by)

    evidence.record(
        subject=cid or record_id, kind="resolution_decision", source="entityiq",
        source_ref=did,
        claim={"record_id": record_id, "customer_id": cid, "outcome": outcome,
               "score": best_scored["score"], "scorecard": settings.scorecard.version},
        confidence=best_scored["score"], observed_at=db.now(), payload=best_scored,
    )
    return {"decision_id": did, "record_id": record_id, "customer_id": cid, "outcome": outcome,
            "score": best_scored["score"], "features": best_scored["features"],
            "rule_hits": best_scored["rule_hits"], "explanation": text,
            "scorecard_version": settings.scorecard.version, "candidates": ranked[:5]}


def _write_decision(record_id, customer_id, outcome, scored, text, decided_by, supersedes=None) -> str:
    did = f"dec_{uuid.uuid4().hex[:12]}"
    ts = db.now()
    with db.tx() as conn:
        conn.execute("UPDATE link_decision SET valid_to=? WHERE record_id=? AND valid_to IS NULL", (ts, record_id))
        conn.execute(
            """INSERT INTO link_decision (decision_id, record_id, customer_id, outcome, score,
                 features, rule_hits, explanation, scorecard_version, decided_by, decided_at,
                 valid_from, valid_to, supersedes)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NULL,?)""",
            (did, record_id, customer_id, outcome, scored["score"],
             json.dumps(scored["features"], sort_keys=True),
             json.dumps(scored["rule_hits"] + scored.get("negative_hits", [])),
             text, settings.scorecard.version, decided_by, ts, ts, supersedes),
        )
    return did


def override(record_id: str, customer_id: str | None, steward: str, rationale: str) -> dict:
    """Human decision. Supersedes the engine row; the engine row is retained."""
    prev = db.q1("SELECT * FROM link_decision WHERE record_id=? AND valid_to IS NULL", (record_id,))
    scored = {"score": 1.0 if customer_id else 0.0,
              "features": json.loads(prev["features"]) if prev else {},
              "rule_hits": ["steward_override"], "negative_hits": []}
    outcome = AUTO if customer_id else NONE
    text = f"Steward {steward} set this link manually. Rationale: {rationale}"
    did = _write_decision(record_id, customer_id, outcome, scored, text,
                          f"steward:{steward}", prev["decision_id"] if prev else None)
    evidence.record(subject=customer_id or record_id, kind="steward_override", source="entityiq",
                    source_ref=did, claim={"record_id": record_id, "customer_id": customer_id,
                                           "steward": steward, "rationale": rationale},
                    confidence=1.0, observed_at=db.now())
    return {"decision_id": did, "outcome": outcome, "customer_id": customer_id, "explanation": text}


def link_as_of(record_id: str, as_of: str | None = None) -> dict | None:
    if as_of:
        row = db.q1(
            """SELECT * FROM link_decision WHERE record_id=? AND valid_from<=?
               AND (valid_to IS NULL OR valid_to>?) ORDER BY decided_at DESC LIMIT 1""",
            (record_id, as_of, as_of))
    else:
        row = db.q1("SELECT * FROM link_decision WHERE record_id=? AND valid_to IS NULL", (record_id,))
    return _decision_row(row) if row else None


def links_for_customer(customer_id: str, as_of: str | None = None) -> list[dict]:
    if as_of:
        rows = db.q("""SELECT * FROM link_decision WHERE customer_id=? AND valid_from<=?
                       AND (valid_to IS NULL OR valid_to>?)""", (customer_id, as_of, as_of))
    else:
        rows = db.q("SELECT * FROM link_decision WHERE customer_id=? AND valid_to IS NULL", (customer_id,))
    return [_decision_row(r) for r in rows]


def _decision_row(r) -> dict:
    return {"decision_id": r["decision_id"], "record_id": r["record_id"], "customer_id": r["customer_id"],
            "outcome": r["outcome"], "score": r["score"], "features": json.loads(r["features"]),
            "rule_hits": json.loads(r["rule_hits"]), "explanation": r["explanation"],
            "scorecard_version": r["scorecard_version"], "decided_by": r["decided_by"],
            "decided_at": r["decided_at"], "valid_from": r["valid_from"], "valid_to": r["valid_to"]}


def review_queue() -> list[dict]:
    rows = db.q("""SELECT * FROM link_decision WHERE outcome='needs_review' AND valid_to IS NULL
                   ORDER BY score DESC""")
    return [_decision_row(r) for r in rows]
