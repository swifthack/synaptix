"""LLM seam.

Deliberately small. The model is allowed to do two things:

  * parse a natural-language request into a typed tool call (intent + args)
  * narrate a decision that has already been made deterministically

It is not allowed to produce a score, assert a link, invent an entity, or decide
an entitlement. Every narration is returned with `authoritative: false` so a
downstream system cannot mistake prose for a finding.

With EIQ_LLM_PROVIDER=none (the default) the platform is fully functional using
a deterministic rule-based intent parser - useful for air-gapped demos, CI, and
for proving that the agent layer is optional rather than load-bearing.
"""
from __future__ import annotations

import json
import os
import re
import urllib.request

from .config import settings

SYSTEM = (
    "You route requests for a bank's entity intelligence platform. "
    "Return ONLY JSON: {\"tool\": <name>, \"args\": {...}}. "
    "Never invent entity names, scores, ownership percentages or screening outcomes."
)


class LLMUnavailable(Exception):
    pass


def available() -> bool:
    return settings.llm_provider != "none"


def _anthropic(prompt: str, system: str, max_tokens: int = 600) -> str:
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        raise LLMUnavailable("ANTHROPIC_API_KEY not set")
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps({"model": settings.llm_model, "max_tokens": max_tokens,
                         "system": system, "messages": [{"role": "user", "content": prompt}]}).encode(),
        headers={"content-type": "application/json", "x-api-key": key,
                 "anthropic-version": "2023-06-01"})
    with urllib.request.urlopen(req, timeout=60) as r:
        body = json.loads(r.read())
    return "".join(b.get("text", "") for b in body.get("content", []))


def _azure(prompt: str, system: str, max_tokens: int = 600) -> str:
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    key = os.getenv("AZURE_OPENAI_API_KEY")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", settings.llm_model)
    version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
    if not (endpoint and key):
        raise LLMUnavailable("AZURE_OPENAI_ENDPOINT / AZURE_OPENAI_API_KEY not set")
    url = f"{endpoint.rstrip('/')}/openai/deployments/{deployment}/chat/completions?api-version={version}"
    req = urllib.request.Request(
        url,
        data=json.dumps({"messages": [{"role": "system", "content": system},
                                      {"role": "user", "content": prompt}],
                         "max_tokens": max_tokens, "temperature": 0}).encode(),
        headers={"content-type": "application/json", "api-key": key})
    with urllib.request.urlopen(req, timeout=60) as r:
        body = json.loads(r.read())
    return body["choices"][0]["message"]["content"]


def complete(prompt: str, system: str = SYSTEM, max_tokens: int = 600) -> str:
    if settings.llm_provider == "anthropic":
        return _anthropic(prompt, system, max_tokens)
    if settings.llm_provider == "azure":
        return _azure(prompt, system, max_tokens)
    raise LLMUnavailable("no LLM provider configured")


def narrate(finding: dict) -> dict:
    """Human-readable gloss on a finding. Never authoritative."""
    if not available():
        return {"text": finding.get("explanation") or "No narration provider configured.",
                "authoritative": False, "generated_by": "deterministic_template"}
    try:
        text = complete(
            "Explain this finding to a KYC analyst in three sentences. Use only the numbers "
            "given; do not add facts.\n\n" + json.dumps(finding, default=str)[:6000],
            system="You explain regulated decisions plainly and never add information.",
            max_tokens=300)
        return {"text": text.strip(), "authoritative": False,
                "generated_by": f"{settings.llm_provider}:{settings.llm_model}"}
    except Exception as exc:  # narration failing must never fail the request
        return {"text": finding.get("explanation", ""), "authoritative": False,
                "generated_by": "fallback", "error": str(exc)}


# ------------------------------------------------------- deterministic parser
INTENT_PATTERNS = [
    (r"\b(kyb|know your business|business pack|onboarding pack)\b", "get_kyb_pack"),
    (r"\b(ubo|beneficial owner|ownership)\b", "get_ubo_graph"),
    (r"\b(sanction|pep|adverse media|screen)\w*\b", "get_screening_bundle"),
    (r"\b(what changed|changes|since last review|delta)\b", "get_change_events"),
    (r"\b(connect|relationship|linked to|related to)\w*\b", "find_connections"),
    (r"\b(exposure|group limit|concentration)\b", "get_group_exposure"),
    (r"\b(evidence|audit|provenance|lineage)\b", "get_evidence_bundle"),
    (r"\b(resolve|match|link)\b", "resolve_record"),
]

ID_PATTERN = re.compile(r"\b(CUST[-_A-Z0-9]+|ext_[a-z0-9]+)\b", re.I)


def parse_intent(text: str) -> dict:
    """Rule-based intent routing. Used when no LLM is configured, and as the
    validator for LLM output when one is."""
    lowered = text.lower()
    tool = next((t for pat, t in INTENT_PATTERNS if re.search(pat, lowered)), "get_kyb_pack")
    ids = ID_PATTERN.findall(text)
    args = {}
    if ids:
        args["customer_id"] = ids[0]
        if tool == "find_connections" and len(ids) > 1:
            args["other_id"] = ids[1]
        if tool == "resolve_record":
            args = {"record_id": ids[0]}
    return {"tool": tool, "args": args, "router": "deterministic"}
