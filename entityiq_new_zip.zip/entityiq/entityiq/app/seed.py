"""Demo book.

Built to exercise the hard cases rather than the happy path:

  CUST-1001  clean identifier match (registration number agrees)
  CUST-1002  fuzzy match only: reordered name, no shared identifier -> review band
  CUST-1003  two plausible internal entities within 0.02 -> forced to review
  CUST-1004  circular shareholding -> UBO product abstains instead of guessing
  CUST-1005  screening evidence missing entirely -> screening product abstains
  CUST-1001  a later registry refresh dissolves the entity -> high-materiality delta
"""
from __future__ import annotations

from . import db, delta, evidence, resolution
from .graph import graph

INTERNAL = [
    dict(customer_id="CUST-1001", legal_name="ABC Construction Pte. Ltd.", jurisdiction="SG",
         registration_no="202012345E", lei="5493001KJTIIGC8Y1R12", tax_id="M90312345A",
         incorporated_on="2020-03-11", address="12 Marina Boulevard, Level 20, Singapore 018982",
         aliases=["ABC Construction"], officers=["Tan Wei Ming", "Priya Nair"], source_system="core_cif"),
    dict(customer_id="CUST-1002", legal_name="Helios Holdings Limited", jurisdiction="HK",
         registration_no=None, lei=None, incorporated_on="2016-07-02",
         address="Unit 4501, Two IFC, 8 Finance Street, Central, Hong Kong",
         aliases=["Holdings Helios Ltd"], officers=["Chan Ka Yee", "Marcus Feld"], source_system="core_cif"),
    dict(customer_id="CUST-1003", legal_name="Meridian Trading Pte Ltd", jurisdiction="SG",
         registration_no=None, incorporated_on="2019-01-15",
         address="8 Shenton Way, Singapore 068811", officers=["R. Kapoor"], source_system="core_cif"),
    dict(customer_id="CUST-1003B", legal_name="Meridian Trading Private Limited", jurisdiction="SG",
         registration_no=None, incorporated_on="2019-01-20",
         address="8 Shenton Way, Singapore 068811", officers=["R. Kapoor"], source_system="trade_system"),
    dict(customer_id="CUST-1004", legal_name="Orion Maritime Group Ltd", jurisdiction="CY",
         registration_no="HE 412991", incorporated_on="2014-05-30",
         address="Griva Digeni 81, Limassol, Cyprus", officers=["A. Petrou"], source_system="core_cif"),
    dict(customer_id="CUST-1005", legal_name="Northwind Commodities SA", jurisdiction="CH",
         registration_no="CHE-114.222.333", incorporated_on="2011-11-04",
         address="Rue du Rhone 14, Geneva, Switzerland", officers=["L. Brunner"], source_system="core_cif"),
]

EXTERNAL = [
    dict(record_id="ext_acra_001", source="acra_registry", source_ref="ACRA/202012345E",
         legal_name="ABC CONSTRUCTION PTE LTD", jurisdiction="SG", registration_no="202012345E",
         status="live", incorporated_on="2020-03-11",
         address="12 MARINA BOULEVARD #20-01 SINGAPORE 018982",
         officers=["Tan Wei Ming", "Priya Nair", "Goh Li Hua"]),
    dict(record_id="ext_cr_002", source="hk_companies_registry", source_ref="CR/2412889",
         legal_name="HOLDINGS HELIOS LTD", jurisdiction="HK", registration_no=None,
         status="active", incorporated_on="2016-07-02",
         address="UNIT 4501 TWO IFC 8 FINANCE ST CENTRAL HK",
         officers=["Chan Ka Yee"], aliases=["Helios Holdings Limited"]),
    dict(record_id="ext_acra_003", source="acra_registry", source_ref="ACRA/201900112M",
         legal_name="MERIDIAN TRADING PTE LTD", jurisdiction="SG", registration_no=None,
         status="live", incorporated_on="2019-01-16", address="8 SHENTON WAY SINGAPORE 068811",
         officers=["R. Kapoor"]),
    dict(record_id="ext_ubo_004", source="ubo_provider", source_ref="UBO/ORION/2026",
         legal_name="ORION MARITIME GROUP LTD", jurisdiction="CY", registration_no="HE412991",
         status="active", incorporated_on="2014-05-30", address="GRIVA DIGENI 81 LIMASSOL CY",
         officers=["A. Petrou"]),
    dict(record_id="ext_zefix_005", source="zefix_registry", source_ref="CHE-114.222.333",
         legal_name="NORTHWIND COMMODITIES SA", jurisdiction="CH", registration_no="CHE114222333",
         status="active", incorporated_on="2011-11-04", address="RUE DU RHONE 14 GENEVA CH",
         officers=["L. Brunner"]),
]


def _screening_evidence(customer_id: str, sanctions_hit: bool = False, pep: bool = False):
    evidence.record(subject=customer_id, kind="sanctions_check", source="sanctions_feed",
                    claim={"result": "hit" if sanctions_hit else "clear",
                           "lists_checked": ["OFAC_SDN", "EU_CFSP", "UN_CONSOLIDATED"]},
                    confidence=0.97, observed_at=db.now())
    evidence.record(subject=customer_id, kind="pep_check", source="pep_provider",
                    claim={"result": "pep_related" if pep else "clear", "degree": 1 if pep else None},
                    confidence=0.93, observed_at=db.now())
    evidence.record(subject=customer_id, kind="adverse_media_check", source="media_provider",
                    claim={"result": "clear", "articles_reviewed": 42},
                    confidence=0.85, observed_at=db.now())


def load(reset: bool = True) -> dict:
    if reset:
        db.reset()

    for rec in INTERNAL:
        resolution.upsert_internal(rec)
    for rec in EXTERNAL:
        resolution.ingest_external(rec)

    decisions = [resolution.resolve(r["record_id"]) for r in EXTERNAL]

    # registry status evidence for the entities that have it
    for cid, status in [("CUST-1001", "live"), ("CUST-1002", "active"),
                        ("CUST-1003", "live"), ("CUST-1004", "active")]:
        evidence.record(subject=cid, kind="registry_status", source="registry",
                        claim={"status": status}, confidence=0.98, observed_at=db.now())

    # screening: 1005 is deliberately left unscreened so the product abstains
    _screening_evidence("CUST-1001")
    _screening_evidence("CUST-1002", pep=True)
    _screening_evidence("CUST-1004", sanctions_hit=True)

    # ------------------------------------------------------------------ graph
    for cid, name, label in [
        ("CUST-1001", "ABC Construction Pte Ltd", "Organization"),
        ("CUST-1002", "Helios Holdings Limited", "Organization"),
        ("CUST-1004", "Orion Maritime Group Ltd", "Organization"),
        ("CUST-1005", "Northwind Commodities SA", "Organization"),
        ("PER-TWM", "Tan Wei Ming", "Person"),
        ("PER-CKY", "Chan Ka Yee", "Person"),
        ("PER-MF", "Marcus Feld", "Person"),
        ("ORG-OFFSHORE-A", "Aegis Nominees Ltd", "Organization"),
        ("ORG-OFFSHORE-B", "Cyclone Holdings Ltd", "Organization"),
    ]:
        graph.upsert_node(cid, label, {"name": name})

    ev_own = evidence.record(subject="CUST-1001", kind="ownership_filing", source="acra_registry",
                             claim={"owner": "CUST-1002", "percentage": 62.0},
                             confidence=0.95, observed_at=db.now())
    graph.upsert_edge("CUST-1002", "CUST-1001", "OWNS", {"percentage": 62.0}, ev_own)

    ev_own2 = evidence.record(subject="CUST-1002", kind="ownership_filing", source="ubo_provider",
                              claim={"owner": "PER-CKY", "percentage": 55.0},
                              confidence=0.92, observed_at=db.now())
    graph.upsert_edge("PER-CKY", "CUST-1002", "OWNS", {"percentage": 55.0}, ev_own2)
    graph.upsert_edge("PER-MF", "CUST-1002", "OWNS", {"percentage": 45.0}, ev_own2)
    graph.upsert_edge("PER-TWM", "CUST-1001", "DIRECTS", {"role": "director"}, ev_own)
    graph.upsert_edge("PER-CKY", "CUST-1002", "DIRECTS", {"role": "director"}, ev_own2)

    # circular shareholding: A owns Orion, Orion owns B, B owns A
    ev_cycle = evidence.record(subject="CUST-1004", kind="ownership_filing", source="ubo_provider",
                               claim={"structure": "circular", "note": "nominee chain"},
                               confidence=0.7, observed_at=db.now())
    graph.upsert_edge("ORG-OFFSHORE-A", "CUST-1004", "OWNS", {"percentage": 80.0}, ev_cycle)
    graph.upsert_edge("CUST-1004", "ORG-OFFSHORE-B", "OWNS", {"percentage": 90.0}, ev_cycle)
    graph.upsert_edge("ORG-OFFSHORE-B", "ORG-OFFSHORE-A", "OWNS", {"percentage": 100.0}, ev_cycle)

    # ------------------------------------------------------------- change feed
    old = dict(db.q1("SELECT * FROM external_record WHERE record_id='ext_acra_001'"))
    refreshed = dict(EXTERNAL[0], status="dissolved",
                     officers=["Priya Nair", "Goh Li Hua"])  # Tan Wei Ming removed
    resolution.ingest_external(refreshed)
    deltas = delta.detect_from_records("ext_acra_001", refreshed, old)

    return {
        "internal_entities": len(INTERNAL),
        "external_records": len(EXTERNAL),
        "decisions": [{"record_id": d["record_id"], "outcome": d["outcome"], "score": d["score"],
                       "customer_id": d["customer_id"]} for d in decisions],
        "deltas": [{"delta_id": d["delta_id"], "change_type": d["change_type"],
                    "materiality": d["materiality"], "autonomy": d["autonomy"]} for d in deltas],
        "evidence_head": evidence.head(),
    }
