import express from "express";
import path from "path";
import multer from "multer";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;
const upload = multer({ storage: multer.memoryStorage() });

app.use(express.json());

// In-memory backend target configuration
let backendConfig = {
  backendUrl: process.env.BACKEND_URL || "http://127.0.0.1:8000",
  useSimulation: true, // Defaults to simulation mode so AI Studio preview works out-of-the-box
};

// Helper: Generate exact mock responses matching user specs or dynamic fallback
function generateSampleChatResponse(message: string, userId: string = "ext_abc_user", sessionId: string = "demo1") {
  const isDocUpload = message.toLowerCase().includes("upload") || message.toLowerCase().includes(".txt") || message.toLowerCase().includes(".pdf");
  const isEscalation = message.toLowerCase().includes("human") || message.toLowerCase().includes("case") || message.toLowerCase().includes("escalat");

  if (isEscalation) {
    return {
      user: {
        user_id: userId,
        display_name: "ABC Ltd Client User",
        user_type: "external",
        role: "client_user",
        customer_id: "CUST_ABC"
      },
      response: {
        request_id: `req-${Date.now()}-esc`,
        timestamp: new Date().toISOString(),
        user_context: {
          user_id: userId,
          display_name: "ABC Ltd Client User",
          user_type: "external",
          role: "client_user",
          customer_id: "CUST_ABC",
          market: "SG"
        },
        understanding: {
          intent: "OPS_CASE_ESCALATION",
          domain: "Operations & Trade Support",
          resolved_entity: {
            type: "case_request",
            priority: "HIGH"
          },
          natural_language_interpretation: "User requested human operations agent review for trade settlement."
        },
        resolution_status: "CASE_CREATED",
        summary: "Operations review case CASE-2026-8802 created for ABC Ltd. High priority routing assigned.",
        root_cause: "Client requested explicit human operational override.",
        explanation: [
          "Automated workflow initiated case creation.",
          "Routed to SG Operations Desk.",
          "Target SLA: 15 minutes."
        ],
        recommended_actions: [
          "Track progress in Ops Case Panel.",
          "Attach supporting trade execution advice."
        ],
        workflow: {
          matched: true,
          workflow_id: "WF-OPS-880",
          workflow_name: "High Priority Ops Escalation",
          confidence: 0.96,
          steps: [
            { step_id: "1", name: "User Auth Verification", status: "COMPLETED" },
            { step_id: "2", name: "Case Registry Lock", status: "COMPLETED" },
            { step_id: "3", name: "Ops Specialist Notification", status: "IN_PROGRESS" }
          ]
        },
        case: {
          created: true,
          case_id: "CASE-2026-8802",
          reason: "Explicit user request for human ops investigation.",
          status: "OPEN"
        },
        document: {},
        agent_execution: [
          {
            agent: "Identity Agent",
            status: "COMPLETED",
            detail: "Resolved user identity and entitled role.",
            metadata: { user_type: "external", customer_id: "CUST_ABC" }
          },
          {
            agent: "Customer Context Agent",
            status: "COMPLETED",
            detail: "Fetched active SLA commitments for SG market.",
            metadata: { customer_tier: "PREMIUM_INSTITUTIONAL" }
          },
          {
            agent: "Workflow Discovery Agent",
            status: "COMPLETED",
            detail: "Matched WF-OPS-880 with 0.96 confidence.",
            metadata: { workflow_id: "WF-OPS-880", workflow_name: "High Priority Ops Escalation" }
          },
          {
            agent: "Case Agent",
            status: "COMPLETED",
            detail: "Provisioned CASE-2026-8802 in Ops queue.",
            metadata: { case_id: "CASE-2026-8802" }
          }
        ],
        trace_available: true,
        ui_hints: {
          show_summary_card: true,
          show_agent_timeline: true,
          show_recommended_actions: true,
          show_case_panel: true,
          show_workflow_panel: true,
          show_document_panel: false,
          primary_action: "View Case Status"
        }
      }
    };
  }

  // Default exact user sample response for "Why was my cash transaction rejected?"
  return {
    user: {
      user_id: userId,
      display_name: "ABC Ltd Client User",
      user_type: "external",
      role: "client_user",
      customer_id: "CUST_ABC"
    },
    response: {
      request_id: `3a5a9380-71c2-469d-${Math.floor(Math.random()*8999+1000)}-0acb759596ab`,
      timestamp: new Date().toISOString(),
      user_context: {
        user_id: userId,
        display_name: "ABC Ltd Client User",
        user_type: "external",
        role: "client_user",
        customer_id: "CUST_ABC",
        market: "SG"
      },
      understanding: {
        intent: "EXPLAIN_REJECTION",
        domain: "Cash",
        resolved_entity: {
          type: "transaction",
          transaction_id: "TXN-ABC-9001"
        },
        natural_language_interpretation: "User is asking why the latest entitled cash transaction was rejected."
      },
      resolution_status: "RESOLVED",
      summary: "The latest cash transaction TXN-ABC-9001 was rejected because Beneficiary declaration document does not match payment instruction.",
      root_cause: "Beneficiary declaration document does not match payment instruction.",
      explanation: [
        "The request was interpreted using the customer's entitled context, not a case ID.",
        "The latest rejected cash transaction was identified from customer context.",
        "Rejection reason code: DOCUMENT_MISMATCH.",
        "Beneficiary declaration document does not match payment instruction."
      ],
      recommended_actions: [
        "Upload revised beneficiary declaration and resubmit transaction.",
        "After uploading the corrected document, resubmit the transaction for processing.",
        "If the issue continues, the agent can create an ops review case automatically."
      ],
      workflow: {
        matched: false,
        workflow_id: null,
        workflow_name: null,
        confidence: null,
        steps: []
      },
      case: {
        created: false,
        reason: "The issue is explainable and has a clear self-service resolution."
      },
      document: {},
      agent_execution: [
        {
          agent: "Identity Agent",
          status: "COMPLETED",
          detail: "Resolved user identity and user type.",
          metadata: {
            user_type: "external",
            customer_id: "CUST_ABC"
          }
        },
        {
          agent: "Customer Context Agent",
          status: "COMPLETED",
          detail: "Loaded customer-scoped operational context.",
          metadata: {
            customer_summary: "Customer ABC Ltd has products Cash, Trade, COBAM and 2 recent transactions."
          }
        },
        {
          agent: "Workflow Discovery Agent",
          status: "NO_MATCH",
          detail: "Searched workflow catalog using natural language intent.",
          metadata: {
            workflow_id: null,
            workflow_name: null,
            confidence: null
          }
        },
        {
          agent: "Resolution Agent",
          status: "RESOLVED",
          detail: "Resolved transaction rejection without creating a case.",
          metadata: {
            transaction_id: "TXN-ABC-9001"
          }
        }
      ],
      trace_available: false,
      ui_hints: {
        show_summary_card: true,
        show_agent_timeline: true,
        show_recommended_actions: true,
        show_case_panel: false,
        show_workflow_panel: true,
        primary_action: "Upload corrected document"
      }
    }
  };
}

function generateSampleUploadResponse(filename: string, userId: string = "ext_abc_user", sessionId: string = "demo2") {
  const isSuccess = filename.toLowerCase().includes("valid") || filename.toLowerCase().includes("beneficiary_declaration");

  if (isSuccess) {
    return {
      user: {
        user_id: userId,
        display_name: "ABC Ltd Client User",
        user_type: "external",
        role: "client_user",
        customer_id: "CUST_ABC"
      },
      response: {
        request_id: `req-${Date.now()}-up-ok`,
        timestamp: new Date().toISOString(),
        user_context: {
          user_id: userId,
          display_name: "ABC Ltd Client User",
          user_type: "external",
          role: "client_user",
          customer_id: "CUST_ABC",
          market: "SG"
        },
        understanding: {
          intent: "DOCUMENT_UPLOAD_VALIDATION",
          domain: "Cash",
          resolved_entity: {
            type: "document",
            file_name: filename
          }
        },
        resolution_status: "DOCUMENT_VALIDATION_SUCCESS",
        summary: `Beneficiary declaration document '${filename}' validated successfully against transaction TXN-ABC-9001.`,
        root_cause: "Document verified and matched payment instruction.",
        explanation: [
          "Document type matched expected beneficiary declaration format.",
          "Beneficiary entity name matches payment instruction.",
          "Transaction TXN-ABC-9001 queued for re-processing."
        ],
        recommended_actions: [
          "Resubmit transaction TXN-ABC-9001 for automated clearing.",
          "No further ops document action required."
        ],
        workflow: {
          matched: true,
          workflow_id: "WF-CASH-RESUBMIT",
          workflow_name: "Automated Transaction Clearing",
          confidence: 0.99,
          steps: [
            { step_id: "1", name: "Doc Validation", status: "COMPLETED" },
            { step_id: "2", name: "Entity Check", status: "COMPLETED" },
            { step_id: "3", name: "Clearing Queue", status: "COMPLETED" }
          ]
        },
        case: {
          created: false,
          reason: "Self-service document validation succeeded."
        },
        document: {
          uploaded: true,
          file_name: filename,
          storage_path: `/uploads/CUST_ABC/${filename}`,
          validation_status: "SUCCESS"
        },
        agent_execution: [
          {
            agent: "Document Agent",
            status: "COMPLETED",
            detail: "Validated uploaded document structure and signatures.",
            metadata: {
              file_name: filename,
              status: "SUCCESS",
              matched_entity: "ABC Ltd Beneficiary"
            }
          },
          {
            agent: "Resolution Agent",
            status: "RESOLVED",
            detail: "Cleared transaction for automated resubmission.",
            metadata: { transaction_id: "TXN-ABC-9001" }
          }
        ],
        trace_available: true,
        ui_hints: {
          show_document_panel: true,
          show_recommended_actions: true,
          show_agent_timeline: true,
          show_workflow_panel: true,
          primary_action: "Resubmit Transaction"
        }
      }
    };
  }

  // Default exact upload response provided by user for "trident-entity-search-entmt_v2.txt"
  return {
    user: {
      user_id: userId,
      display_name: "ABC Ltd Client User",
      user_type: "external",
      role: "client_user",
      customer_id: "CUST_ABC"
    },
    response: {
      request_id: `24d5f951-6e99-46e5-${Math.floor(Math.random()*8999+1000)}-c1c55b0978b8`,
      timestamp: new Date().toISOString(),
      user_context: {
        user_id: userId,
        display_name: "ABC Ltd Client User",
        user_type: "external",
        role: "client_user",
        customer_id: "CUST_ABC",
        market: "SG"
      },
      understanding: {
        intent: "DOCUMENT_UPLOAD_VALIDATION",
        domain: "Cash",
        resolved_entity: {
          type: "document",
          file_name: filename
        }
      },
      resolution_status: "DOCUMENT_VALIDATION_FAILED",
      summary: "Document validation failed because the expected supporting declaration was not identified.",
      root_cause: "Expected supporting declaration was not identified.",
      explanation: [
        "Document type could not be confidently matched to the expected beneficiary declaration.",
        "Supporting declaration may be missing or incorrectly named."
      ],
      recommended_actions: [
        "Upload beneficiary declaration document.",
        "Ensure beneficiary details match the payment instruction."
      ],
      workflow: {},
      case: {
        created: false,
        reason: "Case may be created if the user cannot provide the required document."
      },
      document: {
        uploaded: true,
        file_name: filename,
        storage_path: `C:\\Users\\agentic-backend\\uploads\\CUST_ABC\\${filename}`,
        validation_status: "FAILED"
      },
      agent_execution: [
        {
          agent: "Document Agent",
          status: "COMPLETED",
          detail: "Stored and validated uploaded document.",
          metadata: {
            file_name: filename,
            status: "FAILED"
          }
        }
      ],
      trace_available: false,
      ui_hints: {
        show_document_panel: true,
        show_recommended_actions: true,
        show_agent_timeline: true,
        primary_action: "Upload correct document"
      }
    }
  };
}

// API Routes

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    service: "AgenticServ UI Proxy Server",
    backend_config: backendConfig,
    time: new Date().toISOString()
  });
});

app.get("/api/config", (req, res) => {
  res.json(backendConfig);
});

app.post("/api/config", (req, res) => {
  const { backendUrl, useSimulation } = req.body;
  if (typeof backendUrl === 'string') backendConfig.backendUrl = backendUrl;
  if (typeof useSimulation === 'boolean') backendConfig.useSimulation = useSimulation;
  res.json({ success: true, backendConfig });
});

app.get("/api/scenarios", (req, res) => {
  res.json([
    {
      id: "scenario-1",
      title: "1. Cash Rejection Inquiry",
      subtitle: "Ask why TXN-ABC-9001 was rejected",
      message: "Why was my cash transaction rejected?",
      session_id: "demo1",
      user_id: "ext_abc_user",
      iconType: "rejection"
    },
    {
      id: "scenario-2",
      title: "2. Upload Document (Invalid)",
      subtitle: "Upload trident-entity-search-entmt_v2.txt",
      message: "Uploading document trident-entity-search-entmt_v2.txt",
      session_id: "demo2",
      user_id: "ext_abc_user",
      iconType: "upload_fail"
    },
    {
      id: "scenario-3",
      title: "3. Upload Document (Valid)",
      subtitle: "Upload beneficiary_declaration_v2.pdf",
      message: "Uploading document beneficiary_declaration_v2.pdf",
      session_id: "demo3",
      user_id: "ext_abc_user",
      iconType: "upload_success"
    },
    {
      id: "scenario-4",
      title: "4. Request Ops Escalation",
      subtitle: "Request human ops review for trade order",
      message: "I need human ops to review this trade order immediately",
      session_id: "demo4",
      user_id: "ext_abc_user",
      iconType: "escalation"
    }
  ]);
});

// Main /api/chat Endpoint
app.post("/api/chat", async (req, res) => {
  const { user_id = "ext_abc_user", message, session_id = "demo1" } = req.body;

  // Try forwarding to local backend if not in forced simulation mode
  if (!backendConfig.useSimulation) {
    try {
      const targetUrl = `${backendConfig.backendUrl.replace(/\/$/, '')}/chat`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      const resp = await fetch(targetUrl, {
        method: "POST",
        headers: {
          "Accept": "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ user_id, message, session_id }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (resp.ok) {
        const data = await resp.json();
        return res.json(data);
      }
    } catch (err) {
      console.warn("Target backend offline or unreachable, falling back to agentic simulator:", (err as Error).message);
    }
  }

  // Fallback to local high-fidelity agentic simulator matching user spec
  const sampleResp = generateSampleChatResponse(message, user_id, session_id);
  res.json(sampleResp);
});

// Main /api/upload Endpoint
app.post("/api/upload", upload.single("file"), async (req, res) => {
  const user_id = req.body.user_id || "ext_abc_user";
  const session_id = req.body.session_id || "demo2";
  const fileName = req.file ? req.file.originalname : (req.body.file_name || "trident-entity-search-entmt_v2.txt");

  if (!backendConfig.useSimulation) {
    try {
      const targetUrl = `${backendConfig.backendUrl.replace(/\/$/, '')}/upload`;
      const formData = new FormData();
      formData.append("user_id", user_id);
      formData.append("session_id", session_id);
      if (req.file) {
        const blob = new Blob([req.file.buffer], { type: req.file.mimetype });
        formData.append("file", blob, req.file.originalname);
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      const resp = await fetch(targetUrl, {
        method: "POST",
        headers: { "Accept": "application/json" },
        body: formData,
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (resp.ok) {
        const data = await resp.json();
        return res.json(data);
      }
    } catch (err) {
      console.warn("Target backend upload endpoint unreachable, using agentic upload simulator:", (err as Error).message);
    }
  }

  const sampleUpload = generateSampleUploadResponse(fileName, user_id, session_id);
  res.json(sampleUpload);
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AgenticServ backend proxy & server running on http://localhost:${PORT}`);
  });
}

startServer();
