import React, { useState, useEffect } from 'react';
import { UserType, ChatMessage, ChatResponseWrapper, PresetScenario, BackendConfig } from './types';
import { sendChatMessage, uploadDocumentFile, getPresetScenarios, getBackendConfig, updateBackendConfig } from './services/api';
import { Header } from './components/Header';
import { ScenarioPresetsBar } from './components/ScenarioPresetsBar';
import { ExternalView } from './components/ExternalView';
import { InternalView } from './components/InternalView';
import { WidgetEmbedDrawer } from './components/WidgetEmbedDrawer';
import { BackendConfigModal } from './components/BackendConfigModal';

export default function App() {
  const [currentView, setCurrentView] = useState<UserType>('external');
  const [displayMode, setDisplayMode] = useState<'full' | 'widget_preview'>('full');

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-msg',
      sender: 'agent',
      user_id: 'agentic_ai',
      display_name: 'AgenticServ AI',
      text: 'Hello! I am your Agentic AI Customer Servicing Assistant. How can I assist you with your cash transactions, entitlement status, or document verification today?',
      timestamp: new Date().toISOString()
    }
  ]);

  const [lastResponseWrapper, setLastResponseWrapper] = useState<ChatResponseWrapper | null>(null);
  const [scenarios, setScenarios] = useState<PresetScenario[]>([]);
  const [activeScenarioId, setActiveScenarioId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const [backendConfig, setBackendConfig] = useState<BackendConfig>({
    backendUrl: 'http://127.0.0.1:8000',
    useSimulation: true,
    isBackendConnected: false
  });

  const [isEmbedModalOpen, setIsEmbedModalOpen] = useState(false);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);

  // Initial load
  useEffect(() => {
    async function initData() {
      try {
        const [scList, cfg] = await Promise.all([
          getPresetScenarios(),
          getBackendConfig()
        ]);
        if (scList.length > 0) setScenarios(scList);
        setBackendConfig(cfg);
      } catch (err) {
        console.warn("Failed to load initial presets or config:", err);
      }
    }
    initData();
  }, []);

  // Send message handler
  const handleSendMessage = async (text: string, userId = "ext_abc_user", sessionId = "demo1") => {
    const userMsgId = `user-${Date.now()}`;
    const userMsg: ChatMessage = {
      id: userMsgId,
      sender: 'user',
      user_id: userId,
      display_name: 'ABC Ltd Client User',
      text,
      timestamp: new Date().toISOString()
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const wrapper = await sendChatMessage(text, userId, sessionId);
      setLastResponseWrapper(wrapper);

      const agentMsg: ChatMessage = {
        id: `agent-${Date.now()}`,
        sender: 'agent',
        user_id: 'agentic_ai',
        display_name: 'AgenticServ AI',
        text: wrapper.response.summary || 'Processing completed.',
        timestamp: wrapper.response.timestamp || new Date().toISOString(),
        payload: wrapper
      };

      setMessages((prev) => [...prev, agentMsg]);
    } catch (error) {
      console.error("Error sending message:", error);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'agent',
        user_id: 'agentic_ai',
        display_name: 'AgenticServ AI (Error)',
        text: `Error contacting backend: ${(error as Error).message}`,
        timestamp: new Date().toISOString()
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Upload file handler
  const handleFileUpload = async (file: File, userId = "ext_abc_user", sessionId = "demo2") => {
    const userMsgId = `user-up-${Date.now()}`;
    const userMsg: ChatMessage = {
      id: userMsgId,
      sender: 'user',
      user_id: userId,
      display_name: 'ABC Ltd Client User',
      text: `Uploaded document: ${file.name}`,
      timestamp: new Date().toISOString(),
      attachment: {
        name: file.name,
        size: file.size,
        status: 'uploaded'
      }
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const wrapper = await uploadDocumentFile(file, userId, sessionId);
      setLastResponseWrapper(wrapper);

      const agentMsg: ChatMessage = {
        id: `agent-up-${Date.now()}`,
        sender: 'agent',
        user_id: 'agentic_ai',
        display_name: 'AgenticServ AI',
        text: wrapper.response.summary || 'Document uploaded and analyzed.',
        timestamp: wrapper.response.timestamp || new Date().toISOString(),
        payload: wrapper
      };

      setMessages((prev) => [...prev, agentMsg]);
    } catch (error) {
      console.error("Error uploading document:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Quick Demo Upload Handler for Presets
  const handleQuickUploadDemo = (filename: string) => {
    const dummyFile = new File(["dummy content for demo"], filename, { type: "text/plain" });
    handleFileUpload(dummyFile, "ext_abc_user", "demo2");
  };

  // Scenario Preset Trigger
  const handleSelectScenario = (sc: PresetScenario) => {
    setActiveScenarioId(sc.id);
    if (sc.iconType === 'upload_fail' || sc.iconType === 'upload_success') {
      const fname = sc.message.includes('trident') ? 'trident-entity-search-entmt_v2.txt' : 'beneficiary_declaration_v2.pdf';
      handleQuickUploadDemo(fname);
    } else {
      handleSendMessage(sc.message, sc.user_id, sc.session_id);
    }
  };

  // Ops Desk response broadcast handler
  const handleSendOpsResponse = (text: string) => {
    const opsMsg: ChatMessage = {
      id: `ops-${Date.now()}`,
      sender: 'agent',
      user_id: 'ops_agent_01',
      display_name: 'Ops Specialist Desk',
      text: `[Ops Broadcast] ${text}`,
      timestamp: new Date().toISOString()
    };
    setMessages((prev) => [...prev, opsMsg]);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Header with Dual View Controls */}
      <Header
        currentView={currentView}
        onViewChange={setCurrentView}
        displayMode={displayMode}
        onDisplayModeChange={setDisplayMode}
        backendConfig={backendConfig}
        onOpenConfig={() => setIsConfigModalOpen(true)}
        onOpenEmbedModal={() => setIsEmbedModalOpen(true)}
      />

      {/* Demo Scenario Presets Bar */}
      <ScenarioPresetsBar
        scenarios={scenarios}
        activeScenarioId={activeScenarioId}
        onSelectScenario={handleSelectScenario}
        isLoading={isLoading}
      />

      {/* Main View Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto">
        {currentView === 'external' ? (
          <ExternalView
            messages={messages}
            onSendMessage={handleSendMessage}
            onFileUpload={handleFileUpload}
            isLoading={isLoading}
            displayMode={displayMode}
            onQuickUploadDemo={handleQuickUploadDemo}
          />
        ) : (
          <InternalView
            messages={messages}
            lastResponseWrapper={lastResponseWrapper}
            onSendOpsResponse={handleSendOpsResponse}
            isLoading={isLoading}
          />
        )}
      </main>

      {/* Pluggable Embed Code SDK Drawer */}
      <WidgetEmbedDrawer
        isOpen={isEmbedModalOpen}
        onClose={() => setIsEmbedModalOpen(false)}
        backendUrl={backendConfig.backendUrl}
      />

      {/* Backend Settings Modal */}
      <BackendConfigModal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
        config={backendConfig}
        onSaveConfig={async (newCfg) => {
          const updated = await updateBackendConfig(newCfg);
          setBackendConfig((prev) => ({ ...prev, ...updated }));
        }}
      />
    </div>
  );
}
