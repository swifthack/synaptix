import React from 'react';
import { UserType, BackendConfig } from '../types';
import {
  Users,
  ShieldCheck,
  Code,
  Settings,
  Bot,
  Activity,
  Layers,
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface HeaderProps {
  currentView: UserType;
  onViewChange: (view: UserType) => void;
  displayMode: 'full' | 'widget_preview';
  onDisplayModeChange: (mode: 'full' | 'widget_preview') => void;
  backendConfig: BackendConfig;
  onOpenConfig: () => void;
  onOpenEmbedModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onViewChange,
  displayMode,
  onDisplayModeChange,
  backendConfig,
  onOpenConfig,
  onOpenEmbedModal
}) => {
  return (
    <header id="main-header" className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Product Identity */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/20 ring-1 ring-white/20">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg tracking-tight text-slate-100">AgenticServ</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30">
                  Agentic AI
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                Enterprise Pluggable Customer Service Engine
              </p>
            </div>
          </div>

          {/* Dual View Mode Switcher */}
          <div className="flex items-center space-x-1 sm:space-x-2 bg-slate-950/80 p-1 rounded-xl border border-slate-800">
            <button
              id="view-external-btn"
              onClick={() => onViewChange('external')}
              className={`flex items-center space-x-2 px-3 sm:px-4 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                currentView === 'external'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>External View (Client)</span>
            </button>

            <button
              id="view-internal-btn"
              onClick={() => onViewChange('internal')}
              className={`flex items-center space-x-2 px-3 sm:px-4 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                currentView === 'internal'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Internal View (Ops Workbench)</span>
            </button>
          </div>

          {/* Action Tools & Config */}
          <div className="flex items-center space-x-2">
            {/* Display Mode Toggle */}
            <div className="hidden lg:flex items-center bg-slate-950/80 p-1 rounded-lg border border-slate-800 text-xs">
              <button
                id="display-full-btn"
                onClick={() => onDisplayModeChange('full')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  displayMode === 'full' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Full View
              </button>
              <button
                id="display-widget-btn"
                onClick={() => onDisplayModeChange('widget_preview')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  displayMode === 'widget_preview' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Widget Launcher Demo
              </button>
            </div>

            {/* Code Embed Button */}
            <button
              id="open-embed-modal-btn"
              onClick={onOpenEmbedModal}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
              title="Get Pluggable Widget SDK Code"
            >
              <Code className="w-4 h-4 text-blue-400" />
              <span className="hidden sm:inline">Pluggable SDK</span>
            </button>

            {/* Backend Config Status Button */}
            <button
              id="open-config-btn"
              onClick={onOpenConfig}
              className="flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
            >
              <span className={`w-2 h-2 rounded-full ${backendConfig.useSimulation ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400'}`} />
              <span className="hidden md:inline text-slate-300">
                {backendConfig.useSimulation ? 'Agentic Simulator' : 'Local FastAPI (8000)'}
              </span>
              <Settings className="w-3.5 h-3.5 text-slate-400" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
