import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, ChatResponseWrapper } from '../types';
import {
  Send,
  Paperclip,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  UploadCloud,
  FileText,
  User,
  Bot,
  Building2,
  Globe,
  Sparkles,
  ArrowRight,
  RefreshCw,
  Maximize2,
  Minimize2,
  MessageSquare
} from 'lucide-react';

interface ExternalViewProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  onFileUpload: (file: File) => void;
  isLoading: boolean;
  displayMode: 'full' | 'widget_preview';
  onQuickUploadDemo: (filename: string) => void;
}

export const ExternalView: React.FC<ExternalViewProps> = ({
  messages,
  onSendMessage,
  onFileUpload,
  isLoading,
  displayMode,
  onQuickUploadDemo
}) => {
  const [inputText, setInputText] = useState('');
  const [isWidgetOpen, setIsWidgetOpen] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileUpload(file);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      onFileUpload(file);
    }
  };

  const renderMessageContent = (msg: ChatMessage) => {
    const isAgent = msg.sender === 'agent';
    const payload = msg.payload?.response;

    return (
      <div className="space-y-3">
        {/* Main Text / Natural Language Explanation */}
        <p className="text-sm leading-relaxed whitespace-pre-line">{msg.text}</p>

        {/* Attachment Card if user uploaded file */}
        {msg.attachment && (
          <div className="flex items-center space-x-3 bg-slate-800/80 p-2.5 rounded-lg border border-slate-700 text-xs">
            <FileText className="w-5 h-5 text-blue-400 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-medium text-slate-200 truncate">{msg.attachment.name}</p>
              <p className="text-slate-400">{(msg.attachment.size / 1024).toFixed(1)} KB</p>
            </div>
            {msg.attachment.status === 'uploaded' && (
              <span className="text-emerald-400 text-xs flex items-center gap-1 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" /> Uploaded
              </span>
            )}
          </div>
        )}

        {/* Structured Agentic Response UI Cards */}
        {isAgent && payload && (
          <div className="space-y-3 mt-3">
            {/* Summary Card */}
            {payload.ui_hints?.show_summary_card && (
              <div id={`summary-card-${msg.id}`} className="bg-slate-900/90 border border-slate-700/80 rounded-xl p-3.5 shadow-sm text-xs space-y-2.5">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center space-x-2">
                    <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                    <span className="font-semibold text-slate-200">
                      {payload.understanding?.intent || 'Service Query'} Summary
                    </span>
                  </div>
                  {payload.understanding?.resolved_entity?.transaction_id && (
                    <span className="font-mono bg-slate-800 text-blue-300 px-2 py-0.5 rounded text-[11px] font-medium border border-slate-700">
                      ID: {payload.understanding.resolved_entity.transaction_id}
                    </span>
                  )}
                </div>

                <p className="text-slate-300 leading-normal font-medium">{payload.summary}</p>

                {/* Root cause if available */}
                {payload.root_cause && (
                  <div className="bg-rose-950/30 border border-rose-900/40 p-2.5 rounded-lg text-rose-200 text-xs flex items-start space-x-2">
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-rose-300 block">Root Cause Analysis:</span>
                      <span>{payload.root_cause}</span>
                    </div>
                  </div>
                )}

                {/* Bulleted Explanation List */}
                {payload.explanation && payload.explanation.length > 0 && (
                  <div className="space-y-1 pt-1 text-slate-300">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Details:</span>
                    <ul className="list-disc list-inside space-y-1 text-slate-300">
                      {payload.explanation.map((item, idx) => (
                        <li key={idx} className="leading-snug">{item}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* Document Status Panel */}
            {payload.document && payload.document.uploaded && (
              <div id={`doc-panel-${msg.id}`} className="bg-slate-900/90 border border-slate-700 rounded-xl p-3 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-slate-300 flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-blue-400" /> Document Status
                  </span>
                  <span className={`px-2 py-0.5 rounded font-semibold text-[10px] uppercase ${
                    payload.document.validation_status === 'SUCCESS'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}>
                    {payload.document.validation_status || 'CHECKED'}
                  </span>
                </div>
                <div className="text-slate-400 font-mono text-[11px]">
                  File: {payload.document.file_name}
                </div>
              </div>
            )}

            {/* Recommended Action Buttons */}
            {payload.ui_hints?.show_recommended_actions && payload.recommended_actions && payload.recommended_actions.length > 0 && (
              <div id={`actions-panel-${msg.id}`} className="space-y-2 pt-1">
                <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center space-x-1">
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>Recommended Next Steps:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {payload.recommended_actions.map((act, idx) => {
                    const isPrimary = idx === 0;
                    return (
                      <button
                        key={idx}
                        id={`action-btn-${msg.id}-${idx}`}
                        disabled={isLoading}
                        onClick={() => {
                          if (act.toLowerCase().includes("upload")) {
                            onQuickUploadDemo("beneficiary_declaration_v2.pdf");
                          } else {
                            onSendMessage(act);
                          }
                        }}
                        className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                          isPrimary
                            ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-sm shadow-blue-500/20'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                        }`}
                      >
                        <span>{act}</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  // Chat UI Main Body Render
  const renderChatBody = () => (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
      {/* Top Banner / User Context Bar */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-full bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <User className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-semibold text-sm text-slate-100">ABC Ltd Client Portal</span>
              <span className="text-[10px] font-mono bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700">
                EXT USER
              </span>
            </div>
            <div className="flex items-center space-x-3 text-xs text-slate-400 mt-0.5">
              <span className="flex items-center gap-1">
                <Building2 className="w-3 h-3 text-slate-500" /> CUST_ABC
              </span>
              <span className="flex items-center gap-1">
                <Globe className="w-3 h-3 text-slate-500" /> Market: SG
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <span className="flex items-center space-x-1.5 text-xs text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="font-medium">Agentic Assistant Live</span>
          </span>
        </div>
      </div>

      {/* Message List */}
      <div
        id="external-chat-messages"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`flex-1 overflow-y-auto p-4 space-y-4 relative ${
          isDragging ? 'bg-blue-950/20 border-2 border-dashed border-blue-500/50' : ''
        }`}
      >
        {messages.map((msg) => {
          const isAgent = msg.sender === 'agent';
          return (
            <div
              key={msg.id}
              className={`flex items-start space-x-3 ${isAgent ? 'justify-start' : 'justify-end'}`}
            >
              {isAgent && (
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white shrink-0 mt-0.5 shadow-md shadow-blue-600/30">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 shadow-sm border ${
                  isAgent
                    ? 'bg-slate-900 border-slate-800 text-slate-100'
                    : 'bg-blue-600 border-blue-500 text-white'
                }`}
              >
                <div className="flex items-center justify-between space-x-4 mb-1 text-[11px] opacity-75">
                  <span className="font-medium">{msg.display_name}</span>
                  <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                {renderMessageContent(msg)}
              </div>

              {!isAgent && (
                <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 shrink-0 mt-0.5 border border-slate-700">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center space-x-3 text-slate-400 text-xs">
            <div className="w-8 h-8 rounded-full bg-blue-600/30 flex items-center justify-center text-blue-400 animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-slate-900 p-3 rounded-2xl border border-slate-800 flex items-center space-x-2">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-400" />
              <span>Agentic AI analyzing intent & context...</span>
            </div>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* Input Form & File Dropzone */}
      <div className="p-3 bg-slate-900 border-t border-slate-800">
        {/* Quick File Attach Shortcut helper */}
        <div className="flex items-center justify-between mb-2 px-1 text-xs text-slate-400">
          <span className="flex items-center gap-1.5 text-slate-400">
            <UploadCloud className="w-3.5 h-3.5 text-blue-400" />
            Drag & drop document or use preset buttons
          </span>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => onQuickUploadDemo("trident-entity-search-entmt_v2.txt")}
              className="text-[11px] text-slate-400 hover:text-rose-400 underline"
            >
              Demo Invalid File
            </button>
            <span>•</span>
            <button
              onClick={() => onQuickUploadDemo("beneficiary_declaration_v2.pdf")}
              className="text-[11px] text-slate-400 hover:text-emerald-400 underline"
            >
              Demo Valid File
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="flex items-center space-x-2">
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleFileChange}
            className="hidden"
            id="chat-file-input"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            title="Attach Document"
          >
            <Paperclip className="w-4 h-4" />
          </button>

          <input
            id="chat-text-input"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type your client servicing query (e.g. Why was my transaction rejected?)"
            className="flex-1 bg-slate-950 border border-slate-800 focus:border-blue-500 rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-all"
          />

          <button
            id="chat-send-btn"
            type="submit"
            disabled={!inputText.trim() || isLoading}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-medium text-sm flex items-center space-x-1.5 transition-colors shadow-md shadow-blue-600/20"
          >
            <span>Send</span>
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );

  // If in Floating Widget Preview mode: render simulated Corporate Banking Portal background with floating widget launcher
  if (displayMode === 'widget_preview') {
    return (
      <div className="relative min-h-[calc(100vh-112px)] bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden flex flex-col">
        {/* Simulated Website Header */}
        <div className="bg-slate-950 border-b border-slate-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white text-xs">
              ABC
            </div>
            <span className="font-semibold text-slate-200 text-sm">ABC Global Institutional Portal</span>
          </div>
          <div className="flex items-center space-x-4 text-xs text-slate-400">
            <span>Accounts</span>
            <span>Payments</span>
            <span className="text-blue-400 font-medium">Cash Management</span>
            <span>Reports</span>
          </div>
        </div>

        {/* Simulated Web Contents */}
        <div className="flex-1 p-8 space-y-6 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900">
          <div className="max-w-4xl space-y-4">
            <h2 className="text-2xl font-bold text-slate-100">Client Cash Operations Dashboard</h2>
            <p className="text-sm text-slate-400">
              Welcome back, <strong className="text-slate-200">ABC Ltd Client User</strong>. Manage your corporate transactions, check entitlement context, and track real-time agentic servicing updates.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
              <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs text-slate-400">Recent Transaction</span>
                <p className="text-lg font-mono font-bold text-rose-400">TXN-ABC-9001</p>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Status: REJECTED</span>
                  <span className="text-slate-400">SGD 150,000.00</span>
                </div>
              </div>

              <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs text-slate-400">Market Entitlement</span>
                <p className="text-lg font-bold text-slate-200">Singapore (SG)</p>
                <span className="text-xs text-blue-400 font-medium">Cash & Trade Active</span>
              </div>

              <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs text-slate-400">Agentic AI Servicing</span>
                <p className="text-lg font-bold text-emerald-400">Pluggable Active</p>
                <span className="text-xs text-slate-400">Floating Chat Launcher Ready</span>
              </div>
            </div>
          </div>
        </div>

        {/* Floating Chat Widget Popup */}
        {isWidgetOpen ? (
          <div className="absolute bottom-6 right-6 w-[420px] max-w-[90vw] h-[600px] z-50 shadow-2xl transition-all duration-300">
            <div className="relative h-full">
              <button
                onClick={() => setIsWidgetOpen(false)}
                className="absolute top-3 right-3 z-10 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                title="Minimize Widget"
              >
                <Minimize2 className="w-4 h-4" />
              </button>
              {renderChatBody()}
            </div>
          </div>
        ) : (
          <button
            onClick={() => setIsWidgetOpen(true)}
            className="absolute bottom-6 right-6 z-50 flex items-center space-x-2.5 px-5 py-3.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white shadow-xl shadow-blue-600/30 font-semibold text-sm transition-all transform hover:scale-105"
          >
            <MessageSquare className="w-5 h-5" />
            <span>Chat with Agentic AI</span>
          </button>
        )}
      </div>
    );
  }

  // Full Screen Client View
  return (
    <div className="h-[calc(100vh-112px)] p-2 sm:p-4">
      {renderChatBody()}
    </div>
  );
};
