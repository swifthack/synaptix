import React, { useState } from 'react';
import { ChatMessage, AgentExecutionStep, ChatResponseWrapper } from '../types';
import {
  ShieldCheck,
  Cpu,
  GitBranch,
  FileSearch,
  AlertCircle,
  CheckCircle,
  XCircle,
  Terminal,
  Layers,
  FileText,
  User,
  Copy,
  Check,
  Send,
  Building,
  Globe,
  Clock,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface InternalViewProps {
  messages: ChatMessage[];
  lastResponseWrapper: ChatResponseWrapper | null;
  onSendOpsResponse: (text: string) => void;
  isLoading: boolean;
}

export const InternalView: React.FC<InternalViewProps> = ({
  messages,
  lastResponseWrapper,
  onSendOpsResponse,
  isLoading
}) => {
  const [activeTab, setActiveTab] = useState<'timeline' | 'understanding' | 'workflow_case' | 'document' | 'json'>('timeline');
  const [copied, setCopied] = useState(false);
  const [opsInputText, setOpsInputText] = useState('');

  const payload = lastResponseWrapper?.response;
  const user = lastResponseWrapper?.user;

  const handleCopyJson = () => {
    if (lastResponseWrapper) {
      navigator.clipboard.writeText(JSON.stringify(lastResponseWrapper, null, 2));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleOpsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!opsInputText.trim()) return;
    onSendOpsResponse(opsInputText.trim());
    setOpsInputText('');
  };

  const getAgentStatusBadge = (status: string) => {
    switch (status.toUpperCase()) {
      case 'COMPLETED':
      case 'RESOLVED':
        return (
          <span className="flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            <CheckCircle className="w-3 h-3 text-emerald-400" />
            <span>{status}</span>
          </span>
        );
      case 'NO_MATCH':
        return (
          <span className="flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            <AlertCircle className="w-3 h-3 text-amber-400" />
            <span>NO MATCH</span>
          </span>
        );
      case 'FAILED':
        return (
          <span className="flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">
            <XCircle className="w-3 h-3 text-rose-400" />
            <span>FAILED</span>
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
            {status}
          </span>
        );
    }
  };

  return (
    <div id="internal-ops-workspace" className="h-[calc(100vh-112px)] p-2 sm:p-4 grid grid-cols-1 lg:grid-cols-12 gap-4">
      {/* Left Panel: Client Session Context & Live Chat Monitor (4 Cols) */}
      <div className="lg:col-span-4 flex flex-col bg-slate-950 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
        {/* Panel Header */}
        <div className="bg-slate-900 border-b border-slate-800 p-3.5 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-purple-400" />
            <div>
              <h3 className="font-semibold text-sm text-slate-100">Ops Client Monitor</h3>
              <p className="text-[11px] text-slate-400">Live Client Session Monitoring</p>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-medium bg-purple-500/20 text-purple-300 border border-purple-500/30">
            ROLE: OPS_DESK
          </span>
        </div>

        {/* Client Entitlement Metadata Summary */}
        <div className="bg-slate-900/60 p-3 border-b border-slate-800/80 text-xs space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-400 block">User Identity</span>
              <span className="font-medium text-slate-200">{user?.display_name || 'ABC Ltd Client User'}</span>
              <span className="text-[10px] font-mono text-slate-500 block">({user?.user_id || 'ext_abc_user'})</span>
            </div>
            <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Customer Account</span>
              <span className="font-medium text-slate-200">{user?.customer_id || 'CUST_ABC'}</span>
              <span className="text-[10px] text-blue-400 block">Market: {payload?.user_context?.market || 'SG'}</span>
            </div>
          </div>
        </div>

        {/* Message Log */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`p-3 rounded-xl border text-xs space-y-1 ${
                m.sender === 'agent'
                  ? 'bg-slate-900/80 border-slate-800 text-slate-200'
                  : 'bg-slate-900/40 border-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center justify-between text-[10px] text-slate-400">
                <span className="font-semibold text-slate-300">{m.display_name}</span>
                <span>{new Date(m.timestamp).toLocaleTimeString()}</span>
              </div>
              <p className="text-slate-200 leading-relaxed">{m.text}</p>
            </div>
          ))}
        </div>

        {/* Ops Action Broadcast Input */}
        <div className="p-3 bg-slate-900 border-t border-slate-800">
          <form onSubmit={handleOpsSubmit} className="flex space-x-2">
            <input
              type="text"
              value={opsInputText}
              onChange={(e) => setOpsInputText(e.target.value)}
              placeholder="Send Ops Agent instruction to Client Chat..."
              className="flex-1 bg-slate-950 border border-slate-800 focus:border-purple-500 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none"
            />
            <button
              type="submit"
              disabled={!opsInputText.trim()}
              className="px-3 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-medium text-xs flex items-center space-x-1"
            >
              <span>Broadcast</span>
              <Send className="w-3 h-3" />
            </button>
          </form>
        </div>
      </div>

      {/* Right Panel: Agentic AI Inspection & Execution Workbench (8 Cols) */}
      <div className="lg:col-span-8 flex flex-col bg-slate-950 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
        {/* Navigation Tabs */}
        <div className="bg-slate-900 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between overflow-x-auto">
          <div className="flex items-center space-x-1">
            <button
              id="tab-timeline-btn"
              onClick={() => setActiveTab('timeline')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'timeline'
                  ? 'bg-purple-600/20 text-purple-300 border border-purple-500/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Cpu className="w-3.5 h-3.5 text-purple-400" />
              <span>Agent Execution Graph ({payload?.agent_execution?.length || 0})</span>
            </button>

            <button
              id="tab-understanding-btn"
              onClick={() => setActiveTab('understanding')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'understanding'
                  ? 'bg-purple-600/20 text-purple-300 border border-purple-500/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <FileSearch className="w-3.5 h-3.5 text-blue-400" />
              <span>Understanding & Rationale</span>
            </button>

            <button
              id="tab-workflow-btn"
              onClick={() => setActiveTab('workflow_case')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'workflow_case'
                  ? 'bg-purple-600/20 text-purple-300 border border-purple-500/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <GitBranch className="w-3.5 h-3.5 text-amber-400" />
              <span>Workflow & Case</span>
            </button>

            <button
              id="tab-document-btn"
              onClick={() => setActiveTab('document')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'document'
                  ? 'bg-purple-600/20 text-purple-300 border border-purple-500/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-emerald-400" />
              <span>Document Vault</span>
            </button>

            <button
              id="tab-json-btn"
              onClick={() => setActiveTab('json')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'json'
                  ? 'bg-purple-600/20 text-purple-300 border border-purple-500/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Terminal className="w-3.5 h-3.5 text-slate-400" />
              <span>Raw API JSON</span>
            </button>
          </div>

          {activeTab === 'json' && (
            <button
              onClick={handleCopyJson}
              className="flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy JSON'}</span>
            </button>
          )}
        </div>

        {/* Tab Contents */}
        <div className="flex-1 overflow-y-auto p-4">
          {!payload ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-500 text-xs space-y-2">
              <Cpu className="w-8 h-8 text-slate-600 animate-pulse" />
              <span>Waiting for Agentic AI execution trace payload...</span>
            </div>
          ) : (
            <>
              {/* Tab 1: Agentic Execution Graph & Sub-Agent Timeline */}
              {activeTab === 'timeline' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div>
                      <span className="text-xs text-slate-400">Request ID:</span>
                      <p className="font-mono text-xs font-bold text-slate-200">{payload.request_id}</p>
                    </div>
                    <div>
                      <span className="text-xs text-slate-400">Resolution Status:</span>
                      <p className="font-semibold text-xs text-emerald-400">{payload.resolution_status}</p>
                    </div>
                    <div>
                      <span className="text-xs text-slate-400">Timestamp:</span>
                      <p className="text-xs text-slate-300">{new Date(payload.timestamp).toLocaleString()}</p>
                    </div>
                  </div>

                  <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    Agent Pipeline Execution Sequence
                  </h4>

                  <div className="relative border-l-2 border-slate-800 ml-4 space-y-6 pl-6 py-2">
                    {payload.agent_execution?.map((step: AgentExecutionStep, idx: number) => (
                      <div key={idx} className="relative group">
                        {/* Node Circle */}
                        <div className="absolute -left-[31px] top-1.5 w-4 h-4 rounded-full bg-slate-950 border-2 border-purple-500 flex items-center justify-center">
                          <div className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                        </div>

                        {/* Card */}
                        <div className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 p-4 rounded-xl space-y-2.5 transition-all">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <span className="w-6 h-6 rounded-lg bg-purple-900/40 text-purple-300 text-xs font-bold flex items-center justify-center border border-purple-700/50">
                                #{idx + 1}
                              </span>
                              <h5 className="font-bold text-sm text-slate-100">{step.agent}</h5>
                            </div>
                            {getAgentStatusBadge(step.status)}
                          </div>

                          <p className="text-xs text-slate-300">{step.detail}</p>

                          {/* Metadata Tags */}
                          {step.metadata && Object.keys(step.metadata).length > 0 && (
                            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800/80 font-mono text-[11px] space-y-1">
                              <span className="text-[10px] text-slate-500 uppercase font-semibold block">Execution Metadata:</span>
                              {Object.entries(step.metadata).map(([k, v]) => (
                                <div key={k} className="flex items-start justify-between">
                                  <span className="text-slate-400">{k}:</span>
                                  <span className="text-purple-300 truncate max-w-[300px] font-medium">{String(v)}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tab 2: Understanding & Natural Language Rationale */}
              {activeTab === 'understanding' && (
                <div className="space-y-4 text-xs">
                  <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                    <h4 className="font-semibold text-sm text-slate-100 flex items-center gap-2">
                      <FileSearch className="w-4 h-4 text-blue-400" /> Agentic Understanding & Entity Resolution
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[11px]">Intent Name</span>
                        <span className="font-bold text-blue-300 text-sm">{payload.understanding?.intent || 'N/A'}</span>
                      </div>
                      <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[11px]">Domain Context</span>
                        <span className="font-bold text-slate-200 text-sm">{payload.understanding?.domain || 'N/A'}</span>
                      </div>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                      <span className="text-slate-400 block text-[11px]">Resolved Entity</span>
                      <pre className="font-mono text-emerald-300 text-xs whitespace-pre-wrap">
                        {JSON.stringify(payload.understanding?.resolved_entity, null, 2)}
                      </pre>
                    </div>

                    {payload.understanding?.natural_language_interpretation && (
                      <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[11px] font-semibold mb-1">Natural Language Interpretation:</span>
                        <p className="text-slate-200 text-xs italic leading-relaxed">
                          "{payload.understanding.natural_language_interpretation}"
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Summary & Root Cause */}
                  <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                    <h4 className="font-semibold text-sm text-slate-100">Summary & Root Cause</h4>
                    <p className="text-slate-200 font-medium">{payload.summary}</p>

                    {payload.root_cause && (
                      <div className="p-3 rounded-lg bg-rose-950/30 border border-rose-900/40 text-rose-200">
                        <span className="font-bold block mb-1 text-rose-300">Root Cause Code:</span>
                        <p>{payload.root_cause}</p>
                      </div>
                    )}

                    {payload.explanation && payload.explanation.length > 0 && (
                      <div className="space-y-1.5 pt-2">
                        <span className="font-semibold text-slate-400 uppercase text-[10px] tracking-wider block">Agent Rationale Steps:</span>
                        <ul className="list-disc list-inside space-y-1 text-slate-300">
                          {payload.explanation.map((e, idx) => (
                            <li key={idx}>{e}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Tab 3: Workflow Discovery & Ops Case Management */}
              {activeTab === 'workflow_case' && (
                <div className="space-y-4 text-xs">
                  {/* Workflow Card */}
                  <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-sm text-slate-100 flex items-center gap-2">
                        <GitBranch className="w-4 h-4 text-amber-400" /> Workflow Match Engine
                      </h4>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        payload.workflow?.matched
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}>
                        MATCHED: {payload.workflow?.matched ? 'TRUE' : 'FALSE'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[10px]">Workflow ID</span>
                        <span className="font-mono font-bold text-amber-300">{payload.workflow?.workflow_id || 'None'}</span>
                      </div>
                      <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                        <span className="text-slate-400 block text-[10px]">Confidence Score</span>
                        <span className="font-bold text-slate-200">{payload.workflow?.confidence ? `${(payload.workflow.confidence * 100).toFixed(0)}%` : 'N/A'}</span>
                      </div>
                    </div>

                    {payload.workflow?.steps && payload.workflow.steps.length > 0 && (
                      <div className="space-y-1.5">
                        <span className="text-slate-400 font-semibold block text-[10px]">Workflow Steps Executed:</span>
                        <div className="space-y-1">
                          {payload.workflow.steps.map((st, i) => (
                            <div key={i} className="flex items-center justify-between bg-slate-950 p-2 rounded border border-slate-800">
                              <span className="text-slate-300">{st.name}</span>
                              <span className="text-[10px] font-mono text-emerald-400">{st.status}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Case Management Card */}
                  <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-sm text-slate-100">Operations Case Registry</h4>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        payload.case?.created
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}>
                        CASE CREATED: {payload.case?.created ? 'TRUE' : 'FALSE'}
                      </span>
                    </div>

                    {payload.case?.created && (
                      <div className="bg-purple-950/30 border border-purple-900/40 p-3 rounded-lg space-y-1">
                        <span className="text-purple-300 font-mono font-bold block text-sm">
                          Case Reference: {payload.case.case_id}
                        </span>
                        <p className="text-purple-200 text-xs">Status: {payload.case.status || 'OPEN'}</p>
                      </div>
                    )}

                    <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">Reasoning / Resolution Policy</span>
                      <p className="text-slate-300 mt-1">{payload.case?.reason || 'No case policy provided.'}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 4: Document Vault Audit */}
              {activeTab === 'document' && (
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-4 text-xs">
                  <h4 className="font-semibold text-sm text-slate-100 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-emerald-400" /> Document Audit Vault
                  </h4>

                  {!payload.document?.uploaded ? (
                    <div className="p-8 text-center text-slate-500 space-y-2">
                      <FileText className="w-8 h-8 mx-auto text-slate-600" />
                      <p>No document was uploaded in this current transaction session.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                          <span className="text-slate-400 block text-[10px]">File Name</span>
                          <span className="font-mono font-bold text-slate-200">{payload.document.file_name}</span>
                        </div>
                        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                          <span className="text-slate-400 block text-[10px]">Validation Status</span>
                          <span className={`font-bold ${payload.document.validation_status === 'SUCCESS' ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {payload.document.validation_status}
                          </span>
                        </div>
                      </div>

                      <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
                        <span className="text-slate-400 block text-[10px]">Server Storage Path</span>
                        <code className="font-mono text-[11px] text-blue-300 block break-all">
                          {payload.document.storage_path}
                        </code>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Tab 5: Raw JSON Payload Inspector */}
              {activeTab === 'json' && (
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                  <pre className="font-mono text-xs text-emerald-400 bg-slate-950 p-4 rounded-lg overflow-x-auto max-h-[500px] border border-slate-800 scrollbar-thin">
                    {JSON.stringify(lastResponseWrapper, null, 2)}
                  </pre>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
