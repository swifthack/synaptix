import React from 'react';
import { PresetScenario } from '../types';
import { HelpCircle, FileX, FileCheck, ShieldAlert, Sparkles } from 'lucide-react';

interface ScenarioPresetsBarProps {
  scenarios: PresetScenario[];
  activeScenarioId: string | null;
  onSelectScenario: (scenario: PresetScenario) => void;
  isLoading: boolean;
}

export const ScenarioPresetsBar: React.FC<ScenarioPresetsBarProps> = ({
  scenarios,
  activeScenarioId,
  onSelectScenario,
  isLoading
}) => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'rejection':
        return <HelpCircle className="w-4 h-4 text-amber-500" />;
      case 'upload_fail':
        return <FileX className="w-4 h-4 text-rose-500" />;
      case 'upload_success':
        return <FileCheck className="w-4 h-4 text-emerald-500" />;
      case 'escalation':
        return <ShieldAlert className="w-4 h-4 text-purple-500" />;
      default:
        return <Sparkles className="w-4 h-4 text-blue-500" />;
    }
  };

  return (
    <div id="scenario-presets-container" className="bg-slate-900/90 border-b border-slate-800 py-2.5 px-4">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <div className="flex items-center space-x-2 text-xs font-semibold text-slate-400 uppercase tracking-wider shrink-0">
          <Sparkles className="w-3.5 h-3.5 text-blue-400 animate-spin-slow" />
          <span>Demo Agent Scenarios:</span>
        </div>

        <div className="flex items-center space-x-2 overflow-x-auto w-full pb-1 sm:pb-0 scrollbar-none">
          {scenarios.map((sc) => {
            const isActive = activeScenarioId === sc.id;
            return (
              <button
                key={sc.id}
                id={`preset-${sc.id}`}
                disabled={isLoading}
                onClick={() => onSelectScenario(sc)}
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium border whitespace-nowrap transition-all duration-150 ${
                  isActive
                    ? 'bg-blue-600/20 border-blue-500/50 text-blue-200 ring-1 ring-blue-400/30 shadow-sm'
                    : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700/70 text-slate-300 hover:text-white'
                } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {getIcon(sc.iconType)}
                <span>{sc.title}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
