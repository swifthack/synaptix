import React, { useState } from 'react';
import { X, Settings, Server, RefreshCw, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';
import { BackendConfig } from '../types';

interface BackendConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: BackendConfig;
  onSaveConfig: (newConfig: { backendUrl?: string; useSimulation?: boolean }) => Promise<void>;
}

export const BackendConfigModal: React.FC<BackendConfigModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig
}) => {
  const [backendUrl, setBackendUrl] = useState(config.backendUrl);
  const [useSimulation, setUseSimulation] = useState(config.useSimulation);
  const [isSaving, setIsSaving] = useState(false);

  if (!isOpen) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onSaveConfig({ backendUrl, useSimulation });
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div id="backend-config-modal" className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Server className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm">Agentic AI Backend Setup</h3>
              <p className="text-[11px] text-slate-400">Local FastAPI / Server Proxy Settings</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSave} className="p-6 space-y-5 text-xs">
          {/* Mode Switcher */}
          <div className="space-y-2">
            <label className="font-semibold text-slate-300 block">Execution Backend Engine:</label>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setUseSimulation(true)}
                className={`p-3 rounded-xl border text-left flex flex-col space-y-1 transition-all ${
                  useSimulation
                    ? 'bg-amber-500/10 border-amber-500/50 text-amber-200 ring-1 ring-amber-500/30'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs">AI Studio Simulator</span>
                  {useSimulation && <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />}
                </div>
                <span className="text-[10px] text-slate-400">
                  Built-in schema simulator (Works out-of-the-box in preview)
                </span>
              </button>

              <button
                type="button"
                onClick={() => setUseSimulation(false)}
                className={`p-3 rounded-xl border text-left flex flex-col space-y-1 transition-all ${
                  !useSimulation
                    ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-200 ring-1 ring-emerald-500/30'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs">Live Local FastAPI</span>
                  {!useSimulation && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                </div>
                <span className="text-[10px] text-slate-400">
                  Connects to http://127.0.0.1:8000
                </span>
              </button>
            </div>
          </div>

          {/* URL Input */}
          <div className="space-y-2">
            <label className="font-semibold text-slate-300 block">Local Backend Base URL:</label>
            <input
              type="text"
              value={backendUrl}
              onChange={(e) => setBackendUrl(e.target.value)}
              placeholder="http://127.0.0.1:8000"
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-500 rounded-xl px-3.5 py-2.5 font-mono text-xs text-slate-100 focus:outline-none"
            />
            <p className="text-[11px] text-slate-400">
              The proxy forwards requests to <code className="text-amber-300">{backendUrl}/chat</code> and <code className="text-amber-300">{backendUrl}/upload</code>.
            </p>
          </div>

          {/* Info Box */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-slate-300 space-y-1">
            <span className="font-semibold text-slate-200 block text-[11px] flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" /> Endpoint Compatibility:
            </span>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Supports user schema parameters: <code>user_id</code>, <code>message</code>, <code>session_id</code>, and multipart document file uploads.
            </p>
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shadow-md shadow-amber-500/20"
            >
              {isSaving && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
              <span>Save & Apply Settings</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
