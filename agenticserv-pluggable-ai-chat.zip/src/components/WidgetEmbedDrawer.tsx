import React, { useState } from 'react';
import { X, Code, Copy, Check, Terminal, Layers, Cpu, Globe, Server, CheckCircle2 } from 'lucide-react';

interface WidgetEmbedDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  backendUrl: string;
}

export const WidgetEmbedDrawer: React.FC<WidgetEmbedDrawerProps> = ({
  isOpen,
  onClose,
  backendUrl
}) => {
  const [activeTab, setActiveTab] = useState<'script' | 'react' | 'backend' | 'techstack'>('script');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, section: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const scriptTagCode = `<!-- 1. Add Pluggable Agentic Chat Widget to any HTML webpage -->
<script
  src="${window.location.origin}/agentic-chat-widget.js"
  data-user-id="ext_abc_user"
  data-session-id="demo1"
  data-api-endpoint="${backendUrl}"
  data-theme="dark"
  async>
</script>`;

  const reactComponentCode = `// 2. Import into React / Next.js app
import { AgenticChatWidget } from '@agenticserv/react-widget';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <YourAppContent />

      <AgenticChatWidget
        userId="ext_abc_user"
        sessionId="demo1"
        apiEndpoint="${backendUrl}"
        theme="dark"
        position="bottom-right"
        onAgentResponse={(payload) => {
          console.log('Agentic execution trace:', payload);
        }}
      />
    </div>
  );
}`;

  const backendFastApiCode = `# 3. FastAPI Agentic AI Backend (main.py)
from fastapi import FastAPI, UploadFile, File, Form
from pydantic import BaseModel
import uvicorn

app = FastAPI(title="Agentic AI Customer Servicing Backend")

class ChatRequest(BaseModel):
    user_id: str
    message: str
    session_id: str

@app.post("/chat")
async def handle_chat(req: ChatRequest):
    # Execute Agentic Multi-Agent Pipeline (Identity -> Context -> Workflow -> Resolution)
    return {
        "user": {
            "user_id": req.user_id,
            "display_name": "ABC Ltd Client User",
            "user_type": "external",
            "role": "client_user",
            "customer_id": "CUST_ABC"
        },
        "response": {
            "request_id": "3a5a9380-71c2-469d-9b6f-0acb759596ab",
            "resolution_status": "RESOLVED",
            "summary": "Transaction TXN-ABC-9001 rejected due to DOCUMENT_MISMATCH.",
            "agent_execution": [
                {"agent": "Identity Agent", "status": "COMPLETED", "detail": "Resolved identity."},
                {"agent": "Customer Context Agent", "status": "COMPLETED", "detail": "Loaded entitled context."},
                {"agent": "Resolution Agent", "status": "RESOLVED", "detail": "Analyzed rejection reason."}
            ],
            "ui_hints": {
                "show_summary_card": True,
                "show_recommended_actions": True,
                "primary_action": "Upload corrected document"
            }
        }
    }

@app.post("/upload")
async def handle_upload(
    user_id: str = Form(...),
    session_id: str = Form(...),
    file: UploadFile = File(...)
):
    # Stored and validated by Document Agent
    return {
        "user": {"user_id": user_id, "customer_id": "CUST_ABC"},
        "response": {
            "understanding": {"intent": "DOCUMENT_UPLOAD_VALIDATION"},
            "resolution_status": "DOCUMENT_VALIDATION_FAILED",
            "document": {
                "uploaded": True,
                "file_name": file.filename,
                "validation_status": "FAILED"
            }
        }
    }

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)`;

  return (
    <div id="embed-sdk-modal" className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-slate-100">Pluggable Agentic Chat SDK</h3>
              <p className="text-xs text-slate-400">Codebase & Architecture Integration Guide</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="bg-slate-950/60 px-6 py-2 border-b border-slate-800 flex items-center space-x-2">
          <button
            onClick={() => setActiveTab('script')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'script' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            HTML Script Tag
          </button>
          <button
            onClick={() => setActiveTab('react')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'react' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            React Component
          </button>
          <button
            onClick={() => setActiveTab('backend')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'backend' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            FastAPI Backend Specs
          </button>
          <button
            onClick={() => setActiveTab('techstack')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'techstack' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Recommended Tech Stack
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
          {activeTab === 'script' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-slate-300">
                  Embed this single line script in any legacy or static website (HTML, WordPress, Django, PHP) to initialize the floating Agentic Chat Widget.
                </p>
                <button
                  onClick={() => handleCopy(scriptTagCode, 'script')}
                  className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs"
                >
                  {copiedSection === 'script' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSection === 'script' ? 'Copied' : 'Copy HTML Snippet'}</span>
                </button>
              </div>
              <pre className="font-mono text-xs text-blue-300 bg-slate-950 p-4 rounded-xl border border-slate-800 overflow-x-auto">
                {scriptTagCode}
              </pre>
            </div>
          )}

          {activeTab === 'react' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-slate-300">
                  Plug directly into modern React / Next.js frontend applications with full TypeScript prop typing and event callback listeners.
                </p>
                <button
                  onClick={() => handleCopy(reactComponentCode, 'react')}
                  className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs"
                >
                  {copiedSection === 'react' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSection === 'react' ? 'Copied' : 'Copy React Snippet'}</span>
                </button>
              </div>
              <pre className="font-mono text-xs text-emerald-300 bg-slate-950 p-4 rounded-xl border border-slate-800 overflow-x-auto">
                {reactComponentCode}
              </pre>
            </div>
          )}

          {activeTab === 'backend' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-slate-300">
                  Target FastAPI backend code implementation supporting POST <code>/chat</code> and POST <code>/upload</code> endpoints:
                </p>
                <button
                  onClick={() => handleCopy(backendFastApiCode, 'backend')}
                  className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs"
                >
                  {copiedSection === 'backend' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSection === 'backend' ? 'Copied' : 'Copy Python Code'}</span>
                </button>
              </div>
              <pre className="font-mono text-xs text-purple-300 bg-slate-950 p-4 rounded-xl border border-slate-800 overflow-x-auto">
                {backendFastApiCode}
              </pre>
            </div>
          )}

          {activeTab === 'techstack' && (
            <div className="space-y-4">
              <h4 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-400" /> Recommended Architecture & Tech Stack for Business Demo
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <span className="font-bold text-blue-400 block flex items-center gap-1.5">
                    <Globe className="w-4 h-4" /> Frontend & Widget Library
                  </span>
                  <ul className="space-y-1.5 text-slate-300">
                    <li className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>React 19 + TypeScript:</strong> Modular pluggable widget architecture.</span>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>Tailwind CSS v4 + Motion:</strong> Fluid animations and dual-view styling.</span>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>Shadow DOM Isolation:</strong> Ensures zero CSS style leaks when embedded on client sites.</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <span className="font-bold text-purple-400 block flex items-center gap-1.5">
                    <Server className="w-4 h-4" /> Agentic AI Orchestration Backend
                  </span>
                  <ul className="space-y-1.5 text-slate-300">
                    <li className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>Python 3.11 + FastAPI + Uvicorn:</strong> High speed API server on port 8000.</span>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>LangGraph / CrewAI / AutoGen:</strong> Sub-agent execution pipeline (Identity, Context, Workflow, Resolution, Document).</span>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>Gemini 2.5 Flash API:</strong> Fast intent classification & natural language explanation generation.</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
