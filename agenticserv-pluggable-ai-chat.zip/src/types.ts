export type UserType = 'external' | 'internal';
export type UserRole = 'client_user' | 'ops_agent' | 'admin';

export interface AgenticUser {
  user_id: string;
  display_name: string;
  user_type: UserType;
  role: UserRole;
  customer_id: string;
}

export interface UserContext {
  user_id: string;
  display_name: string;
  user_type: UserType;
  role: UserRole;
  customer_id: string;
  market: string;
}

export interface ResolvedEntity {
  type: string;
  transaction_id?: string;
  file_name?: string;
  [key: string]: any;
}

export interface Understanding {
  intent: string;
  domain: string;
  resolved_entity: ResolvedEntity;
  natural_language_interpretation?: string;
}

export interface WorkflowStep {
  step_id?: string;
  name?: string;
  status?: string;
}

export interface WorkflowInfo {
  matched?: boolean;
  workflow_id?: string | null;
  workflow_name?: string | null;
  confidence?: number | null;
  steps?: WorkflowStep[];
}

export interface CaseInfo {
  created: boolean;
  case_id?: string;
  reason?: string;
  status?: string;
}

export interface DocumentInfo {
  uploaded?: boolean;
  file_name?: string;
  storage_path?: string;
  validation_status?: 'SUCCESS' | 'FAILED' | 'PENDING' | string;
}

export interface AgentExecutionStep {
  agent: string;
  status: 'COMPLETED' | 'NO_MATCH' | 'FAILED' | 'IN_PROGRESS' | string;
  detail: string;
  metadata: Record<string, any>;
}

export interface UIHints {
  show_summary_card?: boolean;
  show_agent_timeline?: boolean;
  show_recommended_actions?: boolean;
  show_case_panel?: boolean;
  show_workflow_panel?: boolean;
  show_document_panel?: boolean;
  primary_action?: string;
}

export interface AgenticResponsePayload {
  request_id: string;
  timestamp: string;
  user_context: UserContext;
  understanding: Understanding;
  resolution_status: string;
  summary: string;
  root_cause: string;
  explanation: string[];
  recommended_actions: string[];
  workflow: WorkflowInfo;
  case: CaseInfo;
  document: DocumentInfo;
  agent_execution: AgentExecutionStep[];
  trace_available?: boolean;
  ui_hints: UIHints;
}

export interface ChatResponseWrapper {
  user: AgenticUser;
  response: AgenticResponsePayload;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'agent';
  user_id: string;
  display_name: string;
  text: string;
  timestamp: string;
  payload?: ChatResponseWrapper;
  attachment?: {
    name: string;
    size: number;
    status: 'uploading' | 'uploaded' | 'failed';
  };
}

export interface PresetScenario {
  id: string;
  title: string;
  subtitle: string;
  message: string;
  session_id: string;
  user_id: string;
  iconType: 'rejection' | 'upload_fail' | 'upload_success' | 'escalation';
}

export interface BackendConfig {
  backendUrl: string; // default http://127.0.0.1:8000
  useSimulation: boolean;
  isBackendConnected: boolean;
}
