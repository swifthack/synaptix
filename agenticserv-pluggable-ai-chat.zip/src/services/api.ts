import { ChatResponseWrapper, PresetScenario, BackendConfig } from '../types';

export async function sendChatMessage(
  message: string,
  userId: string = "ext_abc_user",
  sessionId: string = "demo1"
): Promise<ChatResponseWrapper> {
  const response = await fetch("/api/chat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json"
    },
    body: JSON.stringify({
      user_id: userId,
      message: message,
      session_id: sessionId
    })
  });

  if (!response.ok) {
    throw new Error(`API error (${response.status}): ${await response.text()}`);
  }

  return response.json();
}

export async function uploadDocumentFile(
  file: File,
  userId: string = "ext_abc_user",
  sessionId: string = "demo2"
): Promise<ChatResponseWrapper> {
  const formData = new FormData();
  formData.append("user_id", userId);
  formData.append("session_id", sessionId);
  formData.append("file", file);

  const response = await fetch("/api/upload", {
    method: "POST",
    headers: {
      "Accept": "application/json"
    },
    body: formData
  });

  if (!response.ok) {
    throw new Error(`Upload error (${response.status}): ${await response.text()}`);
  }

  return response.json();
}

export async function getPresetScenarios(): Promise<PresetScenario[]> {
  const response = await fetch("/api/scenarios");
  if (!response.ok) {
    return [];
  }
  return response.json();
}

export async function getBackendConfig(): Promise<BackendConfig> {
  const response = await fetch("/api/config");
  if (!response.ok) {
    return {
      backendUrl: "http://127.0.0.1:8000",
      useSimulation: true,
      isBackendConnected: false
    };
  }
  const data = await response.json();

  // Test live backend health
  let isBackendConnected = false;
  try {
    const healthResp = await fetch("/api/health");
    if (healthResp.ok) {
      isBackendConnected = true;
    }
  } catch (e) {
    isBackendConnected = false;
  }

  return {
    ...data,
    isBackendConnected
  };
}

export async function updateBackendConfig(config: { backendUrl?: string; useSimulation?: boolean }): Promise<BackendConfig> {
  const response = await fetch("/api/config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(config)
  });
  if (!response.ok) {
    throw new Error("Failed to update config");
  }
  const result = await response.json();
  return result.backendConfig;
}
