import { InternalEntity, GraphNode, GraphEdge, CommunitySummary, ChangeEventItem, EvidenceItem } from '../types/entityiq';

export const INITIAL_INTERNAL_ENTITIES: InternalEntity[] = [
  {
    id: 'ENT-SG-1001',
    customerIds: ['CUST-88201', 'CUST-88201-OLD'],
    canonicalName: 'ABC Construction Pte. Ltd.',
    normalizedName: 'abc construction',
    aliases: ['ABC Construction', 'ABC Building Contractors'],
    historicalNames: ['ABC Builders Pte Ltd (renamed 2021)'],
    registrationNumber: '201812345E',
    normalizedRegistrationNumber: '201812345E',
    lei: '5493001KJ95729X4301',
    taxId: 'T18LL1234A',
    jurisdiction: 'Singapore',
    normalizedAddress: '10 marina boulevard 18-01 marina bay financial centre singapore 018983',
    directors: ['Tan Ah Kow', 'John Richard Smith'],
    entityType: 'ORGANIZATION',
    status: 'ACTIVE',
    incorporationDate: '2018-05-14',
    industryCode: '41001 - General Contractors',
    relationshipKeys: ['GRP-BUILD-01'],
    sanctionHit: false,
    pepHit: false,
    adverseMediaHit: false,
  },
  {
    id: 'ENT-SG-1002',
    customerIds: ['CUST-99304'],
    canonicalName: 'Vertex Global Holdings Pte. Ltd.',
    normalizedName: 'vertex global holdings',
    aliases: ['Vertex Global Group', 'VGH Asia'],
    historicalNames: [],
    registrationNumber: '201598765K',
    normalizedRegistrationNumber: '201598765K',
    lei: '9845009876543210123',
    taxId: 'T15LL9876B',
    jurisdiction: 'Singapore',
    normalizedAddress: '1 raffles place 25-01 one raffles place singapore 048616',
    directors: ['Chen Wei', 'Elena Rostova', 'Tan Ah Kow'],
    entityType: 'ORGANIZATION',
    status: 'ACTIVE',
    incorporationDate: '2015-11-20',
    industryCode: '64202 - Financial Holding Companies',
    relationshipKeys: ['GRP-VERTEX-GLOBAL'],
    sanctionHit: false,
    pepHit: true, // Elena Rostova PEP link
    adverseMediaHit: false,
  },
  {
    id: 'ENT-HK-2005',
    customerIds: ['CUST-77412'],
    canonicalName: 'Acme Asia Logistics Limited',
    normalizedName: 'acme asia logistics',
    aliases: ['Acme Express HK', 'Acme Freight'],
    historicalNames: ['Acme Shipping HK Ltd'],
    registrationNumber: 'HK-6739210',
    normalizedRegistrationNumber: '6739210',
    lei: '8943004829104820194',
    taxId: 'HK-982183',
    jurisdiction: 'Hong Kong',
    normalizedAddress: 'suite 1204 12f two international finance centre central hong kong',
    directors: ['David Zhang', 'Michael Chang'],
    entityType: 'ORGANIZATION',
    status: 'ACTIVE',
    incorporationDate: '2016-03-10',
    industryCode: '52291 - Freight Forwarding',
    relationshipKeys: ['GRP-ACME-LOG'],
    sanctionHit: false,
    pepHit: false,
    adverseMediaHit: true,
  },
  {
    id: 'ENT-BVI-3009',
    customerIds: ['CUST-10492'],
    canonicalName: 'CyberDynamics Offshore Corp.',
    normalizedName: 'cyberdynamics offshore',
    aliases: ['CyberDynamics BVI'],
    historicalNames: [],
    registrationNumber: 'BVI-1982734',
    normalizedRegistrationNumber: '1982734',
    jurisdiction: 'British Virgin Islands',
    normalizedAddress: 'trident chambers po box 146 road town tortola bvi',
    directors: ['Elena Rostova', 'Viktor Ivanov'],
    entityType: 'ORGANIZATION',
    status: 'ACTIVE',
    incorporationDate: '2019-08-01',
    industryCode: '64300 - Offshore Special Purpose Vehicles',
    relationshipKeys: ['GRP-CYBER-OFFSHORE'],
    sanctionHit: true, // Viktor Ivanov Sanction match
    pepHit: true,
    adverseMediaHit: true,
  },
  {
    id: 'ENT-UK-4012',
    customerIds: ['CUST-66291'],
    canonicalName: 'Apex Trade Capital UK Ltd',
    normalizedName: 'apex trade capital uk',
    aliases: ['Apex Capital UK'],
    historicalNames: [],
    registrationNumber: 'UK-09871234',
    normalizedRegistrationNumber: '09871234',
    jurisdiction: 'United Kingdom',
    normalizedAddress: '30 st mary axe london ec3a 8ep united kingdom',
    directors: ['John Richard Smith', 'Claire Bennett'],
    entityType: 'ORGANIZATION',
    status: 'ACTIVE',
    incorporationDate: '2017-02-18',
    industryCode: '64990 - Financial Intermediation',
    relationshipKeys: ['GRP-APEX-UK'],
    sanctionHit: false,
    pepHit: false,
    adverseMediaHit: false,
  }
];

export const INITIAL_GRAPH_NODES: GraphNode[] = [
  { id: 'ENT-SG-1001', label: 'ABC Construction Pte. Ltd.', type: 'ORGANIZATION', jurisdiction: 'Singapore', status: 'ACTIVE', sanctionHit: false, pepHit: false, communityId: 'COMM-BUILDERS', properties: { regNo: '201812345E', revenueUsd: 18500000 } },
  { id: 'ENT-SG-1002', label: 'Vertex Global Holdings Pte. Ltd.', type: 'ORGANIZATION', jurisdiction: 'Singapore', status: 'ACTIVE', sanctionHit: false, pepHit: true, communityId: 'COMM-VERTEX-GRP', properties: { regNo: '201598765K', totalExposureUsd: 45000000 } },
  { id: 'ENT-HK-2005', label: 'Acme Asia Logistics Limited', type: 'ORGANIZATION', jurisdiction: 'Hong Kong', status: 'ACTIVE', sanctionHit: false, pepHit: false, communityId: 'COMM-LOGISTICS', properties: { regNo: 'HK-6739210' } },
  { id: 'ENT-BVI-3009', label: 'CyberDynamics Offshore Corp.', type: 'ORGANIZATION', jurisdiction: 'BVI', status: 'ACTIVE', sanctionHit: true, pepHit: true, communityId: 'COMM-VERTEX-GRP', properties: { regNo: 'BVI-1982734' } },
  { id: 'ENT-UK-4012', label: 'Apex Trade Capital UK Ltd', type: 'ORGANIZATION', jurisdiction: 'United Kingdom', status: 'ACTIVE', sanctionHit: false, pepHit: false, communityId: 'COMM-BUILDERS', properties: { regNo: 'UK-09871234' } },
  
  // Person Nodes
  { id: 'PER-TAN-01', label: 'Tan Ah Kow', type: 'PERSON', jurisdiction: 'Singapore', sanctionHit: false, pepHit: false, communityId: 'COMM-BUILDERS', properties: { nationality: 'Singaporean', idNumber: 'S****123A' } },
  { id: 'PER-SMITH-02', label: 'John Richard Smith', type: 'PERSON', jurisdiction: 'United Kingdom', sanctionHit: false, pepHit: false, communityId: 'COMM-BUILDERS', properties: { nationality: 'British', passportNo: 'GB982183' } },
  { id: 'PER-ELENA-03', label: 'Elena Rostova', type: 'PERSON', jurisdiction: 'Cyprus', sanctionHit: false, pepHit: true, communityId: 'COMM-VERTEX-GRP', properties: { nationality: 'Cypriot', role: 'Prominent Political Figure Family' } },
  { id: 'PER-VIKTOR-04', label: 'Viktor Ivanov', type: 'PERSON', jurisdiction: 'Offshore', sanctionHit: true, pepHit: true, communityId: 'COMM-VERTEX-GRP', properties: { sanctionList: 'OFAC SDN List', designation: 'Designated Asset Freeze' } },
  { id: 'PER-CHEN-05', label: 'Chen Wei', type: 'PERSON', jurisdiction: 'Singapore', sanctionHit: false, pepHit: false, communityId: 'COMM-VERTEX-GRP', properties: { nationality: 'Singaporean' } },

  // Document Nodes
  { id: 'DOC-SG-REG-1001', label: 'ACRA Business Profile 2026', type: 'DOCUMENT', properties: { docType: 'ACRA Registry Search', hash: 'sha256_e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' } },
  { id: 'DOC-UBO-DECL-1002', label: 'UBO Declaration Certificate', type: 'DOCUMENT', properties: { docType: 'UBO Certificate', hash: 'sha256_8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92' } }
];

export const INITIAL_GRAPH_EDGES: GraphEdge[] = [
  { id: 'EDGE-1', source: 'PER-TAN-01', target: 'ENT-SG-1001', type: 'OWNS', ownershipPercentage: 65, startDate: '2018-05-14', sourceRef: 'ACRA Registry SG', confidence: 0.99 },
  { id: 'EDGE-2', source: 'PER-TAN-01', target: 'ENT-SG-1001', type: 'DIRECTS', startDate: '2018-05-14', sourceRef: 'ACRA Registry SG', confidence: 1.0 },
  { id: 'EDGE-3', source: 'PER-SMITH-02', target: 'ENT-SG-1001', type: 'DIRECTS', startDate: '2020-01-10', sourceRef: 'ACRA Registry SG', confidence: 0.98 },
  { id: 'EDGE-4', source: 'ENT-SG-1001', target: 'ENT-UK-4012', type: 'OWNS', ownershipPercentage: 100, startDate: '2021-03-01', sourceRef: 'UK Companies House', confidence: 0.96 },
  { id: 'EDGE-5', source: 'ENT-SG-1001', target: 'ENT-UK-4012', type: 'SUBSIDIARY_OF', sourceRef: 'Corporate Filing', confidence: 0.98 },
  
  // Vertex Group
  { id: 'EDGE-6', source: 'ENT-SG-1002', target: 'ENT-BVI-3009', type: 'OWNS', ownershipPercentage: 80, startDate: '2019-08-05', sourceRef: 'BVI Registry & Financial Statement', confidence: 0.94 },
  { id: 'EDGE-7', source: 'PER-ELENA-03', target: 'ENT-SG-1002', type: 'DIRECTS', startDate: '2017-06-15', sourceRef: 'ACRA Registry SG', confidence: 0.99 },
  { id: 'EDGE-8', source: 'PER-CHEN-05', target: 'ENT-SG-1002', type: 'OWNS', ownershipPercentage: 55, startDate: '2015-11-20', sourceRef: 'ACRA Registry SG', confidence: 0.99 },
  { id: 'EDGE-9', source: 'PER-ELENA-03', target: 'ENT-SG-1002', type: 'OWNS', ownershipPercentage: 45, startDate: '2016-02-01', sourceRef: 'UBO Declaration', confidence: 0.95 },
  { id: 'EDGE-10', source: 'PER-VIKTOR-04', target: 'ENT-BVI-3009', type: 'DIRECTS', startDate: '2019-08-01', sourceRef: 'BVI Registry', confidence: 0.91 },
  { id: 'EDGE-11', source: 'PER-VIKTOR-04', target: 'ENT-BVI-3009', type: 'OWNS', ownershipPercentage: 100, startDate: '2019-08-01', sourceRef: 'Leaked Offshore Data', confidence: 0.88 },

  // Mentions / Documents
  { id: 'EDGE-12', source: 'DOC-SG-REG-1001', target: 'ENT-SG-1001', type: 'MENTIONS', sourceRef: 'ACRA PDF Extract', confidence: 1.0 },
  { id: 'EDGE-13', source: 'DOC-UBO-DECL-1002', target: 'ENT-SG-1002', type: 'MENTIONS', sourceRef: 'Compliance Upload', confidence: 1.0 }
];

export const INITIAL_COMMUNITY_SUMMARIES: CommunitySummary[] = [
  {
    communityId: 'COMM-BUILDERS',
    name: 'ABC Construction & Allied Holdings Group',
    memberCount: 4,
    ultimateParent: 'Tan Ah Kow (65% UBO)',
    totalGroupExposureUsd: 28500000,
    riskLevel: 'LOW',
    summary: 'Established South East Asia construction and infrastructure engineering corporate cluster. Primary operational anchor is ABC Construction Pte. Ltd. (SG), with wholly owned UK trade subsidy. Clean sanctions and PEP status.'
  },
  {
    communityId: 'COMM-VERTEX-GRP',
    name: 'Vertex Global Offshore & Investments Syndicate',
    memberCount: 5,
    ultimateParent: 'Chen Wei (55%) & Elena Rostova (45%)',
    totalGroupExposureUsd: 72000000,
    riskLevel: 'HIGH',
    summary: 'High-risk multi-jurisdictional holding group spanning Singapore financial holdings and British Virgin Islands offshore SPV (CyberDynamics Offshore Corp). Contains active OFAC Sanction hit on Director/UBO Viktor Ivanov and PEP relationship via Elena Rostova.'
  },
  {
    communityId: 'COMM-LOGISTICS',
    name: 'Acme Logistics HK Network',
    memberCount: 2,
    ultimateParent: 'Acme Global Logistics Pte Ltd',
    totalGroupExposureUsd: 14000000,
    riskLevel: 'MEDIUM',
    summary: 'Regional freight forwarding network operating in Hong Kong and Southern China. Contains adverse media hit regarding customs investigation in 2024.'
  }
];

export const INITIAL_CHANGE_EVENTS: ChangeEventItem[] = [
  {
    id: 'EVT-2026-001',
    entityId: 'ENT-BVI-3009',
    entityName: 'CyberDynamics Offshore Corp.',
    eventType: 'SANCTION_UPDATE',
    oldValue: 'Sanctions: Clear',
    newValue: 'OFAC SDN List Addition: Director Viktor Ivanov Designated',
    timestamp: '2026-08-07T14:22:00Z',
    suggestedAction: 'Immediate Account Freeze & Escalation to Financial Crime Unit',
    targetRole: 'COMPLIANCE_INVESTIGATOR',
    status: 'PENDING'
  },
  {
    id: 'EVT-2026-002',
    entityId: 'ENT-SG-1002',
    entityName: 'Vertex Global Holdings Pte. Ltd.',
    eventType: 'UBO_CHANGE',
    oldValue: 'Chen Wei (100% UBO)',
    newValue: 'Chen Wei (55%), Elena Rostova (45% UBO - PEP)',
    timestamp: '2026-08-06T09:15:00Z',
    suggestedAction: 'Trigger Enhanced Due Diligence (EDD) & Group Limit Re-assessment',
    targetRole: 'KYC_ANALYST',
    status: 'PENDING'
  },
  {
    id: 'EVT-2026-003',
    entityId: 'ENT-SG-1001',
    entityName: 'ABC Construction Pte. Ltd.',
    eventType: 'DIRECTOR_CHANGE',
    oldValue: 'Directors: Tan Ah Kow',
    newValue: 'Directors Added: John Richard Smith (UK National)',
    timestamp: '2026-08-05T11:40:00Z',
    suggestedAction: 'Update KYB Profile & Perform Automated PEP/Sanctions Check on new director',
    targetRole: 'KYC_ANALYST',
    status: 'REVIEWED'
  },
  {
    id: 'EVT-2026-004',
    entityId: 'ENT-HK-2005',
    entityName: 'Acme Asia Logistics Limited',
    eventType: 'REGISTRY_STATUS_CHANGE',
    oldValue: 'Registry Status: Pending Filings',
    newValue: 'Registry Status: Fully Compliant Active Status',
    timestamp: '2026-08-04T16:05:00Z',
    suggestedAction: 'Clear Temporary Compliance Hold on Credit Line Drawdown',
    targetRole: 'CREDIT_OFFICER',
    status: 'PENDING'
  }
];

export const INITIAL_EVIDENCE_ITEMS: EvidenceItem[] = [
  {
    id: 'EVID-SG-ACRA-8812',
    sourceSystem: 'Singapore ACRA Corporate Registry',
    documentRef: 'DOC-SG-REG-1001',
    timestamp: '2026-08-01T08:00:00Z',
    confidenceScore: 0.99,
    attribution: 'Government API Integration',
    hash: 'sha256_e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
  },
  {
    id: 'EVID-UK-CH-9941',
    sourceSystem: 'UK Companies House Registry',
    documentRef: 'DOC-UK-CH-0987',
    timestamp: '2026-08-02T10:12:00Z',
    confidenceScore: 0.97,
    attribution: 'UK Registry Direct Feed',
    hash: 'sha256_7c3a9f012b4e88910192bc9e29a39f109283c01928340192834a910293848192'
  },
  {
    id: 'EVID-BVI-REG-3310',
    sourceSystem: 'Virgin Islands Financial Services Commission',
    documentRef: 'DOC-BVI-1982734',
    timestamp: '2026-08-03T15:45:00Z',
    confidenceScore: 0.92,
    attribution: 'Offshore Registry Partner Provider',
    hash: 'sha256_1029384756102938475610293847561029384756102938475610293847561029'
  }
];
