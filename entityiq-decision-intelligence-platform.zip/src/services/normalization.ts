import { NormalizedEntityInput, NormalizedEntity, BlockingKey } from '../types/entityiq';

const CORP_SUFFIXES = [
  'pte ltd', 'pte. ltd.', 'private limited', 'ltd', 'ltd.', 'limited',
  'inc', 'inc.', 'incorporated', 'corp', 'corp.', 'corporation',
  'llc', 'plc', 'gmbh', 'co.', 'co', 'company'
];

export function normalizeName(rawName: string): string {
  if (!rawName) return '';
  let name = rawName.toLowerCase().trim();
  
  // Remove punctuation except spaces
  name = name.replace(/[^\w\s]/gi, '');

  // Strip common corporate suffixes
  for (const suffix of CORP_SUFFIXES) {
    const cleanSuffix = suffix.replace(/[^\w\s]/gi, '');
    const regex = new RegExp(`\\b${cleanSuffix}\\b$`, 'gi');
    name = name.replace(regex, '').trim();
  }

  // Remove multiple spaces
  name = name.replace(/\s+/g, ' ');

  return name;
}

export function normalizeRegNumber(rawReg?: string): string {
  if (!rawReg) return '';
  return rawReg.toUpperCase().replace(/[^A-Z0-9]/g, '');
}

export function normalizeAddress(rawAddress?: string): string {
  if (!rawAddress) return '';
  let addr = rawAddress.toLowerCase().trim();
  addr = addr.replace(/[^\w\s]/gi, ' ');
  addr = addr.replace(/\s+/g, ' ');
  return addr;
}

export function generateBlockingKeys(normalized: NormalizedEntity): BlockingKey[] {
  const keys: BlockingKey[] = [];

  if (normalized.normalizedRegistrationNumber) {
    keys.push({
      type: 'REGISTRATION_NUMBER',
      key: `reg_${normalized.jurisdiction || 'GEN'}_${normalized.normalizedRegistrationNumber}`,
    });
  }

  if (normalized.lei) {
    keys.push({
      type: 'LEI',
      key: `lei_${normalized.lei.toUpperCase()}`,
    });
  }

  if (normalized.normalizedName) {
    const tokens = normalized.normalizedName.split(' ').filter(Boolean);
    if (tokens.length >= 1) {
      keys.push({
        type: 'NAME_FIRST_TOKEN',
        key: `name_t1_${tokens[0]}`,
      });
    }
    if (tokens.length >= 2) {
      keys.push({
        type: 'NAME_TWO_TOKENS',
        key: `name_t2_${tokens[0]}_${tokens[1]}`,
      });
    }
  }

  if (normalized.normalizedAddress) {
    const addrTokens = normalized.normalizedAddress.split(' ');
    if (addrTokens.length >= 3) {
      keys.push({
        type: 'ADDRESS_SUBSTR',
        key: `addr_${addrTokens[0]}_${addrTokens[1]}`,
      });
    }
  }

  return keys;
}

export function processNormalization(input: NormalizedEntityInput): NormalizedEntity {
  const normalizedName = normalizeName(input.name);
  const normalizedRegistrationNumber = normalizeRegNumber(input.registrationNumber);
  const normalizedAddress = normalizeAddress(input.address);
  const directorsNormalized = (input.directors || []).map(d => normalizeName(d));

  const result: NormalizedEntity = {
    originalName: input.name,
    normalizedName,
    originalRegistrationNumber: input.registrationNumber,
    normalizedRegistrationNumber,
    originalAddress: input.address,
    normalizedAddress,
    lei: input.lei?.toUpperCase().trim(),
    taxId: input.taxId?.trim(),
    jurisdiction: input.jurisdiction || 'Singapore',
    directorsNormalized,
    blockingKeys: [],
  };

  result.blockingKeys = generateBlockingKeys(result);
  return result;
}
