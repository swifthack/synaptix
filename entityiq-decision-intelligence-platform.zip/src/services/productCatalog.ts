import {
  KYBPack,
  ScreeningBundle,
  UBOGraphProduct,
  EvidenceBundleProduct,
  ChangeEventItem,
} from '../types/entityiq';
import { INITIAL_INTERNAL_ENTITIES, INITIAL_EVIDENCE_ITEMS, INITIAL_CHANGE_EVENTS } from '../data/mockDatabase';
import { calculateUBOGraph } from './knowledgeGraph';

export function getKYBPackProduct(entityId: string): KYBPack {
  const entity = INITIAL_INTERNAL_ENTITIES.find(e => e.id === entityId) || INITIAL_INTERNAL_ENTITIES[0];

  return {
    entityId: entity.id,
    legalIdentity: {
      canonicalName: entity.canonicalName,
      registrationNumber: entity.registrationNumber,
      lei: entity.lei,
      jurisdiction: entity.jurisdiction,
      status: entity.status,
      incorporationDate: entity.incorporationDate,
    },
    aliases: entity.aliases,
    registeredAddress: entity.normalizedAddress,
    directors: entity.directors.map(d => ({
      name: d,
      appointmentDate: '2020-01-15',
      nationality: d.includes('Smith') ? 'British' : d.includes('Rostova') ? 'Cypriot' : 'Singaporean',
    })),
    evidencePointers: [`EVID-ACRA-${entity.registrationNumber}`, 'EVID-UBO-DECL-2026'],
    lastUpdated: new Date().toISOString(),
  };
}

export function getScreeningBundleProduct(entityId: string): ScreeningBundle {
  const entity = INITIAL_INTERNAL_ENTITIES.find(e => e.id === entityId) || INITIAL_INTERNAL_ENTITIES[0];

  const sanctions = [
    {
      hit: entity.sanctionHit || false,
      matchedName: entity.sanctionHit ? 'Viktor Ivanov (Director / UBO of Related SPV)' : undefined,
      listName: entity.sanctionHit ? 'OFAC SDN List / UK Sanctions List' : undefined,
      score: entity.sanctionHit ? 0.99 : 0.05,
    },
  ];

  const pepStatus = [
    {
      hit: entity.pepHit || false,
      personName: entity.pepHit ? 'Elena Rostova (Director)' : undefined,
      role: entity.pepHit ? 'Prominent Foreign Political Figure Family Member' : undefined,
    },
  ];

  const adverseMedia = [
    {
      hit: entity.adverseMediaHit || false,
      headline: entity.adverseMediaHit ? 'Regulatory Inquiry into Customs Clearance Discrepancies' : undefined,
      date: entity.adverseMediaHit ? '2024-10-12' : undefined,
      sentiment: entity.adverseMediaHit ? 'NEGATIVE' : 'NEUTRAL',
    },
  ];

  let riskScore = 15;
  if (entity.sanctionHit) riskScore += 70;
  if (entity.pepHit) riskScore += 15;
  if (entity.adverseMediaHit) riskScore += 10;

  return {
    entityId: entity.id,
    sanctions,
    pepStatus,
    adverseMedia,
    overallRiskScore: Math.min(100, riskScore),
    evidenceId: `EVID-SCREEN-${entity.id}-${Date.now().toString(36).toUpperCase()}`,
  };
}

export function getUBOGraphProduct(entityId: string): UBOGraphProduct {
  return calculateUBOGraph(entityId);
}

export function getEvidenceBundleProduct(entityId: string): EvidenceBundleProduct {
  const items = INITIAL_EVIDENCE_ITEMS;

  return {
    entityId,
    evidenceRegistry: items,
    lineageChain: [
      'Vendor External Registry Feed (ACRA / Companies House)',
      'EntityIQ Normalization Engine v2.1',
      'Pluggable Entity Resolution Core',
      'Evidence Registry Lineage Store',
    ],
    auditabilityStatus: 'FULLY_VERIFIED',
  };
}

export function getChangeEventsForRole(role?: string): ChangeEventItem[] {
  if (!role) return INITIAL_CHANGE_EVENTS;
  return INITIAL_CHANGE_EVENTS.filter(e => e.targetRole === role || role === 'ALL');
}
