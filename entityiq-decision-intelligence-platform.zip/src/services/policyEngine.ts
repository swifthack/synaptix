import { UserRole } from '../types/entityiq';

export interface PolicyCheckRequest {
  userRole: UserRole;
  purpose: 'ONBOARDING' | 'CREDIT_UNDERWRITING' | 'MARKETING' | 'INVESTIGATION' | 'REGULATORY_REPORTING';
  targetJurisdiction: string;
  fieldRequested: string;
}

export interface PolicyCheckResult {
  allowed: boolean;
  reason: string;
  redactedValue?: string;
  appliedControls: string[];
}

export function checkPolicyAccess(req: PolicyCheckRequest): PolicyCheckResult {
  const appliedControls: string[] = [];

  // 1. Purpose Binding Control
  if (req.purpose === 'MARKETING') {
    appliedControls.push('PURPOSE_BINDING_RESTRICTION');
    return {
      allowed: false,
      reason: 'POLICY VIOLATION: Customer KYB and Beneficial Ownership data collected under Regulatory Onboarding cannot be reused for Marketing purposes.',
      appliedControls,
    };
  }

  // 2. Field-Level Role Access Control
  if (req.userRole === 'RM') {
    if (req.fieldRequested === 'sourceDocumentRawPayload' || req.fieldRequested === 'sanctionsInvestigativeNotes') {
      appliedControls.push('FIELD_LEVEL_ROLE_REDACTION');
      return {
        allowed: true,
        reason: 'RESTRICTED ACCESS: RM role can view high-level UBO summary and KYB status, but raw source payloads and investigative case notes are redacted.',
        redactedValue: '[REDACTED - COMPLIANCE RESTRICTED FIELD]',
        appliedControls,
      };
    }
  }

  // 3. Jurisdiction Control
  if (req.targetJurisdiction === 'BVI' && req.userRole === 'RM') {
    appliedControls.push('OFFSHORE_JURISDICTION_GOVERNANCE');
    return {
      allowed: true,
      reason: 'JURISDICTION CONTROL: Viewing BVI Offshore entity requires Senior Compliance Signoff for full details.',
      appliedControls,
    };
  }

  appliedControls.push('STANDARD_GOVERNANCE_PASSED');
  return {
    allowed: true,
    reason: 'Access granted under policy governance framework.',
    appliedControls,
  };
}
