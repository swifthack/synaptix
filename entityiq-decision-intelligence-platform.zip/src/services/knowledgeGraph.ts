import { GraphNode, GraphEdge, CommunitySummary, UBONode, UBOGraphProduct } from '../types/entityiq';
import { INITIAL_GRAPH_NODES, INITIAL_GRAPH_EDGES, INITIAL_COMMUNITY_SUMMARIES } from '../data/mockDatabase';

export function getGraphSubtree(
  centerEntityId: string,
  nodes: GraphNode[] = INITIAL_GRAPH_NODES,
  edges: GraphEdge[] = INITIAL_GRAPH_EDGES,
  depth: number = 2
) {
  const visitedNodeIds = new Set<string>([centerEntityId]);
  const activeEdges: GraphEdge[] = [];

  let currentFrontier = [centerEntityId];

  for (let d = 0; d < depth; d++) {
    const nextFrontier: string[] = [];
    for (const nodeId of currentFrontier) {
      for (const edge of edges) {
        if (edge.source === nodeId || edge.target === nodeId) {
          if (!activeEdges.some(e => e.id === edge.id)) {
            activeEdges.push(edge);
          }
          const otherId = edge.source === nodeId ? edge.target : edge.source;
          if (!visitedNodeIds.has(otherId)) {
            visitedNodeIds.add(otherId);
            nextFrontier.push(otherId);
          }
        }
      }
    }
    currentFrontier = nextFrontier;
  }

  const activeNodes = nodes.filter(n => visitedNodeIds.has(n.id));
  return { nodes: activeNodes, edges: activeEdges };
}

export function calculateUBOGraph(
  entityId: string,
  nodes: GraphNode[] = INITIAL_GRAPH_NODES,
  edges: GraphEdge[] = INITIAL_GRAPH_EDGES
): UBOGraphProduct {
  const entityNode = nodes.find(n => n.id === entityId);
  const entityName = entityNode ? entityNode.label : entityId;

  const ubos: UBONode[] = [];

  // Find direct and indirect owners where edge type is OWNS
  function traceOwners(currentId: string, currentPct: number, currentPath: string[]) {
    const incomingOwnsEdges = edges.filter(e => e.target === currentId && (e.type === 'OWNS' || e.type === 'BENEFICIAL_OWNER'));

    if (incomingOwnsEdges.length === 0) {
      // Reached an ultimate owner node
      const ownerNode = nodes.find(n => n.id === currentId);
      if (ownerNode && currentId !== entityId) {
        ubos.push({
          id: ownerNode.id,
          name: ownerNode.label,
          type: ownerNode.type,
          ownershipPct: Math.round(currentPct * 100) / 100,
          isUltimateParent: true,
          jurisdiction: ownerNode.jurisdiction || 'Unknown',
          path: [...currentPath, ownerNode.label],
        });
      }
      return;
    }

    for (const edge of incomingOwnsEdges) {
      const ownerNode = nodes.find(n => n.id === edge.source);
      if (!ownerNode) continue;

      const edgePct = edge.ownershipPercentage ? edge.ownershipPercentage / 100 : 1.0;
      const combinedPct = currentPct * edgePct;

      if (ownerNode.type === 'PERSON') {
        ubos.push({
          id: ownerNode.id,
          name: ownerNode.label,
          type: 'PERSON',
          ownershipPct: Math.round(combinedPct * 100 * 100) / 100,
          isUltimateParent: true,
          jurisdiction: ownerNode.jurisdiction || 'Singapore',
          path: [...currentPath, ownerNode.label],
        });
      } else {
        traceOwners(ownerNode.id, combinedPct, [...currentPath, ownerNode.label]);
      }
    }
  }

  traceOwners(entityId, 1.0, [entityName]);

  const subtree = getGraphSubtree(entityId, nodes, edges, 3);

  return {
    entityId,
    entityName,
    ultimateBeneficialOwners: ubos,
    ownershipTree: subtree,
    provenance: `Graph Traversal Engine (Leiden Community + Direct Ownership Trace) - Generated ${new Date().toISOString()}`,
  };
}

export function performGraphRAGHybridSearch(query: string) {
  const queryLower = query.toLowerCase();

  // 1. Keyword & Entity match
  const matchedNodes = INITIAL_GRAPH_NODES.filter(
    n =>
      n.label.toLowerCase().includes(queryLower) ||
      n.jurisdiction?.toLowerCase().includes(queryLower) ||
      n.properties.regNo?.toLowerCase().includes(queryLower)
  );

  // 2. Community Detection Retrieval
  const matchedCommunities = INITIAL_COMMUNITY_SUMMARIES.filter(
    c =>
      c.name.toLowerCase().includes(queryLower) ||
      c.summary.toLowerCase().includes(queryLower) ||
      c.ultimateParent?.toLowerCase().includes(queryLower)
  );

  // 3. Relevant Graph Edges
  const matchedNodeIds = new Set(matchedNodes.map(n => n.id));
  const matchedEdges = INITIAL_GRAPH_EDGES.filter(
    e => matchedNodeIds.has(e.source) || matchedNodeIds.has(e.target)
  );

  return {
    query,
    nodesFound: matchedNodes,
    edgesFound: matchedEdges,
    communitiesFound: matchedCommunities,
    retrievalScore: matchedNodes.length > 0 || matchedCommunities.length > 0 ? 0.94 : 0.42,
  };
}
