export type EntityType = 'ORGANIZATION' | 'PERSON' | 'DOCUMENT';

export type RelationshipType = 'OWNS' | 'DIRECTS' | 'SUBSIDIARY_OF' | 'MENTIONS' | 'BENEFICIAL_OWNER';

export type ResolutionDecision = 'AUTO_LINK' | 'NEEDS_REVIEW' | 'NO_MATCH';

export interface BlockingKey {
  type: string;
  key: string;
}

export interface NormalizedEntityInput {
  name: string;
  registrationNumber?: string;
  lei?: string;
  taxId?: string;
  address?: string;
  jurisdiction?: string;
  directors?: string[];
  docHash?: string;
}

export interface NormalizedEntity {
  originalName: string;
  normalizedName: string;
  originalRegistrationNumber?: string;
  normalizedRegistrationNumber?: string;
  originalAddress?: string;
  normalizedAddress?: string;
  lei?: string;
  taxId?: string;
  jurisdiction?: string;
  directorsNormalized: string[];
  blockingKeys: BlockingKey[];
}

export interface InternalEntity {
  id: string;
  customerIds: string[];
  canonicalName: string;
  normalizedName: string;
  aliases: string[];
  historicalNames: string[];
  registrationNumber: string;
  normalizedRegistrationNumber: string;
  lei?: string;
  taxId?: string;
  jurisdiction: string;
  normalizedAddress: string;
  directors: string[];
  entityType: EntityType;
  status: 'ACTIVE' | 'DISSOLVED' | 'UNDER_REVIEW' | 'INACTIVE';
  incorporationDate?: string;
  industryCode?: string;
  relationshipKeys: string[];
  sanctionHit?: boolean;
  pepHit?: boolean;
  adverseMediaHit?: boolean;
}

export interface ProbabilisticFeatureScore {
  feature: string;
  score: number; // 0.0 - 1.0
  weight: number;
  explanation: string;
}

export interface MatchCandidateResult {
  candidateId: string;
  internalEntity: InternalEntity;
  blockingMatchKeys: string[];
  deterministicMatch: boolean;
  deterministicRulesTriggered: string[];
  probabilisticScore: number;
  featureScores: ProbabilisticFeatureScore[];
  totalScore: number;
  decision: ResolutionDecision;
  explanations: string[];
  confidence: number;
}

export interface ResolutionResponse {
  normalizedInput: NormalizedEntity;
  blockingKeysGenerated: BlockingKey[];
  candidatesEvaluated: number;
  matches: MatchCandidateResult[];
  recommendedDecision: ResolutionDecision;
  primaryMatch?: MatchCandidateResult;
  auditEvidenceId: string;
  timestamp: string;
}

export interface GraphNode {
  id: string;
  label: string;
  type: EntityType;
  jurisdiction?: string;
  status?: string;
  sanctionHit?: boolean;
  pepHit?: boolean;
  communityId?: string;
  properties: Record<string, any>;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  type: RelationshipType;
  ownershipPercentage?: number;
  startDate?: string;
  sourceRef: string;
  confidence: number;
}

export interface CommunitySummary {
  communityId: string;
  name: string;
  memberCount: number;
  ultimateParent?: string;
  totalGroupExposureUsd: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  summary: string;
}

export interface KYBPack {
  entityId: string;
  legalIdentity: {
    canonicalName: string;
    registrationNumber: string;
    lei?: string;
    jurisdiction: string;
    status: string;
    incorporationDate?: string;
  };
  aliases: string[];
  registeredAddress: string;
  directors: { name: string; appointmentDate?: string; nationality?: string }[];
  evidencePointers: string[];
  lastUpdated: string;
}

export interface ScreeningBundle {
  entityId: string;
  sanctions: { hit: boolean; matchedName?: string; listName?: string; score?: number }[];
  pepStatus: { hit: boolean; personName?: string; role?: string }[];
  adverseMedia: { hit: boolean; headline?: string; date?: string; sentiment?: string }[];
  overallRiskScore: number;
  evidenceId: string;
}

export interface UBONode {
  id: string;
  name: string;
  type: EntityType;
  ownershipPct: number;
  isUltimateParent: boolean;
  jurisdiction: string;
  path: string[];
}

export interface UBOGraphProduct {
  entityId: string;
  entityName: string;
  ultimateBeneficialOwners: UBONode[];
  ownershipTree: {
    nodes: GraphNode[];
    edges: GraphEdge[];
  };
  provenance: string;
}

export interface EvidenceItem {
  id: string;
  sourceSystem: string;
  documentRef?: string;
  timestamp: string;
  confidenceScore: number;
  attribution: string;
  hash: string;
}

export interface EvidenceBundleProduct {
  entityId: string;
  evidenceRegistry: EvidenceItem[];
  lineageChain: string[];
  auditabilityStatus: 'FULLY_VERIFIED' | 'PARTIALLY_VERIFIED' | 'UNVERIFIED';
}

export interface ChangeEventItem {
  id: string;
  entityId: string;
  entityName: string;
  eventType: 'REGISTRY_STATUS_CHANGE' | 'DIRECTOR_CHANGE' | 'UBO_CHANGE' | 'SANCTION_UPDATE';
  oldValue: string;
  newValue: string;
  timestamp: string;
  suggestedAction: string;
  targetRole: 'KYC_ANALYST' | 'CREDIT_OFFICER' | 'COMPLIANCE_INVESTIGATOR' | 'RM';
  status: 'PENDING' | 'REVIEWED' | 'DISMISSED';
}

export type UserRole = 'KYC_ANALYST' | 'COMPLIANCE_INVESTIGATOR' | 'CREDIT_OFFICER' | 'RM';

export interface MultiAgentGraphCallPayload {
  callingAgent: string;
  receivingAgent: string;
  purpose: string;
  cypherQuery: string;
  subGraph: {
    nodes: GraphNode[];
    edges: GraphEdge[];
  };
  renderDirective: 'SUBGRAPH_CANVAS' | 'UBO_TREE' | 'SANCTION_CHAIN';
  timestamp: string;
}

export interface AgentChatMessage {
  id: string;
  sender: 'user' | 'agent';
  agentType?: 'ORCHESTRATOR' | 'KYC' | 'RISK' | 'INVESTIGATION';
  text: string;
  timestamp: string;
  dataProduct?: {
    type: 'KYB' | 'SCREENING' | 'UBO' | 'EVIDENCE' | 'RESOLUTION';
    data: any;
  };
  multiAgentGraphCall?: MultiAgentGraphCallPayload;
  sources?: string[];
  graphView?: boolean;
}
