import React, { useState, useEffect } from 'react';
import { UserRole } from './types/entityiq';
import { Header } from './components/Header';
import { ArchitectureView } from './components/ArchitectureView';
import { EntityResolutionLab } from './components/EntityResolutionLab';
import { KnowledgeGraphView } from './components/KnowledgeGraphView';
import { ProductCatalogView } from './components/ProductCatalogView';
import { ChangeAndPolicyView } from './components/ChangeAndPolicyView';
import { AgenticAISuite } from './components/AgenticAISuite';
import { Neo4jArchitectureExplorer } from './components/Neo4jArchitectureExplorer';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('architecture');
  const [userRole, setUserRole] = useState<UserRole>('KYC_ANALYST');
  const [serverConnected, setServerConnected] = useState<boolean>(true);

  // Health check on backend server
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        if (data.status === 'ok') {
          setServerConnected(true);
        }
      })
      .catch(() => {
        setServerConnected(false);
      });
  }, []);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans antialiased selection:bg-indigo-500 selection:text-white">
      
      {/* Platform Header Navigation */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        userRole={userRole}
        setUserRole={setUserRole}
        serverConnected={serverConnected}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {currentTab === 'architecture' && <ArchitectureView />}
        {currentTab === 'neo4j' && <Neo4jArchitectureExplorer />}
        {currentTab === 'resolution' && <EntityResolutionLab />}
        {currentTab === 'graph' && <KnowledgeGraphView />}
        {currentTab === 'products' && <ProductCatalogView />}
        {currentTab === 'monitoring' && (
          <ChangeAndPolicyView
            id="VIEW-MONITORING"
            entityId="ENT-SG-1001"
            entityName="ABC Construction Pte. Ltd."
            eventType="DIRECTOR_CHANGE"
            oldValue="Tan Ah Kow"
            newValue="Tan Ah Kow, John Richard Smith"
            timestamp={new Date().toISOString()}
            suggestedAction="Review director change and trigger PEP/Sanctions scan"
            targetRole="KYC_ANALYST"
            status="PENDING"
            userRole={userRole}
          />
        )}
        {currentTab === 'agents' && <AgenticAISuite userRole={userRole} />}
      </main>

      {/* Platform Footer */}
      <footer className="bg-slate-900 text-slate-400 py-6 border-t border-slate-800 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-white">EntityIQ Decision Intelligence Platform v2.0</span>
            <span className="text-slate-600">|</span>
            <span>Commercial & Investment Banking Architecture</span>
          </div>
          <div className="flex items-center space-x-4">
            <span>Powered by Gemini 3.6 Flash</span>
            <span>•</span>
            <span>GraphRAG Fusion</span>
            <span>•</span>
            <span>Leiden Community Engine</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
