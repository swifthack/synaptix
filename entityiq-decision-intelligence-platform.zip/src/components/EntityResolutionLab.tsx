import React, { useState } from 'react';
import { NormalizedEntityInput, ResolutionResponse, MatchCandidateResult } from '../types/entityiq';
import { resolveEntity } from '../services/entityResolution';
import { Cpu, CheckCircle, AlertTriangle, XCircle, Search, ShieldCheck, ArrowRight, RefreshCw, FileCheck } from 'lucide-react';

export const EntityResolutionLab: React.FC = () => {
  const [formData, setFormData] = useState<NormalizedEntityInput>({
    name: 'ABC Construction Pte. Ltd.',
    registrationNumber: '201812345E',
    lei: '5493001KJ95729X4301',
    taxId: 'T18LL1234A',
    address: '10 Marina Boulevard #18-01, Marina Bay Financial Centre, Singapore 018983',
    jurisdiction: 'Singapore',
    directors: ['Tan Ah Kow', 'John Richard Smith'],
    docHash: 'sha256_e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
  });

  const [resolutionResult, setResolutionResult] = useState<ResolutionResponse | null>(() => {
    return resolveEntity(formData);
  });

  const [loading, setLoading] = useState(false);

  const handleRunResolution = () => {
    setLoading(true);
    setTimeout(() => {
      const res = resolveEntity(formData);
      setResolutionResult(res);
      setLoading(false);
    }, 400);
  };

  const handlePresetSelect = (type: string) => {
    if (type === 'ABC_SG') {
      setFormData({
        name: 'ABC CONSTRUCTION PTE LTD',
        registrationNumber: '201812345E',
        lei: '5493001KJ95729X4301',
        address: '10 Marina Boulevard 18-01 MBFC Singapore',
        jurisdiction: 'Singapore',
        directors: ['Tan Ah Kow'],
      });
    } else if (type === 'VERTEX_REVIEW') {
      setFormData({
        name: 'Vertex Global Group (Singapore)',
        registrationNumber: '201598765K',
        address: '1 Raffles Place #25-01 Singapore',
        jurisdiction: 'Singapore',
        directors: ['Chen Wei', 'Elena Rostova'],
      });
    } else if (type === 'NO_MATCH_NEW') {
      setFormData({
        name: 'Aetheria Cloud Technologies Pte Ltd',
        registrationNumber: '202699881M',
        address: '71 Ayer Rajah Crescent #02-12, Singapore',
        jurisdiction: 'Singapore',
        directors: ['Marcus Vance'],
      });
    }
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Cpu className="h-5 w-5 text-indigo-600" />
            <h1 className="text-xl font-bold text-slate-900">Pluggable Entity Resolution Core</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Standardization, blocking key generation, deterministic rules, probabilistic scoring, and decision threshold routing.
          </p>
        </div>

        {/* Preset Selector */}
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold text-slate-500">Test Scenarios:</span>
          <button
            onClick={() => handlePresetSelect('ABC_SG')}
            className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-medium text-slate-700 transition-colors"
          >
            ABC Construction (Auto-Link)
          </button>
          <button
            onClick={() => handlePresetSelect('VERTEX_REVIEW')}
            className="px-2.5 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-xs font-medium text-amber-800 border border-amber-200 transition-colors"
          >
            Vertex Group (Needs Review)
          </button>
          <button
            onClick={() => handlePresetSelect('NO_MATCH_NEW')}
            className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-medium text-slate-700 transition-colors"
          >
            New Company (No Match)
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Input Form & Normalization */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider pb-2 border-b border-slate-100 flex items-center justify-between">
              <span>External Input Record</span>
              <span className="text-xs font-normal text-slate-400">Incoming Feed</span>
            </h2>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-medium mb-1">Corporate Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Registration No.</label>
                  <input
                    type="text"
                    value={formData.registrationNumber || ''}
                    onChange={(e) => setFormData({ ...formData, registrationNumber: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Jurisdiction</label>
                  <input
                    type="text"
                    value={formData.jurisdiction || 'Singapore'}
                    onChange={(e) => setFormData({ ...formData, jurisdiction: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">LEI Code (Optional)</label>
                <input
                  type="text"
                  value={formData.lei || ''}
                  onChange={(e) => setFormData({ ...formData, lei: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Registered Address</label>
                <textarea
                  rows={2}
                  value={formData.address || ''}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Directors (Comma separated)</label>
                <input
                  type="text"
                  value={formData.directors?.join(', ') || ''}
                  onChange={(e) => setFormData({ ...formData, directors: e.target.value.split(',').map(s => s.trim()) })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            <button
              onClick={handleRunResolution}
              disabled={loading}
              className="w-full mt-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-2 shadow-md shadow-indigo-600/20 transition-colors"
            >
              {loading ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  <span>Running Resolution Core...</span>
                </>
              ) : (
                <>
                  <Cpu className="h-4 w-4" />
                  <span>Execute Entity Resolution Engine</span>
                </>
              )}
            </button>
          </div>

          {/* Normalization & Blocking Keys Display */}
          {resolutionResult && (
            <div className="bg-slate-900 text-white p-5 rounded-2xl space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-400 pb-2 border-b border-slate-800">
                Normalization Engine Output
              </h3>

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-slate-400">Normalized Name:</span>
                  <div className="font-mono text-emerald-400 bg-slate-800 p-2 rounded mt-1">
                    "{resolutionResult.normalizedInput.normalizedName}"
                  </div>
                </div>

                <div>
                  <span className="text-slate-400">Normalized Registration No:</span>
                  <div className="font-mono text-emerald-400 bg-slate-800 p-2 rounded mt-1">
                    "{resolutionResult.normalizedInput.normalizedRegistrationNumber || 'N/A'}"
                  </div>
                </div>

                <div>
                  <span className="text-slate-400">Generated Blocking Keys:</span>
                  <div className="flex flex-wrap gap-1.5 mt-1.5">
                    {resolutionResult.blockingKeysGenerated.map((bk, i) => (
                      <span key={i} className="px-2 py-1 bg-indigo-900/60 border border-indigo-700/60 text-indigo-300 font-mono rounded text-[10px]">
                        {bk.key}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Resolution Engine Results */}
        <div className="lg:col-span-7 space-y-6">
          {resolutionResult ? (
            <>
              {/* Classification Threshold Banner */}
              <div className={`p-5 rounded-2xl border shadow-sm flex items-center justify-between ${
                resolutionResult.recommendedDecision === 'AUTO_LINK'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : resolutionResult.recommendedDecision === 'NEEDS_REVIEW'
                  ? 'bg-amber-50 border-amber-200 text-amber-900'
                  : 'bg-slate-50 border-slate-200 text-slate-900'
              }`}>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    {resolutionResult.recommendedDecision === 'AUTO_LINK' && <CheckCircle className="h-6 w-6 text-emerald-600" />}
                    {resolutionResult.recommendedDecision === 'NEEDS_REVIEW' && <AlertTriangle className="h-6 w-6 text-amber-600" />}
                    {resolutionResult.recommendedDecision === 'NO_MATCH' && <XCircle className="h-6 w-6 text-slate-500" />}
                    <h2 className="text-lg font-bold">
                      Recommendation: {resolutionResult.recommendedDecision.replace('_', ' ')}
                    </h2>
                  </div>
                  <p className="text-xs opacity-80">
                    Audit Evidence Ref: <span className="font-mono font-bold">{resolutionResult.auditEvidenceId}</span>
                  </p>
                </div>

                {/* Score Gauge */}
                <div className="text-right">
                  <span className="text-2xl font-black block">
                    {(resolutionResult.primaryMatch?.totalScore ? resolutionResult.primaryMatch.totalScore * 100 : 0).toFixed(1)}%
                  </span>
                  <span className="text-[10px] font-semibold uppercase tracking-wider block opacity-75">
                    Match Score
                  </span>
                </div>
              </div>

              {/* Threshold Specification Legend */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 grid grid-cols-3 gap-3 text-center text-xs">
                <div className={`p-2.5 rounded-lg border ${
                  resolutionResult.recommendedDecision === 'AUTO_LINK' ? 'bg-emerald-100 border-emerald-300 font-bold' : 'bg-slate-50 border-slate-200 text-slate-500'
                }`}>
                  <span className="block text-[10px] uppercase text-emerald-800">0.92 - 1.00</span>
                  <span>AUTO LINK</span>
                </div>
                <div className={`p-2.5 rounded-lg border ${
                  resolutionResult.recommendedDecision === 'NEEDS_REVIEW' ? 'bg-amber-100 border-amber-300 font-bold' : 'bg-slate-50 border-slate-200 text-slate-500'
                }`}>
                  <span className="block text-[10px] uppercase text-amber-800">0.78 - 0.91</span>
                  <span>NEEDS REVIEW</span>
                </div>
                <div className={`p-2.5 rounded-lg border ${
                  resolutionResult.recommendedDecision === 'NO_MATCH' ? 'bg-slate-200 border-slate-300 font-bold' : 'bg-slate-50 border-slate-200 text-slate-500'
                }`}>
                  <span className="block text-[10px] uppercase text-slate-600">&lt; 0.78</span>
                  <span>NO MATCH</span>
                </div>
              </div>

              {/* Evaluated Candidates */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider pb-2 border-b border-slate-100 flex items-center justify-between">
                  <span>Candidate Customer Records Evaluated ({resolutionResult.candidatesEvaluated})</span>
                </h3>

                {resolutionResult.matches.length === 0 ? (
                  <p className="text-xs text-slate-500 italic py-4 text-center">No existing customer records met the candidate threshold.</p>
                ) : (
                  <div className="space-y-4">
                    {resolutionResult.matches.map((cand, idx) => (
                      <div key={idx} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-bold text-sm text-slate-900">{cand.internalEntity.canonicalName}</span>
                            <div className="text-xs text-slate-500 font-mono">
                              ID: {cand.internalEntity.id} | Reg: {cand.internalEntity.registrationNumber} ({cand.internalEntity.jurisdiction})
                            </div>
                          </div>
                          <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                            cand.decision === 'AUTO_LINK' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {(cand.totalScore * 100).toFixed(1)}% Match
                          </span>
                        </div>

                        {/* Deterministic Rules Triggered */}
                        {cand.deterministicMatch && (
                          <div className="bg-emerald-50 border border-emerald-200 p-2 rounded-lg text-xs text-emerald-900 flex items-center space-x-2">
                            <CheckCircle className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                            <span>
                              <strong>Deterministic Match Triggered:</strong> {cand.deterministicRulesTriggered.join(', ')}
                            </span>
                          </div>
                        )}

                        {/* Probabilistic Feature Score Breakdown */}
                        <div className="space-y-2 pt-2 border-t border-slate-200/60">
                          <span className="text-[11px] font-bold uppercase text-slate-600 block">Probabilistic Feature Matrix</span>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            {cand.featureScores.map((fs, fIdx) => (
                              <div key={fIdx} className="bg-white p-2 rounded border border-slate-200">
                                <div className="flex items-center justify-between font-medium text-slate-800">
                                  <span>{fs.feature}</span>
                                  <span className="text-indigo-600 font-bold">{(fs.score * 100).toFixed(0)}%</span>
                                </div>
                                <div className="w-full bg-slate-100 h-1.5 rounded-full mt-1.5 overflow-hidden">
                                  <div className="bg-indigo-600 h-1.5 rounded-full" style={{ width: `${fs.score * 100}%` }} />
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Reasoning Explanations */}
                        <div className="bg-slate-900 text-slate-300 p-3 rounded-lg text-xs space-y-1">
                          <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">Explainability & Reasoning Log</span>
                          {cand.explanations.map((exp, eIdx) => (
                            <p key={eIdx} className="text-slate-200 flex items-center space-x-1">
                              <span className="text-indigo-400">›</span> <span>{exp}</span>
                            </p>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center py-12 text-slate-500">
              Select or enter an input record to execute entity resolution.
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
