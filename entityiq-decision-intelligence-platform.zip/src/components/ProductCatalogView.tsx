import React, { useState } from 'react';
import { INITIAL_INTERNAL_ENTITIES } from '../data/mockDatabase';
import {
  getKYBPackProduct,
  getScreeningBundleProduct,
  getUBOGraphProduct,
  getEvidenceBundleProduct,
} from '../services/productCatalog';
import { FileText, ShieldAlert, GitMerge, FileCheck, Copy, Check, Download } from 'lucide-react';

export const ProductCatalogView: React.FC = () => {
  const [selectedEntityId, setSelectedEntityId] = useState<string>('ENT-SG-1002');
  const [activeProductTab, setActiveProductTab] = useState<'KYB' | 'SCREENING' | 'UBO' | 'EVIDENCE'>('KYB');
  const [copied, setCopied] = useState(false);

  const kyb = getKYBPackProduct(selectedEntityId);
  const screening = getScreeningBundleProduct(selectedEntityId);
  const ubo = getUBOGraphProduct(selectedEntityId);
  const evidence = getEvidenceBundleProduct(selectedEntityId);

  const activeProductData =
    activeProductTab === 'KYB'
      ? kyb
      : activeProductTab === 'SCREENING'
      ? screening
      : activeProductTab === 'UBO'
      ? ubo
      : evidence;

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(activeProductData, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <FileText className="h-5 w-5 text-indigo-600" />
            <h1 className="text-xl font-bold text-slate-900">Standardized Decision Products Catalog</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Consumption Layer APIs: Reusable, evidence-backed data packages for onboarding, screening, credit, and risk journeys.
          </p>
        </div>

        {/* Target Entity Switcher */}
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold text-slate-500">Target Entity:</span>
          <select
            value={selectedEntityId}
            onChange={(e) => setSelectedEntityId(e.target.value)}
            className="bg-slate-100 border border-slate-300 text-slate-800 text-xs font-semibold rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
          >
            {INITIAL_INTERNAL_ENTITIES.map((ent) => (
              <option key={ent.id} value={ent.id}>
                {ent.canonicalName} ({ent.jurisdiction})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Product Category Tabs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          onClick={() => setActiveProductTab('KYB')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeProductTab === 'KYB'
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/20'
              : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center space-x-3">
            <FileText className={`h-5 w-5 ${activeProductTab === 'KYB' ? 'text-white' : 'text-indigo-600'}`} />
            <div>
              <span className="font-bold text-sm block">KYB Pack API</span>
              <span className="text-[11px] opacity-80 block">Legal Identity & Directors</span>
            </div>
          </div>
        </button>

        <button
          onClick={() => setActiveProductTab('SCREENING')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeProductTab === 'SCREENING'
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/20'
              : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center space-x-3">
            <ShieldAlert className={`h-5 w-5 ${activeProductTab === 'SCREENING' ? 'text-white' : 'text-rose-600'}`} />
            <div>
              <span className="font-bold text-sm block">Screening Bundle</span>
              <span className="text-[11px] opacity-80 block">Sanctions, PEP & Media</span>
            </div>
          </div>
        </button>

        <button
          onClick={() => setActiveProductTab('UBO')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeProductTab === 'UBO'
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/20'
              : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center space-x-3">
            <GitMerge className={`h-5 w-5 ${activeProductTab === 'UBO' ? 'text-white' : 'text-teal-600'}`} />
            <div>
              <span className="font-bold text-sm block">UBO Graph API</span>
              <span className="text-[11px] opacity-80 block">Ownership & Control Tree</span>
            </div>
          </div>
        </button>

        <button
          onClick={() => setActiveProductTab('EVIDENCE')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeProductTab === 'EVIDENCE'
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/20'
              : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center space-x-3">
            <FileCheck className={`h-5 w-5 ${activeProductTab === 'EVIDENCE' ? 'text-white' : 'text-emerald-600'}`} />
            <div>
              <span className="font-bold text-sm block">Evidence Bundle</span>
              <span className="text-[11px] opacity-80 block">Audit Trail & Lineage</span>
            </div>
          </div>
        </button>
      </div>

      {/* Product Detail Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Rendered Visual Card */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            
            {activeProductTab === 'KYB' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h2 className="text-base font-bold text-slate-900">{kyb.legalIdentity.canonicalName}</h2>
                  <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 font-bold text-xs rounded-full">
                    {kyb.legalIdentity.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-xl">
                    <span className="text-slate-500 text-[10px] uppercase font-semibold block">Registration Number</span>
                    <span className="font-bold text-slate-900 mt-0.5 block">{kyb.legalIdentity.registrationNumber}</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl">
                    <span className="text-slate-500 text-[10px] uppercase font-semibold block">Jurisdiction</span>
                    <span className="font-bold text-slate-900 mt-0.5 block">{kyb.legalIdentity.jurisdiction}</span>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl text-xs space-y-1">
                  <span className="text-slate-500 text-[10px] uppercase font-semibold block">Registered Office Address</span>
                  <p className="font-medium text-slate-800">{kyb.registeredAddress}</p>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-800 block">Board of Directors ({kyb.directors.length})</span>
                  <div className="space-y-1.5 text-xs">
                    {kyb.directors.map((d, i) => (
                      <div key={i} className="p-2.5 rounded-lg border border-slate-200 flex items-center justify-between">
                        <span className="font-bold text-slate-900">{d.name}</span>
                        <span className="text-slate-500 text-[11px]">{d.nationality} National</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeProductTab === 'SCREENING' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h2 className="text-base font-bold text-slate-900">Screening Risk Assessment</h2>
                  <span className={`px-3 py-1 rounded-full text-xs font-black ${
                    screening.overallRiskScore > 50 ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    Overall Risk: {screening.overallRiskScore}/100
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                    <div className="flex items-center justify-between font-bold">
                      <span className="text-slate-900">Sanction Checks:</span>
                      <span className={screening.sanctions[0]?.hit ? 'text-rose-600 font-bold' : 'text-emerald-600 font-bold'}>
                        {screening.sanctions[0]?.hit ? 'HIT DETECTED' : 'CLEARED'}
                      </span>
                    </div>
                    {screening.sanctions[0]?.hit && (
                      <p className="text-rose-800 bg-rose-50 p-2 rounded mt-1 border border-rose-200">
                        {screening.sanctions[0].matchedName} on {screening.sanctions[0].listName}
                      </p>
                    )}
                  </div>

                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                    <div className="flex items-center justify-between font-bold">
                      <span className="text-slate-900">PEP Connections:</span>
                      <span className={screening.pepStatus[0]?.hit ? 'text-amber-600 font-bold' : 'text-emerald-600 font-bold'}>
                        {screening.pepStatus[0]?.hit ? 'PEP LINK IDENTIFIED' : 'CLEARED'}
                      </span>
                    </div>
                    {screening.pepStatus[0]?.hit && (
                      <p className="text-amber-900 bg-amber-50 p-2 rounded mt-1 border border-amber-200">
                        {screening.pepStatus[0].personName} ({screening.pepStatus[0].role})
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {activeProductTab === 'UBO' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h2 className="text-base font-bold text-slate-900">Ultimate Beneficial Owners ({ubo.ultimateBeneficialOwners.length})</h2>
                  <span className="text-xs text-slate-500">Algorithm: Graph Traversal</span>
                </div>

                <div className="space-y-2 text-xs">
                  {ubo.ultimateBeneficialOwners.map((owner) => (
                    <div key={owner.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between">
                      <div>
                        <span className="font-bold text-slate-900 block">{owner.name} ({owner.type})</span>
                        <span className="text-[11px] text-slate-500">Ownership Path: {owner.path.join(' → ')}</span>
                      </div>
                      <span className="text-sm font-black text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100">
                        {owner.ownershipPct}% UBO
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeProductTab === 'EVIDENCE' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h2 className="text-base font-bold text-slate-900">Evidence Registry Provenance</h2>
                  <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 font-bold text-xs rounded-full">
                    {evidence.auditabilityStatus}
                  </span>
                </div>

                <div className="space-y-2 text-xs">
                  {evidence.evidenceRegistry.map((item) => (
                    <div key={item.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                      <div className="flex items-center justify-between font-bold text-slate-900">
                        <span>{item.sourceSystem}</span>
                        <span className="text-emerald-600 font-mono">Confidence: {(item.confidenceScore * 100).toFixed(0)}%</span>
                      </div>
                      <p className="text-slate-500 text-[11px] font-mono truncate">Doc Hash: {item.hash}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        </div>

        {/* JSON Code Response View */}
        <div className="lg:col-span-5">
          <div className="bg-slate-900 text-slate-200 p-5 rounded-2xl border border-slate-800 shadow-sm space-y-3 h-full flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
                  REST API Endpoint Payload ({activeProductTab})
                </span>
                <button
                  onClick={handleCopyJson}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs flex items-center space-x-1.5 transition-colors"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Payload'}</span>
                </button>
              </div>

              <pre className="text-[11px] font-mono bg-slate-950 p-4 rounded-xl text-emerald-400 overflow-x-auto max-h-[360px] scrollbar-thin">
                {JSON.stringify(activeProductData, null, 2)}
              </pre>
            </div>

            <p className="text-[11px] text-slate-400 italic pt-2">
              All data products adhere to strict EntityIQ field-level governance and schema specs.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
};
