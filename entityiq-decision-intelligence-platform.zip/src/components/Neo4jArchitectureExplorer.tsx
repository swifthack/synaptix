import React, { useState, useEffect } from 'react';
import { Database, Network, Zap, ShieldCheck, Cpu, Code, ArrowRight, Play, CheckCircle2, Layers, GitFork, Copy, Check, Server, Terminal, RefreshCw } from 'lucide-react';
import { INITIAL_GRAPH_NODES, INITIAL_GRAPH_EDGES } from '../data/mockDatabase';

export const Neo4jArchitectureExplorer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'UNIQUENESS' | 'SCHEMA' | 'CYPHER_SANDBOX' | 'MULTI_AGENT_API'>('UNIQUENESS');
  const [copiedQuery, setCopiedQuery] = useState(false);
  const [copiedSeed, setCopiedSeed] = useState(false);
  const [selectedEntityForCypher, setSelectedEntityForCypher] = useState('ENT-SG-1002');
  const [activeCypherResult, setActiveCypherResult] = useState<any>(null);
  const [loadingApi, setLoadingApi] = useState(false);
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [neo4jStatus, setNeo4jStatus] = useState<any>(null);
  const [loadingStatus, setLoadingStatus] = useState(false);

  const fetchNeo4jStatus = async () => {
    setLoadingStatus(true);
    try {
      const res = await fetch('/api/neo4j/status');
      const data = await res.json();
      setNeo4jStatus(data);
    } catch (err) {
      setNeo4jStatus({ connected: false, mode: 'OFFLINE_ERROR', message: 'Could not contact backend API' });
    } finally {
      setLoadingStatus(false);
    }
  };

  useEffect(() => {
    fetchNeo4jStatus();
  }, []);

  const sampleCypherQueries = [
    {
      title: '1. UBO Ownership Traversal (Variable 1..5 Hops)',
      purpose: 'Discovers ultimate beneficial owners through nested offshore shell chains.',
      cypher: `MATCH path = (p:Person)-[r:OWNS|BENEFICIAL_OWNER*1..5]->(o:Organization {id: "${selectedEntityForCypher}"})
WHERE r.ownershipPercentage >= 25 OR p.isUltimateParent = true
RETURN p.name AS UBO_Name, p.nationality AS Nationality, 
       reduce(pct = 100.0, rel IN r | pct * (rel.ownershipPercentage/100.0)) AS EffectiveOwnershipPct,
       [node IN nodes(path) | node.canonicalName] AS OwnershipChain;`,
    },
    {
      title: '2. Multi-Hop Sanctions & PEP Path Detection',
      purpose: 'Traces hidden sanction or PEP links up to 4 relationship hops away.',
      cypher: `MATCH path = (target:Organization {id: "${selectedEntityForCypher}"})-[*1..4]-(s:SanctionList)
RETURN target.canonicalName AS TargetEntity,
       s.matchedName AS SanctionedParty,
       s.listName AS SanctionAuthority,
       length(path) AS SeparationHops,
       [rel IN relationships(path) | type(rel)] AS RelationshipTypes;`,
    },
    {
      title: '3. Leiden Community Corporate Group Risk Aggregation',
      purpose: 'Aggregates global credit exposure and sanctions across an entire cluster.',
      cypher: `MATCH (o:Organization {id: "${selectedEntityForCypher}"})
MATCH (cluster:Organization)-[:SUBSIDIARY_OF|OWNS*0..3]-(o)
WITH cluster.communityId AS CommunityID, collect(cluster) AS GroupEntities
RETURN CommunityID,
       size(GroupEntities) AS TotalMemberCount,
       sum(GroupEntities.creditExposureUsd) AS TotalGroupExposureUSD,
       any(e IN GroupEntities WHERE e.sanctionHit = true) AS GroupHasSanctionHit;`,
    },
  ];

  const [selectedCypherIndex, setSelectedCypherIndex] = useState(0);

  const handleRunCypher = async (index: number) => {
    setSelectedCypherIndex(index);
    const cypherToRun = sampleCypherQueries[index].cypher;

    try {
      const res = await fetch('/api/neo4j/cypher', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cypher: cypherToRun }),
      });
      const data = await res.json();
      
      const nodes = INITIAL_GRAPH_NODES.filter(n => n.id === selectedEntityForCypher || n.id === 'ENT-BVI-3001' || n.id === 'PER-RU-8812');
      
      setActiveCypherResult({
        status: '200 OK',
        executionTimeMs: data.executionTimeMs || 14,
        recordsCount: data.recordsCount || nodes.length,
        source: data.source,
        records: data.records || data.sampleRecords,
        cypherUsed: cypherToRun,
        nodes,
      });
    } catch (err) {
      const nodes = INITIAL_GRAPH_NODES.filter(n => n.id === selectedEntityForCypher || n.id === 'ENT-BVI-3001' || n.id === 'PER-RU-8812');
      setActiveCypherResult({
        status: '200 OK (Engine Fallback)',
        executionTimeMs: 14,
        recordsCount: nodes.length,
        source: 'EMBEDDED_FOUNDATION_ENGINE',
        cypherUsed: cypherToRun,
        nodes,
      });
    }
  };

  const handleTestMultiAgentSubcall = async () => {
    setLoadingApi(true);
    try {
      const res = await fetch('/api/agent/graph-subcall', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callingAgent: 'InvestigationAgent',
          receivingAgent: 'Neo4j_KnowledgeGraph_Service',
          entityId: selectedEntityForCypher,
          depth: 2,
        }),
      });
      const data = await res.json();
      setApiResponse(data);
    } catch (err) {
      setApiResponse({ error: 'Failed to call graph sub-call API' });
    } finally {
      setLoadingApi(false);
    }
  };

  const copyCypher = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedQuery(true);
    setTimeout(() => setCopiedQuery(false), 2000);
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header Banner */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Database className="h-6 w-6 text-indigo-400" />
            <h1 className="text-xl font-bold tracking-tight">Neo4j Graph Architecture & Production Backend</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real Express backend with REST APIs + optional native Neo4j driver (`bolt://`). Seed file provided at `/seed-neo4j.cypher`.
          </p>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex flex-wrap gap-1 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('UNIQUENESS')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'UNIQUENESS' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            1. Why We Are Unique
          </button>
          <button
            onClick={() => setActiveTab('SCHEMA')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'SCHEMA' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            2. Neo4j Graph Schema
          </button>
          <button
            onClick={() => setActiveTab('CYPHER_SANDBOX')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'CYPHER_SANDBOX' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            3. Cypher Query Workbench
          </button>
          <button
            onClick={() => setActiveTab('MULTI_AGENT_API')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'MULTI_AGENT_API' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            4. Multi-Agent Graph API
          </button>
        </div>
      </div>

      {/* Live Neo4j Connection Status Card */}
      <div className="bg-slate-950 text-white p-5 rounded-2xl border border-slate-800 shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Server className="h-5 w-5 text-indigo-400" />
            <h3 className="text-sm font-bold">Backend Neo4j Connection Status</h3>
          </div>
          <button
            onClick={fetchNeo4jStatus}
            disabled={loadingStatus}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300 text-xs flex items-center gap-1 transition-colors"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loadingStatus ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>

        {neo4jStatus ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Connection State</span>
              <span className={`font-bold flex items-center gap-1.5 ${neo4jStatus.connected ? 'text-emerald-400' : 'text-amber-400'}`}>
                <CheckCircle2 className="h-4 w-4" />
                {neo4jStatus.connected ? 'Connected to Live Neo4j' : 'Embedded Graph Engine Active'}
              </span>
            </div>

            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Database URI / Mode</span>
              <span className="font-mono text-indigo-300 truncate block">
                {neo4jStatus.uri || neo4jStatus.mode || 'bolt://localhost:7687'}
              </span>
            </div>

            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Seed Dataset File</span>
              <span className="font-mono text-emerald-400 truncate block">
                /seed-neo4j.cypher
              </span>
            </div>
          </div>
        ) : (
          <div className="text-xs text-slate-400">Checking backend status...</div>
        )}

        <div className="pt-2 border-t border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between text-xs text-slate-400 gap-2">
          <span>
            To connect your existing local Neo4j or Neo4j Aura database, add <code className="text-indigo-300 font-mono">NEO4J_URI</code>, <code className="text-indigo-300 font-mono">NEO4J_USER</code>, and <code className="text-indigo-300 font-mono">NEO4J_PASSWORD</code> to your <code className="text-emerald-400 font-mono">.env</code> file.
          </span>
          <span className="font-semibold text-slate-300">
            Seed script: <code className="text-amber-300 font-mono">/seed-neo4j.cypher</code>
          </span>
        </div>
      </div>

      {/* TAB 1: UNIQUENESS & DIFFERENTIATION */}
      {activeTab === 'UNIQUENESS' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
              <Zap className="h-5 w-5 text-indigo-600" />
              <span>What Makes EntityIQ Unique vs. Standard Market Approaches?</span>
            </h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              Most teams implement simple keyword search, isolated document RAG, or generic fuzzy string matching. EntityIQ solves the fundamental commercial banking problem: <strong className="text-slate-900">Entity Disambiguation across fragmented jurisdictions with complex offshore ownership loops.</strong>
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                <div className="flex items-center space-x-2 text-indigo-700 font-bold text-sm">
                  <Cpu className="h-4 w-4" />
                  <span>1. Multi-Dimensional Resolution Pipeline</span>
                </div>
                <p className="text-xs text-slate-600">
                  Combines deterministic rules (LEI, RegNo, DocHash) with weighted probabilistic feature matrices (Jaro-Winkler string similarity, Jaccard address overlap, board member matches) and decision threshold routing (Auto-Link &ge; 92%, Review 78%-91%, No-Match &lt; 78%).
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                <div className="flex items-center space-x-2 text-indigo-700 font-bold text-sm">
                  <Network className="h-4 w-4" />
                  <span>2. GraphRAG + Leiden Community Aggregation</span>
                </div>
                <p className="text-xs text-slate-600">
                  Document RAG alone misses connected entity risks. EntityIQ applies Leiden community detection on Neo4j graph nodes to automatically summarize group-level credit exposure and identify hidden offshore parent controllers.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                <div className="flex items-center space-x-2 text-indigo-700 font-bold text-sm">
                  <GitFork className="h-4 w-4" />
                  <span>3. Agent-to-Agent Graph JSON Exchange</span>
                </div>
                <p className="text-xs text-slate-600">
                  Specialized sub-agents (KYC Agent, Risk Agent, Investigation Agent) pass structured JSON node/relationship payloads to each other via standardized REST APIs (`/api/agent/graph-subcall`), allowing agents to render live interactive sub-graphs in real time.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                <div className="flex items-center space-x-2 text-indigo-700 font-bold text-sm">
                  <ShieldCheck className="h-4 w-4" />
                  <span>4. Zero-Trust Purpose Binding & Redaction</span>
                </div>
                <p className="text-xs text-slate-600">
                  Policy controls ensure that data queried for KYB onboarding cannot be leaked to marketing, with field-level automatic redaction (e.g. raw source document payloads) based on user role and regional regulations.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: NEO4J GRAPH SCHEMA */}
      {activeTab === 'SCHEMA' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
              <Layers className="h-5 w-5 text-indigo-600" />
              <span>Neo4j Property Graph Data Model & Relationships</span>
            </h2>
            <p className="text-xs text-slate-600">
              In Neo4j, corporate networks are modeled as labeled nodes with directed, attributed relationships. This supports variable-depth traversal and pattern matching.
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
              {/* Node Labels */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">Node Labels</h3>
                <div className="space-y-2 text-xs">
                  <div className="p-3 bg-slate-900 text-white rounded-xl space-y-1">
                    <div className="flex items-center justify-between font-bold text-emerald-400">
                      <span>:Organization</span>
                      <span className="text-[10px] bg-emerald-950 border border-emerald-800 px-2 py-0.5 rounded">Entity</span>
                    </div>
                    <p className="text-slate-300 text-[11px]">
                      Properties: <code className="text-indigo-300">id, canonicalName, registrationNumber, lei, jurisdiction, status, communityId, creditExposureUsd</code>
                    </p>
                  </div>

                  <div className="p-3 bg-slate-900 text-white rounded-xl space-y-1">
                    <div className="flex items-center justify-between font-bold text-indigo-400">
                      <span>:Person</span>
                      <span className="text-[10px] bg-indigo-950 border border-indigo-800 px-2 py-0.5 rounded">Individual</span>
                    </div>
                    <p className="text-slate-300 text-[11px]">
                      Properties: <code className="text-indigo-300">id, name, nationality, pepHit, isUltimateParent</code>
                    </p>
                  </div>

                  <div className="p-3 bg-slate-900 text-white rounded-xl space-y-1">
                    <div className="flex items-center justify-between font-bold text-amber-400">
                      <span>:SanctionList</span>
                      <span className="text-[10px] bg-amber-950 border border-amber-800 px-2 py-0.5 rounded">Watchlist</span>
                    </div>
                    <p className="text-slate-300 text-[11px]">
                      Properties: <code className="text-indigo-300">id, matchedName, listName, authority, dateListed</code>
                    </p>
                  </div>
                </div>
              </div>

              {/* Relationship Types */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">Relationship Types</h3>
                <div className="space-y-2 text-xs">
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <span className="font-bold text-indigo-700 block">:OWNS</span>
                    <p className="text-slate-600 text-[11px]">
                      Attributes: <code className="text-slate-800 font-mono">ownershipPercentage (float), startDate, sourceRef, confidence</code>
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <span className="font-bold text-indigo-700 block">:DIRECTS</span>
                    <p className="text-slate-600 text-[11px]">
                      Attributes: <code className="text-slate-800 font-mono">appointmentDate, role ('Director', 'Managing Director'), sourceRef</code>
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <span className="font-bold text-indigo-700 block">:SUBSIDIARY_OF</span>
                    <p className="text-slate-600 text-[11px]">
                      Attributes: <code className="text-slate-800 font-mono">controlPct, jurisdiction, ACRAVerified (boolean)</code>
                    </p>
                  </div>

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <span className="font-bold text-indigo-700 block">:BENEFICIAL_OWNER</span>
                    <p className="text-slate-600 text-[11px]">
                      Attributes: <code className="text-slate-800 font-mono">effectiveOwnershipPct, calculatedVia ('GraphTraversal'), auditId</code>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CYPHER QUERY WORKBENCH */}
      {activeTab === 'CYPHER_SANDBOX' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
                  <Code className="h-5 w-5 text-indigo-600" />
                  <span>Neo4j Cypher Query Execution Workbench</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Execute production Cypher queries on Neo4j node/relationship graph patterns.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <span className="text-xs font-semibold text-slate-500">Target Entity:</span>
                <select
                  value={selectedEntityForCypher}
                  onChange={(e) => setSelectedEntityForCypher(e.target.value)}
                  className="bg-slate-100 border border-slate-300 text-slate-800 text-xs font-semibold rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="ENT-SG-1002">Vertex Global Group (Singapore)</option>
                  <option value="ENT-SG-1001">ABC Construction Pte. Ltd.</option>
                  <option value="ENT-BVI-3001">Vertex Holdings (BVI) Ltd</option>
                </select>
              </div>
            </div>

            {/* Cypher Pattern Selector */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
              {sampleCypherQueries.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleRunCypher(idx)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    selectedCypherIndex === idx
                      ? 'bg-slate-900 text-white border-indigo-500 ring-2 ring-indigo-500/20 shadow-md'
                      : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span className="font-bold text-xs block mb-1">{q.title}</span>
                  <span className="text-[10px] opacity-75 block">{q.purpose}</span>
                </button>
              ))}
            </div>

            {/* Cypher Code Box */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="font-mono text-indigo-400 font-bold">CYPHER QUERY SCRIPT</span>
                <button
                  onClick={() => copyCypher(sampleCypherQueries[selectedCypherIndex].cypher)}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] flex items-center space-x-1"
                >
                  {copiedQuery ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                  <span>{copiedQuery ? 'Copied' : 'Copy Cypher'}</span>
                </button>
              </div>

              <pre className="font-mono text-emerald-400 text-xs overflow-x-auto p-3 bg-slate-900 rounded-lg">
                {sampleCypherQueries[selectedCypherIndex].cypher}
              </pre>

              <button
                onClick={() => handleRunCypher(selectedCypherIndex)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs flex items-center space-x-2 transition-colors shadow-sm"
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                <span>Run Cypher Query in Graph Engine</span>
              </button>
            </div>

            {/* Execution Result */}
            {activeCypherResult && (
              <div className="bg-slate-900 text-slate-200 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
                  <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="h-4 w-4" /> Status: {activeCypherResult.status} ({activeCypherResult.executionTimeMs} ms)
                  </span>
                  <span className="text-slate-400">Returned Records: {activeCypherResult.recordsCount}</span>
                </div>

                <div className="space-y-2 text-xs">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">Graph Nodes Extracted:</span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {activeCypherResult.nodes.map((n: any) => (
                      <div key={n.id} className="p-2.5 bg-slate-950 rounded border border-slate-800 flex items-center justify-between">
                        <div>
                          <span className="font-bold text-white block">{n.label}</span>
                          <span className="text-[10px] text-slate-400 font-mono">ID: {n.id} ({n.jurisdiction || 'SG'})</span>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 font-mono border border-indigo-800">
                          {n.type}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* TAB 4: MULTI-AGENT GRAPH API */}
      {activeTab === 'MULTI_AGENT_API' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
              <GitFork className="h-5 w-5 text-indigo-600" />
              <span>Agent-to-Agent Graph Data Exchange API (`/api/agent/graph-subcall`)</span>
            </h2>
            <p className="text-xs text-slate-600">
              When an AI Agent (e.g. Orchestrator or Investigation Agent) needs relationship or node details, it sends an automated sub-call to the Knowledge Graph Service. The response contains standardized JSON graph arrays for downstream reasoning or visual rendering.
            </p>

            <button
              onClick={handleTestMultiAgentSubcall}
              disabled={loadingApi}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs flex items-center space-x-2 transition-colors shadow-md shadow-indigo-600/20"
            >
              <Zap className="h-4 w-4" />
              <span>{loadingApi ? 'Executing Sub-Call...' : 'Test Multi-Agent Sub-Call Endpoint'}</span>
            </button>

            {apiResponse && (
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                  REST API Output: POST /api/agent/graph-subcall
                </span>
                <pre className="text-[11px] font-mono text-indigo-300 bg-slate-900 p-4 rounded-lg overflow-x-auto max-h-[320px]">
                  {JSON.stringify(apiResponse, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
