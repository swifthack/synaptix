import React, { useState } from 'react';
import { UserRole, ChangeEventItem } from '../types/entityiq';
import { INITIAL_CHANGE_EVENTS } from '../data/mockDatabase';
import { checkPolicyAccess, PolicyCheckRequest, PolicyCheckResult } from '../services/policyEngine';
import { Activity, ShieldCheck, Bell, Lock, CheckCircle, AlertTriangle, ArrowRight, RefreshCw } from 'lucide-react';

interface ChangeAndPolicyViewProps {
  userRole: UserRole;
}

export const ChangeAndPolicyView: React.FC<ChangeEventItem & ChangeAndPolicyViewProps> = ({ userRole }) => {
  const [events, setEvents] = useState<ChangeEventItem[]>(INITIAL_CHANGE_EVENTS);
  const [filterRole, setFilterRole] = useState<string>('ALL');

  // Policy Engine State
  const [policyReq, setPolicyReq] = useState<PolicyCheckRequest>({
    userRole: userRole,
    purpose: 'ONBOARDING',
    targetJurisdiction: 'Singapore',
    fieldRequested: 'beneficialOwnerSummary',
  });

  const [policyRes, setPolicyRes] = useState<PolicyCheckResult | null>(() => checkPolicyAccess(policyReq));

  const handleTestPolicy = () => {
    const result = checkPolicyAccess(policyReq);
    setPolicyRes(result);
  };

  const filteredEvents = events.filter(e => filterRole === 'ALL' || e.targetRole === filterRole);

  const handleDismissEvent = (id: string) => {
    setEvents(events.map(e => e.id === id ? { ...e, status: 'DISMISSED' as const } : e));
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Activity className="h-5 w-5 text-indigo-600" />
            <h1 className="text-xl font-bold text-slate-900">Change Detection & Policy Engine</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Proactive registry monitoring, change event action routing, purpose binding, and field-level policy governance.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold text-slate-500">Filter Events By Role:</span>
          <select
            value={filterRole}
            onChange={(e) => setFilterRole(e.target.value)}
            className="bg-slate-100 border border-slate-300 text-slate-800 text-xs font-semibold rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
          >
            <option value="ALL">All Roles</option>
            <option value="KYC_ANALYST">KYC Analyst</option>
            <option value="COMPLIANCE_INVESTIGATOR">Compliance Investigator</option>
            <option value="CREDIT_OFFICER">Credit Officer</option>
            <option value="RM">RM / Client Service</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Proactive Change Monitoring Feed */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <Bell className="h-5 w-5 text-indigo-600" />
                <h2 className="text-base font-bold text-slate-900">Proactive Event Feed & Action Routing</h2>
              </div>
              <span className="text-xs text-slate-500 font-semibold">Active Events: {filteredEvents.length}</span>
            </div>

            <div className="space-y-4">
              {filteredEvents.map((evt) => (
                <div
                  key={evt.id}
                  className={`p-4 rounded-xl border transition-all ${
                    evt.eventType === 'SANCTION_UPDATE'
                      ? 'bg-rose-50/60 border-rose-200'
                      : evt.eventType === 'UBO_CHANGE'
                      ? 'bg-amber-50/60 border-amber-200'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200/60">
                    <div>
                      <span className="font-bold text-sm text-slate-900">{evt.entityName}</span>
                      <span className="text-xs text-slate-500 block font-mono">{evt.entityId}</span>
                    </div>
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      evt.status === 'PENDING' ? 'bg-indigo-100 text-indigo-800' : 'bg-slate-200 text-slate-600'
                    }`}>
                      {evt.status}
                    </span>
                  </div>

                  <div className="py-2 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between font-medium">
                      <span className="text-slate-500">Event Type:</span>
                      <span className="font-bold text-indigo-700">{evt.eventType}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                      <div className="p-2 bg-white/80 rounded border border-slate-200">
                        <span className="text-slate-400 block text-[9px] uppercase">Previous Value</span>
                        <span className="text-slate-700 font-medium">{evt.oldValue}</span>
                      </div>
                      <div className="p-2 bg-white/80 rounded border border-slate-200">
                        <span className="text-slate-400 block text-[9px] uppercase">Updated Value</span>
                        <span className="text-indigo-900 font-bold">{evt.newValue}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-200/60 flex items-center justify-between text-xs">
                    <span className="text-slate-700 font-semibold flex items-center gap-1">
                      <ArrowRight className="h-3.5 w-3.5 text-indigo-600" /> Action: {evt.suggestedAction}
                    </span>
                    {evt.status === 'PENDING' && (
                      <button
                        onClick={() => handleDismissEvent(evt.id)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded text-[11px] transition-colors"
                      >
                        Acknowledge Action
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Policy Engine Access Simulator */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center space-x-2 pb-3 border-b border-slate-100">
              <ShieldCheck className="h-5 w-5 text-indigo-600" />
              <h2 className="text-base font-bold text-slate-900">Policy Engine Controls</h2>
            </div>

            <p className="text-xs text-slate-500">
              Test purpose binding, field-level access controls, and regional governance rules.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-medium mb-1">Requester Role</label>
                <select
                  value={policyReq.userRole}
                  onChange={(e) => setPolicyReq({ ...policyReq, userRole: e.target.value as UserRole })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="KYC_ANALYST">KYC Analyst</option>
                  <option value="COMPLIANCE_INVESTIGATOR">Compliance Investigator</option>
                  <option value="CREDIT_OFFICER">Credit Officer</option>
                  <option value="RM">RM / Client Service</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Declared Purpose</label>
                <select
                  value={policyReq.purpose}
                  onChange={(e) => setPolicyReq({ ...policyReq, purpose: e.target.value as any })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="ONBOARDING">Regulatory Onboarding / KYB</option>
                  <option value="CREDIT_UNDERWRITING">Credit Underwriting</option>
                  <option value="INVESTIGATION">Compliance Investigation</option>
                  <option value="MARKETING">Marketing & Cross-Selling (Restricted)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Target Field Requested</label>
                <select
                  value={policyReq.fieldRequested}
                  onChange={(e) => setPolicyReq({ ...policyReq, fieldRequested: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="beneficialOwnerSummary">Beneficial Owner Summary</option>
                  <option value="sourceDocumentRawPayload">Source Document Raw Payload (Restricted)</option>
                  <option value="sanctionsInvestigativeNotes">Sanctions Investigative Notes (Restricted)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Target Jurisdiction</label>
                <input
                  type="text"
                  value={policyReq.targetJurisdiction}
                  onChange={(e) => setPolicyReq({ ...policyReq, targetJurisdiction: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <button
                onClick={handleTestPolicy}
                className="w-full mt-2 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-2 transition-colors"
              >
                <Lock className="h-4 w-4" />
                <span>Evaluate Policy Controls</span>
              </button>
            </div>

            {/* Policy Evaluation Output */}
            {policyRes && (
              <div className={`p-4 rounded-xl border text-xs space-y-2 mt-4 ${
                policyRes.allowed ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}>
                <div className="flex items-center space-x-2 font-bold">
                  {policyRes.allowed ? <CheckCircle className="h-5 w-5 text-emerald-600" /> : <AlertTriangle className="h-5 w-5 text-rose-600" />}
                  <span>Policy Result: {policyRes.allowed ? 'ACCESS GRANTED' : 'ACCESS DENIED'}</span>
                </div>
                <p className="leading-relaxed opacity-90">{policyRes.reason}</p>
                {policyRes.redactedValue && (
                  <div className="font-mono bg-rose-100/80 p-2 rounded text-rose-950 mt-1 font-bold">
                    Value: {policyRes.redactedValue}
                  </div>
                )}
                <div className="pt-2 border-t border-slate-200/60 flex flex-wrap gap-1">
                  {policyRes.appliedControls.map((ctrl, i) => (
                    <span key={i} className="px-2 py-0.5 bg-white/80 rounded text-[10px] font-mono font-bold border border-slate-300">
                      {ctrl}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
