import React from 'react';
import { UserRole } from '../types/entityiq';
import { Network, ShieldCheck, Cpu, UserCheck, Activity, Database, FileText, Zap } from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  serverConnected: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  userRole,
  setUserRole,
  serverConnected,
}) => {
  const tabs = [
    { id: 'architecture', label: 'Architecture & Vision', icon: Network },
    { id: 'neo4j', label: 'Neo4j & Uniqueness', icon: Zap },
    { id: 'resolution', label: 'Entity Resolution Lab', icon: Cpu },
    { id: 'graph', label: 'Knowledge Graph & GraphRAG', icon: Database },
    { id: 'products', label: 'Product Catalog', icon: FileText },
    { id: 'monitoring', label: 'Change & Policy Engine', icon: Activity },
    { id: 'agents', label: 'Agentic AI Suite', icon: UserCheck },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Platform Title */}
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-br from-indigo-500 to-blue-600 p-2 rounded-lg shadow-md shadow-indigo-500/20">
              <ShieldCheck className="h-6 w-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-200 bg-clip-text text-transparent">
                  EntityIQ
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-medium border border-indigo-500/30">
                  v2.0 Enterprise
                </span>
              </div>
              <p className="text-xs text-slate-400">Data Platform → Decision Intelligence</p>
            </div>
          </div>

          {/* User Role Switcher */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/60 text-xs">
              <span className="text-slate-400 font-medium">Role Perspective:</span>
              <select
                value={userRole}
                onChange={(e) => setUserRole(e.target.value as UserRole)}
                className="bg-transparent text-indigo-300 font-semibold focus:outline-none cursor-pointer"
              >
                <option value="KYC_ANALYST" className="bg-slate-900 text-white">KYC Analyst</option>
                <option value="COMPLIANCE_INVESTIGATOR" className="bg-slate-900 text-white">Compliance Investigator</option>
                <option value="CREDIT_OFFICER" className="bg-slate-900 text-white">Credit Officer</option>
                <option value="RM" className="bg-slate-900 text-white">RM / Client Service</option>
              </select>
            </div>

            {/* Server Connection Status Badge */}
            <div className="hidden sm:flex items-center space-x-2 bg-slate-800/50 px-2.5 py-1 rounded-full text-xs border border-slate-800">
              <span className={`h-2 w-2 rounded-full ${serverConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
              <span className="text-slate-300">{serverConnected ? 'Server Active' : 'Connecting...'}</span>
            </div>
          </div>

        </div>

        {/* Primary Navigation Tabs */}
        <nav className="flex space-x-1 overflow-x-auto pb-2 scrollbar-none pt-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setCurrentTab(tab.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 text-xs font-medium rounded-md whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`h-4 w-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
