import React, { useState } from 'react';
import {
  Layers,
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  Database,
  Search,
  Shield,
  Bot,
  Zap,
  ChevronRight,
  FileText,
} from 'lucide-react';

export const ArchitectureView: React.FC = () => {
  const [selectedLayer, setSelectedLayer] = useState<number>(1);

  const analysts = [
    {
      role: 'KYC Analyst',
      currentWork: 'Retrieve registry data, UBO information, reconcile names, match IDs, create case packs',
      currentTime: '30 - 60 mins+',
      entityIQTime: 'Instant (< 5 secs)',
      gain: '95% time reduction',
    },
    {
      role: 'Compliance Investigator',
      currentWork: 'Cross check related parties, manually validate identity, trace offshore layers',
      currentTime: '1 - 2 hours+',
      entityIQTime: 'Instant (< 10 secs)',
      gain: '92% time reduction',
    },
    {
      role: 'Credit Officer',
      currentWork: 'Build group structure manually, verify legal entities, calculate connected exposure',
      currentTime: 'Half day+',
      entityIQTime: 'Instant (< 15 secs)',
      gain: '98% time reduction',
    },
    {
      role: 'RM / Client Service',
      currentWork: 'Check corporate changes, wait for Operations and Compliance clearance',
      currentTime: 'Hours to Days',
      entityIQTime: 'Proactive Alerting',
      gain: 'Real-time action routing',
    },
  ];

  const layers = [
    {
      layer: 1,
      title: 'Layer 1: Intelligent Experience Layer',
      subtitle: 'Agentic AI Interface & Multi-Agent Orchestration',
      icon: Bot,
      color: 'from-purple-500 to-indigo-600',
      description: 'Provides autonomous AI agents tailored for banking personas, equipped with intent recognition, workflow planning, tool routing, and context memory.',
      components: ['Orchestration Agent', 'KYC Agent', 'Risk Agent', 'Investigation Agent'],
      capabilities: ['Intent Recognition', 'Planning & Workflow Orchestration', 'Tool Routing', 'Conversation Memory'],
    },
    {
      layer: 2,
      title: 'Layer 2: Retrieval & Response Layer',
      subtitle: 'GraphRAG & Hybrid Retrieval Engine',
      icon: Search,
      color: 'from-blue-500 to-cyan-600',
      description: 'Combines vector search, graph traversal, keyword search, and Leiden community detection to ground responses in verified evidence.',
      components: ['Vector Search Engine', 'Graph Traversal Module', 'Leiden Community Context', 'Evidence Citation Generator'],
      capabilities: ['Semantic Search', 'Graph Traversal', 'Evidence Generation', 'Context Citation'],
    },
    {
      layer: 3,
      title: 'Layer 3: Consumption Layer',
      subtitle: 'Journey Aggregator & Standardized Product Catalog',
      icon: FileText,
      color: 'from-teal-500 to-emerald-600',
      description: 'Packages underlying resolution and graph intelligence into standardized API data products for business journeys.',
      components: ['KYB Pack API', 'Screening API', 'UBO Graph API', 'Evidence Bundle API', 'Change Events API'],
      capabilities: ['Product Orchestration', 'Data Formatting', 'Policy Controls', 'Event Alerts'],
    },
    {
      layer: 4,
      title: 'Layer 4: EntityIQ Foundation Layer',
      subtitle: 'Normalization, Entity Resolution & Evidence Store',
      icon: Cpu,
      color: 'from-amber-500 to-orange-600',
      description: 'Core engine for corporate identity resolution, deterministic matching, probabilistic scoring, policy governance, and evidence lineage.',
      components: ['Normalization Engine', 'Entity Linking & Resolution', 'Link & Evidence Store', 'Change Detection', 'Policy Engine'],
      capabilities: ['Name/Address/ID Normalization', 'Blocking Key Generation', 'Threshold Classification (0.92+ Auto Link)', 'Audit Provenance'],
    },
    {
      layer: 5,
      title: 'Layer 5: Data Source Layer',
      subtitle: 'Internal Data, External Registries & Vendor Feeds',
      icon: Database,
      color: 'from-slate-600 to-slate-800',
      description: 'Connects to enterprise internal databases and external registry integrations (ACRA, Companies House, Sanction feeds, UBO providers).',
      components: ['Internal Canonical Data Sources', 'External Registry Feeds (ACRA, UK CH, BVI)', 'Sanctions & PEP Feeds', 'Beneficial Ownership Providers'],
      capabilities: ['Centralized Storage', 'Source Connectivity', 'Payload Ingestion', 'Historical Feed Archives'],
    },
  ];

  return (
    <div className="space-y-8 pb-12">
      
      {/* Hero Executive Summary Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-3xl">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold border border-indigo-500/30">
              <Zap className="h-3.5 w-3.5 text-indigo-400" />
              <span>EntityIQ Enterprise Strategy & Architecture</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white">
              Data Platform <span className="text-indigo-400">→</span> Decision Intelligence
            </h1>
            <p className="text-sm md:text-base text-slate-300 leading-relaxed">
              Transforming raw, disconnected vendor feeds and corporate registries into unified, evidence-backed, decision-ready data products and agentic workflow automation for commercial & investment banking.
            </p>
          </div>
          
          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60 min-w-[240px]">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Current Platform Reality</span>
            <div className="mt-2 space-y-2 text-xs">
              <div className="flex items-center justify-between text-slate-300">
                <span>External Registries:</span>
                <span className="text-emerald-400 font-medium">Connected</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Central Ingestion:</span>
                <span className="text-emerald-400 font-medium">Connected</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Current Function:</span>
                <span className="text-amber-400 font-semibold">Data Storage Only</span>
              </div>
              <div className="pt-2 border-t border-slate-700 flex items-center justify-between font-semibold">
                <span className="text-white">With EntityIQ:</span>
                <span className="text-indigo-300">Decision Ready</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Operational Problem: Analysts Acting as Data Reconcilers */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Operational Transformation Matrix</h2>
            <p className="text-xs text-slate-500">From manual data assembly to automated decision-ready intelligence</p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
            Analyst Impact
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {analysts.map((a, idx) => (
            <div key={idx} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <span className="font-bold text-sm text-slate-900">{a.role}</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {a.gain}
                </span>
              </div>
              <div className="py-3 space-y-2 text-xs">
                <p className="text-slate-600 line-clamp-2"><strong className="text-slate-800">Manual Work:</strong> {a.currentWork}</p>
                <div className="flex items-center justify-between pt-1">
                  <span className="text-slate-400 flex items-center gap-1"><Clock className="h-3 w-3 text-amber-500" /> Today:</span>
                  <span className="font-semibold text-amber-700 line-through">{a.currentTime}</span>
                </div>
                <div className="flex items-center justify-between font-bold">
                  <span className="text-indigo-600 flex items-center gap-1"><CheckCircle2 className="h-3 w-3 text-indigo-600" /> EntityIQ:</span>
                  <span className="text-indigo-700">{a.entityIQTime}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive 5-Layer Platform Architecture */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">EntityIQ 5-Layer Platform Architecture</h2>
            <p className="text-xs text-slate-500">Click any layer to inspect detailed capabilities and component responsibilities</p>
          </div>
          <span className="text-xs font-medium text-slate-500">Click a layer to view details</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Layer Stack Selector */}
          <div className="lg:col-span-5 space-y-3">
            {layers.map((l) => {
              const Icon = l.icon;
              const isSelected = selectedLayer === l.layer;
              return (
                <button
                  key={l.layer}
                  onClick={() => setSelectedLayer(l.layer)}
                  className={`w-full text-left p-4 rounded-xl transition-all border ${
                    isSelected
                      ? 'bg-slate-900 text-white border-indigo-500 shadow-lg ring-2 ring-indigo-500/20'
                      : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300 hover:bg-slate-50/80'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg bg-gradient-to-br ${l.color} text-white`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider block">Layer {l.layer}</span>
                        <h3 className="font-bold text-sm">{l.title.replace(`Layer ${l.layer}: `, '')}</h3>
                      </div>
                    </div>
                    <ChevronRight className={`h-4 w-4 transition-transform ${isSelected ? 'text-indigo-400 transform rotate-90' : 'text-slate-400'}`} />
                  </div>
                </button>
              );
            })}
          </div>

          {/* Selected Layer Detail Panel */}
          <div className="lg:col-span-7">
            {(() => {
              const active = layers.find(l => l.layer === selectedLayer)!;
              const Icon = active.icon;
              return (
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 h-full flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 pb-4 border-b border-slate-100">
                      <div className={`p-3 rounded-xl bg-gradient-to-br ${active.color} text-white`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider block">Target Architecture View</span>
                        <h3 className="text-xl font-bold text-slate-900">{active.title}</h3>
                        <p className="text-xs text-slate-500">{active.subtitle}</p>
                      </div>
                    </div>

                    <p className="text-sm text-slate-700 leading-relaxed">
                      {active.description}
                    </p>

                    {/* Modules & Services */}
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">Key Sub-Systems & APIs</h4>
                      <div className="grid grid-cols-2 gap-2">
                        {active.components.map((comp, idx) => (
                          <div key={idx} className="flex items-center space-x-2 text-xs p-2.5 rounded-lg bg-slate-50 border border-slate-200/80 font-medium text-slate-800">
                            <CheckCircle2 className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                            <span>{comp}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Capabilities */}
                    <div className="space-y-2 pt-2">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">Core Functional Capabilities</h4>
                      <div className="flex flex-wrap gap-2">
                        {active.capabilities.map((cap, idx) => (
                          <span key={idx} className="px-2.5 py-1 rounded-md bg-indigo-50 text-indigo-700 text-xs font-medium border border-indigo-100">
                            {cap}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-900 text-slate-300 p-4 rounded-xl text-xs flex items-center justify-between">
                    <span>Explore live code execution for this layer:</span>
                    <button
                      onClick={() => alert(`Directing to functional module for ${active.title}...`)}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-semibold hover:bg-indigo-500 transition-colors"
                    >
                      Inspect Live APIs
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>

        </div>
      </div>

    </div>
  );
};
