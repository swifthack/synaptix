import React, { useState } from 'react';
import { UserRole, AgentChatMessage } from '../types/entityiq';
import { INITIAL_INTERNAL_ENTITIES } from '../data/mockDatabase';
import { Bot, UserCheck, Send, Sparkles, ShieldAlert, Cpu, FileText, Database, ArrowRight, RefreshCw } from 'lucide-react';

interface AgenticAISuiteProps {
  userRole: UserRole;
}

export const AgenticAISuite: React.FC<AgenticAISuiteProps> = ({ userRole }) => {
  const [selectedAgentType, setSelectedAgentType] = useState<'ORCHESTRATOR' | 'KYC' | 'RISK' | 'INVESTIGATION'>('ORCHESTRATOR');
  const [selectedEntityId, setSelectedEntityId] = useState<string>('ENT-SG-1002');
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const [messages, setMessages] = useState<AgentChatMessage[]>([
    {
      id: 'MSG-1',
      sender: 'agent',
      agentType: 'ORCHESTRATOR',
      text: 'Welcome to EntityIQ Agentic AI Suite. I am your Orchestration Agent. I coordinate specialized sub-agents (KYC, Risk, Investigation) to deliver evidence-backed decision intelligence.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      sources: ['EntityIQ Grounding Engine', 'ACRA Registry Feed', 'Knowledge Graph'],
    },
  ]);

  const agentDescriptions = {
    ORCHESTRATOR: {
      name: 'Orchestrator Agent',
      desc: 'Intent recognition, workflow planning, tool routing, conversation memory, executive summaries.',
      color: 'bg-indigo-600',
    },
    KYC: {
      name: 'KYC Agent',
      desc: 'Queries KYB Packs, corporate registry verification, ACRA feeds, director changes, periodic refresh.',
      color: 'bg-teal-600',
    },
    RISK: {
      name: 'Risk Agent',
      desc: 'Total group exposure, credit underwriting, covenant monitoring, risk scores, concentration risk.',
      color: 'bg-amber-600',
    },
    INVESTIGATION: {
      name: 'Investigation Agent',
      desc: 'Complex graph traversal, offshore corporate layers (BVI/Cayman), PEP/Sanctions hits, adverse media.',
      color: 'bg-rose-600',
    },
  };

  const samplePrompts = [
    { label: 'KYB Profile Summary', text: `Generate a full KYB Pack and director verification for entity ${selectedEntityId}`, agent: 'KYC' as const },
    { label: 'Sanctions & PEP Trace', text: `Investigate any PEP or Sanctions connections for ${selectedEntityId} and related SPVs`, agent: 'INVESTIGATION' as const },
    { label: 'Group Risk & Exposure', text: `Calculate total group credit exposure and ultimate parents for ${selectedEntityId}`, agent: 'RISK' as const },
    { label: 'What Changed Recently?', text: `What registry or UBO changes occurred since the last review for ${selectedEntityId}?`, agent: 'ORCHESTRATOR' as const },
  ];

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputMessage;
    if (!textToSend.trim() || loading) return;

    const userMsg: AgentChatMessage = {
      id: `USER-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setLoading(true);

    try {
      const response = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          agentType: selectedAgentType,
          role: userRole,
          selectedEntityId,
        }),
      });

      const data = await response.json();

      const agentMsg: AgentChatMessage = {
        id: `AGENT-${Date.now()}`,
        sender: 'agent',
        agentType: selectedAgentType,
        text: data.reply || 'Request processed by EntityIQ Foundation Engine.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sources: data.sources || ['EntityIQ Foundation Layer'],
        multiAgentGraphCall: data.multiAgentGraphCall,
      };

      setMessages(prev => [...prev, agentMsg]);
    } catch (err) {
      const errorMsg: AgentChatMessage = {
        id: `ERR-${Date.now()}`,
        sender: 'agent',
        agentType: selectedAgentType,
        text: `Unable to process request: Server error or Gemini API connectivity issue.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Bot className="h-5 w-5 text-indigo-600" />
            <h1 className="text-xl font-bold text-slate-900">Layer 1: Agentic AI Suite</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Autonomous multi-agent orchestration for specialized banking workflows powered by Gemini 3.6 Flash & GraphRAG context.
          </p>
        </div>

        {/* Target Entity Switcher */}
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold text-slate-500">Target Entity Context:</span>
          <select
            value={selectedEntityId}
            onChange={(e) => setSelectedEntityId(e.target.value)}
            className="bg-slate-100 border border-slate-300 text-slate-800 text-xs font-semibold rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
          >
            {INITIAL_INTERNAL_ENTITIES.map((ent) => (
              <option key={ent.id} value={ent.id}>
                {ent.canonicalName} ({ent.jurisdiction})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Agent Selector Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {(Object.keys(agentDescriptions) as Array<keyof typeof agentDescriptions>).map((key) => {
          const info = agentDescriptions[key];
          const isSelected = selectedAgentType === key;
          return (
            <button
              key={key}
              onClick={() => setSelectedAgentType(key)}
              className={`p-4 rounded-xl border text-left transition-all ${
                isSelected
                  ? 'bg-slate-900 text-white border-indigo-500 shadow-md ring-2 ring-indigo-500/20'
                  : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center space-x-2 mb-1.5">
                <span className={`h-2.5 w-2.5 rounded-full ${info.color}`} />
                <span className="font-bold text-sm">{info.name}</span>
              </div>
              <p className="text-[11px] opacity-75 line-clamp-2">{info.desc}</p>
            </button>
          );
        })}
      </div>

      {/* Sample Quick Action Prompts */}
      <div className="flex flex-wrap gap-2 items-center">
        <span className="text-xs font-semibold text-slate-500 flex items-center gap-1">
          <Sparkles className="h-3.5 w-3.5 text-indigo-600" /> Quick Agent Workflows:
        </span>
        {samplePrompts.map((sp, idx) => (
          <button
            key={idx}
            onClick={() => {
              setSelectedAgentType(sp.agent);
              handleSendMessage(sp.text);
            }}
            className="px-3 py-1.5 bg-white border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/50 text-slate-700 text-xs font-medium rounded-lg transition-colors shadow-2xs"
          >
            {sp.label}
          </button>
        ))}
      </div>

      {/* Chat Conversation Canvas */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-xl overflow-hidden flex flex-col h-[520px]">
        
        {/* Chat Header */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between text-white">
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-lg ${agentDescriptions[selectedAgentType].color} text-white`}>
              <Bot className="h-5 w-5" />
            </div>
            <div>
              <span className="font-bold text-sm block">{agentDescriptions[selectedAgentType].name} Active</span>
              <span className="text-xs text-slate-400">Context: {selectedEntityId} | Role: {userRole}</span>
            </div>
          </div>
          <span className="text-xs text-emerald-400 font-mono bg-emerald-950/80 border border-emerald-800 px-2.5 py-1 rounded-full">
            Gemini 3.6 Flash Active
          </span>
        </div>

        {/* Message History Container */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4 scrollbar-thin">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-3xl rounded-2xl p-4 text-xs space-y-2 leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-indigo-600 text-white rounded-br-none'
                    : 'bg-slate-800 border border-slate-700 text-slate-200 rounded-bl-none'
                }`}
              >
                {m.sender === 'agent' && (
                  <div className="flex items-center justify-between text-[10px] text-indigo-300 pb-1 border-b border-slate-700/60 font-semibold uppercase tracking-wider">
                    <span>{m.agentType || 'EntityIQ Agent'}</span>
                    <span className="text-slate-400 font-normal">{m.timestamp}</span>
                  </div>
                )}

                <div className="whitespace-pre-wrap">{m.text}</div>

                {/* Multi-Agent Graph Sub-Call Execution Panel */}
                {m.multiAgentGraphCall && (
                  <div className="mt-3 p-3 bg-slate-900 border border-indigo-500/40 rounded-xl space-y-2 text-[11px]">
                    <div className="flex items-center justify-between text-indigo-300 font-mono font-bold pb-1 border-b border-slate-800">
                      <span className="flex items-center gap-1.5">
                        <Database className="h-3.5 w-3.5 text-indigo-400" />
                        <span>Multi-Agent Call: {m.multiAgentGraphCall.callingAgent} &rarr; {m.multiAgentGraphCall.receivingAgent}</span>
                      </span>
                      <span className="text-[9px] bg-indigo-950 px-2 py-0.5 rounded text-indigo-200 border border-indigo-800">
                        {m.multiAgentGraphCall.renderDirective}
                      </span>
                    </div>

                    <div className="space-y-1">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Executed Cypher Pattern:</span>
                      <pre className="font-mono text-emerald-400 bg-slate-950 p-2 rounded text-[10px] overflow-x-auto">
                        {m.multiAgentGraphCall.cypherQuery}
                      </pre>
                    </div>

                    <div className="space-y-1 pt-1">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">
                        Exchanged Graph Data ({m.multiAgentGraphCall.subGraph.nodes.length} Nodes, {m.multiAgentGraphCall.subGraph.edges.length} Edges):
                      </span>
                      <div className="flex flex-wrap gap-1">
                        {m.multiAgentGraphCall.subGraph.nodes.map((n) => (
                          <span key={n.id} className="px-2 py-0.5 bg-slate-800 rounded font-mono text-[10px] text-slate-200 border border-slate-700">
                            {n.label} ({n.type})
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {m.sources && m.sources.length > 0 && (
                  <div className="pt-2 border-t border-slate-700/60 text-[10px] text-slate-400 space-y-0.5">
                    <span className="font-bold text-indigo-300 block">Context Citations:</span>
                    {m.sources.map((s, i) => (
                      <span key={i} className="inline-block mr-2 px-1.5 py-0.5 bg-slate-900 rounded border border-slate-700 font-mono">
                        {s}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start">
              <div className="bg-slate-800 border border-slate-700 text-slate-300 p-4 rounded-2xl text-xs flex items-center space-x-3">
                <RefreshCw className="h-4 w-4 animate-spin text-indigo-400" />
                <span>EntityIQ Agent is processing knowledge graph and running reasoning checks...</span>
              </div>
            </div>
          )}
        </div>

        {/* Chat Input Bar */}
        <div className="p-4 bg-slate-950 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder={`Ask the ${agentDescriptions[selectedAgentType].name} about corporate structure, KYB, sanctions, or risks...`}
              className="flex-1 bg-slate-900 border border-slate-700 text-white placeholder-slate-500 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              type="submit"
              disabled={loading || !inputMessage.trim()}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs flex items-center space-x-2 transition-colors"
            >
              <Send className="h-4 w-4" />
              <span>Send</span>
            </button>
          </form>
        </div>

      </div>

    </div>
  );
};
