import React, { useState } from 'react';
import { INITIAL_GRAPH_NODES, INITIAL_GRAPH_EDGES, INITIAL_COMMUNITY_SUMMARIES } from '../data/mockDatabase';
import { performGraphRAGHybridSearch } from '../services/knowledgeGraph';
import { Database, Network, Search, ShieldAlert, Users, Layers, ExternalLink, Zap } from 'lucide-react';

export const KnowledgeGraphView: React.FC = () => {
  const [selectedCommunityId, setSelectedCommunityId] = useState<string>('COMM-VERTEX-GRP');
  const [ragQuery, setRagQuery] = useState<string>('Find offshore entities connected to Viktor Ivanov or Sanctions');
  const [ragResult, setRagResult] = useState<any>(() => performGraphRAGHybridSearch('offshore'));

  const handleRagSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const res = performGraphRAGHybridSearch(ragQuery);
    setRagResult(res);
  };

  const activeCommunity = INITIAL_COMMUNITY_SUMMARIES.find(c => c.communityId === selectedCommunityId) || INITIAL_COMMUNITY_SUMMARIES[0];
  const communityNodes = INITIAL_GRAPH_NODES.filter(n => n.communityId === selectedCommunityId);
  const communityNodeIds = new Set(communityNodes.map(n => n.id));
  const communityEdges = INITIAL_GRAPH_EDGES.filter(e => communityNodeIds.has(e.source) || communityNodeIds.has(e.target));

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Database className="h-5 w-5 text-indigo-600" />
            <h1 className="text-xl font-bold text-slate-900">Knowledge Graph & GraphRAG Layer</h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Relationship intelligence, Leiden community detection, corporate group structure mapping, and hybrid GraphRAG retrieval fusion.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold text-slate-500">Active Group Clusters:</span>
          {INITIAL_COMMUNITY_SUMMARIES.map((c) => (
            <button
              key={c.communityId}
              onClick={() => setSelectedCommunityId(c.communityId)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                selectedCommunityId === c.communityId
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {c.name.split(' ')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* GraphRAG Hybrid Retrieval Search Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 rounded-2xl border border-slate-800 text-white shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Zap className="h-5 w-5 text-indigo-400" />
            <h2 className="text-sm font-bold uppercase tracking-wider text-indigo-200">GraphRAG Hybrid Retrieval Engine</h2>
          </div>
          <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
            Vector + Graph + Keyword + Community
          </span>
        </div>

        <form onSubmit={handleRagSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={ragQuery}
              onChange={(e) => setRagQuery(e.target.value)}
              placeholder="Search across corporate entities, directors, sanctions, or jurisdictions..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs transition-colors"
          >
            Query GraphRAG
          </button>
        </form>

        {ragResult && (
          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700 text-xs space-y-3">
            <div className="flex items-center justify-between text-slate-300">
              <span>Query: "{ragResult.query}"</span>
              <span className="text-emerald-400 font-bold">Retrieval Fusion Score: {(ragResult.retrievalScore * 100).toFixed(0)}%</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-700">
              <div>
                <span className="text-slate-400 font-bold block mb-1">Matched Nodes ({ragResult.nodesFound.length}):</span>
                <div className="space-y-1">
                  {ragResult.nodesFound.map((n: any) => (
                    <div key={n.id} className="p-2 bg-slate-900 rounded border border-slate-700/60 flex items-center justify-between">
                      <span className="font-medium text-white">{n.label}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-900/60 text-indigo-300">{n.type}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-slate-400 font-bold block mb-1">Leiden Community Clusters ({ragResult.communitiesFound.length}):</span>
                <div className="space-y-1">
                  {ragResult.communitiesFound.map((c: any) => (
                    <div key={c.communityId} className="p-2 bg-slate-900 rounded border border-slate-700/60">
                      <span className="font-medium text-indigo-300">{c.name}</span>
                      <p className="text-[11px] text-slate-300 line-clamp-2 mt-0.5">{c.summary}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Community Summary Card */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider block">Leiden Community Cluster</span>
                <h2 className="text-lg font-bold text-slate-900">{activeCommunity.name}</h2>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                activeCommunity.riskLevel === 'HIGH' ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
              }`}>
                {activeCommunity.riskLevel} RISK
              </span>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-200/60">
              {activeCommunity.summary}
            </p>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/60">
                <span className="text-slate-500 block text-[10px] uppercase font-semibold">Ultimate Parent</span>
                <span className="font-bold text-slate-900 block mt-0.5">{activeCommunity.ultimateParent}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/60">
                <span className="text-slate-500 block text-[10px] uppercase font-semibold">Total Group Exposure</span>
                <span className="font-bold text-indigo-700 block mt-0.5">${(activeCommunity.totalGroupExposureUsd / 1000000).toFixed(1)}M USD</span>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">Cluster Members ({communityNodes.length})</h3>
              <div className="space-y-2">
                {communityNodes.map((n) => (
                  <div key={n.id} className="p-3 rounded-xl border border-slate-200 bg-white flex items-center justify-between text-xs">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-slate-900">{n.label}</span>
                        {n.sanctionHit && (
                          <span className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 font-bold text-[10px]">
                            SANCTION
                          </span>
                        )}
                        {n.pepHit && (
                          <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-bold text-[10px]">
                            PEP
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-500">Jurisdiction: {n.jurisdiction}</span>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                      {n.type}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Visual Relationship Graph View */}
        <div className="lg:col-span-7">
          <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <Network className="h-5 w-5 text-indigo-400" />
                <h3 className="text-sm font-bold uppercase tracking-wider text-indigo-300">
                  Knowledge Graph Canvas & Relationships
                </h3>
              </div>
              <span className="text-xs text-slate-400">Nodes: {communityNodes.length} | Edges: {communityEdges.length}</span>
            </div>

            {/* Interactive Graph Node List Representation */}
            <div className="space-y-4">
              <span className="text-xs font-semibold text-slate-400 block">Active Edges & Relationship Links:</span>

              <div className="space-y-3">
                {communityEdges.map((e) => {
                  const sourceNode = INITIAL_GRAPH_NODES.find(n => n.id === e.source);
                  const targetNode = INITIAL_GRAPH_NODES.find(n => n.id === e.target);
                  return (
                    <div key={e.id} className="p-3 bg-slate-800/90 rounded-xl border border-slate-700/80 flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-3">
                        <div className="bg-indigo-900/60 p-2 rounded-lg text-indigo-300 border border-indigo-700/50">
                          <Users className="h-4 w-4" />
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-bold text-white">{sourceNode?.label}</span>
                            <span className="text-indigo-400 font-mono font-bold">
                              → [{e.type} {e.ownershipPercentage ? `(${e.ownershipPercentage}%)` : ''}] →
                            </span>
                            <span className="font-bold text-emerald-300">{targetNode?.label}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 mt-0.5 block">
                            Source Attribution: {e.sourceRef} (Confidence: {(e.confidence * 100).toFixed(0)}%)
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
