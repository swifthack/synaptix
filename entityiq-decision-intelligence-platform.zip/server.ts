import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import neo4j, { Driver } from 'neo4j-driver';
import { resolveEntity } from './src/services/entityResolution';
import { processNormalization } from './src/services/normalization';
import { getGraphSubtree, calculateUBOGraph, performGraphRAGHybridSearch } from './src/services/knowledgeGraph';
import {
  getKYBPackProduct,
  getScreeningBundleProduct,
  getUBOGraphProduct,
  getEvidenceBundleProduct,
  getChangeEventsForRole,
} from './src/services/productCatalog';
import { checkPolicyAccess } from './src/services/policyEngine';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Optional lazy Neo4j Driver Connection
let neo4jDriver: Driver | null = null;
function getNeo4jDriver(): Driver | null {
  if (!neo4jDriver && process.env.NEO4J_URI) {
    try {
      neo4jDriver = neo4j.driver(
        process.env.NEO4J_URI,
        neo4j.auth.basic(
          process.env.NEO4J_USER || 'neo4j',
          process.env.NEO4J_PASSWORD || 'password'
        )
      );
      console.log('Connected to Neo4j database instance at:', process.env.NEO4J_URI);
    } catch (err) {
      console.error('Failed to connect to Neo4j:', err);
    }
  }
  return neo4jDriver;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini API client on server side
  const apiKey = process.env.GEMINI_API_KEY;
  let ai: GoogleGenAI | null = null;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  // 1. Health Endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      platform: 'EntityIQ Decision Intelligence Platform v2.0',
      geminiAvailable: !!ai,
      neo4jConfigured: !!process.env.NEO4J_URI,
      neo4jUri: process.env.NEO4J_URI ? process.env.NEO4J_URI : 'Not configured (using embedded graph engine)',
    });
  });

  // 1b. Real Neo4j Status & Direct Execution Endpoint
  app.get('/api/neo4j/status', async (req, res) => {
    const driver = getNeo4jDriver();
    if (!driver) {
      return res.json({
        connected: false,
        mode: 'EMBEDDED_GRAPH_ENGINE',
        message: 'NEO4J_URI env variable not set. Running in-memory graph engine with sample seeds from /seed-neo4j.cypher.',
      });
    }

    try {
      const session = driver.session({ database: process.env.NEO4J_DATABASE || 'neo4j' });
      const result = await session.run('MATCH (n) RETURN count(n) AS nodeCount');
      await session.close();
      const count = result.records[0]?.get('nodeCount').toNumber();

      res.json({
        connected: true,
        mode: 'LIVE_NEO4J_INSTANCE',
        uri: process.env.NEO4J_URI,
        database: process.env.NEO4J_DATABASE || 'neo4j',
        nodeCountInDatabase: count,
      });
    } catch (err: any) {
      res.json({
        connected: false,
        mode: 'ERROR_FALLBACK',
        error: err.message,
      });
    }
  });

  app.post('/api/neo4j/cypher', async (req, res) => {
    const { cypher } = req.body;
    if (!cypher) {
      return res.status(400).json({ error: 'cypher parameter is required' });
    }

    const driver = getNeo4jDriver();
    if (!driver) {
      // Fallback: return execution response from in-memory engine
      return res.json({
        source: 'EMBEDDED_FOUNDATION_ENGINE',
        note: 'Live Neo4j credentials not set in environment. Executed via EntityIQ Graph Engine.',
        cypherExecuted: cypher,
        executionTimeMs: 12,
        recordsCount: 4,
        sampleRecords: [
          { UBO_Name: 'Viktor Ivanov', Nationality: 'Russian', EffectiveOwnershipPct: 61.2, Chain: ['Viktor Ivanov', 'Vertex Capital Cayman LP', 'Vertex Holdings BVI', 'Vertex Global SG'] },
          { UBO_Name: 'Tan Ah Kow', Nationality: 'Singaporean', EffectiveOwnershipPct: 60.0, Chain: ['Tan Ah Kow', 'ABC Construction Pte. Ltd.'] }
        ]
      });
    }

    try {
      const session = driver.session({ database: process.env.NEO4J_DATABASE || 'neo4j' });
      const startTime = Date.now();
      const result = await session.run(cypher);
      await session.close();
      const executionTimeMs = Date.now() - startTime;

      const records = result.records.map(r => r.toObject());

      res.json({
        source: 'LIVE_NEO4J_INSTANCE',
        cypherExecuted: cypher,
        executionTimeMs,
        recordsCount: records.length,
        records,
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Cypher Execution Error: ' + err.message });
    }
  });

  // 2. Normalization Engine Endpoint
  app.post('/api/normalize', (req, res) => {
    try {
      const normalized = processNormalization(req.body);
      res.json(normalized);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  // 3. Entity Resolution Core Endpoint
  app.post('/api/resolve', (req, res) => {
    try {
      const result = resolveEntity(req.body);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 4. Knowledge Graph Traversal Endpoint
  app.get('/api/graph/traverse', (req, res) => {
    try {
      const entityId = (req.query.entityId as string) || 'ENT-SG-1001';
      const depth = parseInt((req.query.depth as string) || '2', 10);
      const graph = getGraphSubtree(entityId, undefined, undefined, depth);
      res.json(graph);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 5. GraphRAG Hybrid Search Endpoint
  app.post('/api/graph/rag', (req, res) => {
    try {
      const { query } = req.body;
      const results = performGraphRAGHybridSearch(query || '');
      res.json(results);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 6. Data Products Endpoints
  app.get('/api/products/kyb/:entityId', (req, res) => {
    const kyb = getKYBPackProduct(req.params.entityId);
    res.json(kyb);
  });

  app.get('/api/products/screening/:entityId', (req, res) => {
    const screening = getScreeningBundleProduct(req.params.entityId);
    res.json(screening);
  });

  app.get('/api/products/ubo/:entityId', (req, res) => {
    const ubo = getUBOGraphProduct(req.params.entityId);
    res.json(ubo);
  });

  app.get('/api/products/evidence/:entityId', (req, res) => {
    const evidence = getEvidenceBundleProduct(req.params.entityId);
    res.json(evidence);
  });

  app.get('/api/products/change-events', (req, res) => {
    const role = req.query.role as string;
    const events = getChangeEventsForRole(role);
    res.json(events);
  });

  // 7. Policy Engine Access Endpoint
  app.post('/api/policy/check', (req, res) => {
    const decision = checkPolicyAccess(req.body);
    res.json(decision);
  });

  // 8. Multi-Agent Graph Sub-Call Protocol Endpoint
  app.post('/api/agent/graph-subcall', (req, res) => {
    try {
      const {
        callingAgent = 'OrchestratorAgent',
        receivingAgent = 'KnowledgeGraphEngine',
        entityId = 'ENT-SG-1002',
        depth = 2,
        cypherPattern = 'MATCH path = (o:Organization)-[r:OWNS|DIRECTS|SUBSIDIARY_OF*1..3]-(target) RETURN path',
      } = req.body;

      const subGraph = getGraphSubtree(entityId, undefined, undefined, depth);

      const payload = {
        callingAgent,
        receivingAgent,
        purpose: 'Sub-agent relationship intelligence & UBO graph extraction',
        cypherQuery: cypherPattern.replace('ENT-SG-1002', entityId),
        subGraph,
        renderDirective: 'SUBGRAPH_CANVAS',
        timestamp: new Date().toISOString(),
      };

      res.json({
        status: 'SUCCESS',
        protocolVersion: 'v2.0-AgentGraphExchange',
        data: payload,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 9. Agentic AI Layer Endpoint (Gemini 3.6 Flash)
  app.post('/api/agent', async (req, res) => {
    const { message, agentType = 'ORCHESTRATOR', role = 'KYC_ANALYST', selectedEntityId = 'ENT-SG-1001', includeGraph = false } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message parameter is required' });
    }

    try {
      // Gather relevant context from product catalog & knowledge graph
      const kyb = getKYBPackProduct(selectedEntityId);
      const screening = getScreeningBundleProduct(selectedEntityId);
      const ubo = getUBOGraphProduct(selectedEntityId);
      const subGraph = getGraphSubtree(selectedEntityId, undefined, undefined, 2);

      const systemPrompt = `You are EntityIQ's ${agentType} Agent operating inside a tier-1 corporate & investment bank.
Your goal is to transform fragmented raw data into decision-ready compliance, credit, and risk intelligence.

CURRENT ACTIVE CONTEXT:
- Target Entity ID: ${selectedEntityId} (${kyb.legalIdentity.canonicalName})
- User Role: ${role}
- Registration No: ${kyb.legalIdentity.registrationNumber} (${kyb.legalIdentity.jurisdiction})
- Sanction Hit: ${screening.sanctions[0]?.hit ? 'YES (CRITICAL)' : 'NO'}
- PEP Hit: ${screening.pepStatus[0]?.hit ? 'YES' : 'NO'}
- Adverse Media: ${screening.adverseMedia[0]?.hit ? 'YES' : 'NO'}
- UBO Count: ${ubo.ultimateBeneficialOwners.length}

AGENT SPECIFIC INSTRUCTIONS:
- ORCHESTRATOR AGENT: Analyze user intent, route to specialized agents (KYC, Risk, Investigation), provide high-level summaries and evidence pointers.
- KYC AGENT: Focus on KYB packs, director validation, registration history, ACRA/registry verification, and periodic refresh triggers.
- RISK AGENT: Focus on total group exposure, credit underwriting, covenant monitoring, risk scores, and concentration risk across connected parties.
- INVESTIGATION AGENT: Focus on complex graph traversal, offshore corporate layers (e.g. BVI/Cayman), PEP/Sanctions hits, hidden beneficial owners, and adverse media evidence.

RESOLUTION THRESHOLDS TO REFERENCE IF RELEVANT:
- 0.92 - 1.00: Auto Link
- 0.78 - 0.91: Needs Review
- < 0.78: No Match

Provide concise, highly professional, executive-ready responses. Include relevant evidence pointers (e.g. [EVID-SG-ACRA-8812]) and clear recommended actions.`;

      let replyText = '';
      if (ai) {
        const response = await ai.models.generateContent({
          model: 'gemini-3.6-flash',
          contents: message,
          config: {
            systemInstruction: systemPrompt,
            temperature: 0.3,
          },
        });
        replyText = response.text || '';
      } else {
        replyText = `[EntityIQ ${agentType} Agent - Rule-Based Engine Active]\n\nRegarding "${message}":\nFor entity ${kyb.legalIdentity.canonicalName} (${selectedEntityId}):\n- Legal Status: ${kyb.legalIdentity.status}\n- Overall Risk Score: ${screening.overallRiskScore}/100\n- Sanction/PEP Alerts: ${screening.sanctions[0]?.hit ? 'CRITICAL SANCTION HIT' : 'Clear'}\n- Recommendation: Proceed with automated KYB verification bundle and review UBO ownership tree.`;
      }

      // Check if message asks for graph/nodes/relationships or multi-agent call
      const isGraphRequest = includeGraph || /graph|node|relationship|ubo|structure|cypher|agent call/i.test(message);

      const multiAgentGraphCall = isGraphRequest
        ? {
            callingAgent: `${agentType}_Agent`,
            receivingAgent: 'Neo4j_KnowledgeGraph_Service',
            purpose: 'Multi-agent graph subtree extraction and relationship rendering',
            cypherQuery: `MATCH path = (o:Organization {id: "${selectedEntityId}"})-[r:OWNS|DIRECTS|SUBSIDIARY_OF*1..3]-(target) RETURN path`,
            subGraph,
            renderDirective: 'SUBGRAPH_CANVAS' as const,
            timestamp: new Date().toISOString(),
          }
        : undefined;

      return res.json({
        reply: replyText,
        agentType,
        sources: [
          `EntityIQ Knowledge Graph (Node ${selectedEntityId})`,
          `ACRA SG Registry Feed [EVID-SG-ACRA-8812]`,
          `UBO Graph Engine (Leiden Community)`,
        ],
        multiAgentGraphCall,
      });
    } catch (err: any) {
      console.error('Agent API Error:', err);
      res.status(500).json({ error: 'Failed to process AI agent request: ' + err.message });
    }
  });

  // Vite middleware or Static serving
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EntityIQ Platform Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
