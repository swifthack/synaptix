// ============================================================================
// EntityIQ Decision Intelligence Platform - Neo4j Production Seed Script
// Execute this script in Neo4j Browser, Neo4j Desktop, or Cypher-Shell
// ============================================================================

// 1. CREATE UNIQUE CONSTRAINTS & INDEXES
CREATE CONSTRAINT org_id_unique IF NOT EXISTS FOR (o:Organization) REQUIRE o.id IS UNIQUE;
CREATE CONSTRAINT person_id_unique IF NOT EXISTS FOR (p:Person) REQUIRE p.id IS UNIQUE;
CREATE CONSTRAINT sanction_id_unique IF NOT EXISTS FOR (s:SanctionList) REQUIRE s.id IS UNIQUE;

CREATE INDEX org_name_idx IF NOT EXISTS FOR (o:Organization) ON (o.canonicalName);
CREATE INDEX org_reg_idx IF NOT EXISTS FOR (o:Organization) ON (o.registrationNumber);

// 2. CLEAR EXISTING SAMPLE DATA (OPTIONAL)
// MATCH (n) DETACH DELETE n;

// 3. CREATE ORGANIZATION NODES
CREATE (abc:Organization {
  id: "ENT-SG-1001",
  canonicalName: "ABC Construction Pte. Ltd.",
  registrationNumber: "201812345E",
  lei: "5493001KJ95729X4301",
  jurisdiction: "Singapore",
  status: "ACTIVE",
  address: "10 Marina Boulevard #18-01, MBFC, Singapore",
  communityId: "COMM-ABC-CONST",
  creditExposureUsd: 12500000.0,
  sanctionHit: false
});

CREATE (vertex_sg:Organization {
  id: "ENT-SG-1002",
  canonicalName: "Vertex Global Group (Singapore)",
  registrationNumber: "201598765K",
  jurisdiction: "Singapore",
  status: "ACTIVE",
  address: "1 Raffles Place #25-01, Singapore",
  communityId: "COMM-VERTEX-GRP",
  creditExposureUsd: 48500000.0,
  sanctionHit: false
});

CREATE (vertex_bvi:Organization {
  id: "ENT-BVI-3001",
  canonicalName: "Vertex Holdings (BVI) Ltd",
  registrationNumber: "BVI-998812",
  jurisdiction: "British Virgin Islands",
  status: "ACTIVE",
  address: "P.O. Box 957, Offshore Incorporations Centre, Road Town, Tortola",
  communityId: "COMM-VERTEX-GRP",
  creditExposureUsd: 22000000.0,
  sanctionHit: true
});

CREATE (vertex_cayman:Organization {
  id: "ENT-CYM-4002",
  canonicalName: "Vertex Capital Offshore Investments LP",
  registrationNumber: "CYM-112233",
  jurisdiction: "Cayman Islands",
  status: "ACTIVE",
  address: "Ugland House, Grand Cayman KY1-1104",
  communityId: "COMM-VERTEX-GRP",
  creditExposureUsd: 18000000.0,
  sanctionHit: false
});

CREATE (aetheria:Organization {
  id: "ENT-SG-1003",
  canonicalName: "Aetheria Cloud Technologies Pte Ltd",
  registrationNumber: "202699881M",
  jurisdiction: "Singapore",
  status: "ACTIVE",
  address: "71 Ayer Rajah Crescent #02-12, Singapore",
  communityId: "COMM-AETHERIA",
  creditExposureUsd: 3500000.0,
  sanctionHit: false
});

// 4. CREATE PERSON NODES
CREATE (tan:Person {
  id: "PER-SG-001",
  name: "Tan Ah Kow",
  nationality: "Singaporean",
  pepHit: false,
  isUltimateParent: false
});

CREATE (smith:Person {
  id: "PER-UK-002",
  name: "John Richard Smith",
  nationality: "British",
  pepHit: false,
  isUltimateParent: false
});

CREATE (chen:Person {
  id: "PER-SG-003",
  name: "Chen Wei",
  nationality: "Singaporean",
  pepHit: false,
  isUltimateParent: false
});

CREATE (ivanov:Person {
  id: "PER-RU-8812",
  name: "Viktor Ivanov",
  nationality: "Russian",
  pepHit: true,
  isUltimateParent: true
});

// 5. CREATE SANCTION WATCHLIST NODES
CREATE (ofac_list:SanctionList {
  id: "SANC-OFAC-001",
  matchedName: "Viktor Ivanov",
  listName: "OFAC SDN List (Specially Designated Nationals)",
  authority: "US Treasury OFAC",
  dateListed: "2024-03-15"
});

// 6. CREATE RELATIONSHIPS
// ABC Construction Relationships
CREATE (tan)-[:DIRECTS {role: "Managing Director", appointmentDate: "2018-05-10", sourceRef: "ACRA-SG"}]->(abc);
CREATE (smith)-[:DIRECTS {role: "Director", appointmentDate: "2020-11-01", sourceRef: "ACRA-SG"}]->(abc);
CREATE (tan)-[:OWNS {ownershipPercentage: 60.0, startDate: "2018-05-10", sourceRef: "ACRA-SG", confidence: 1.0}]->(abc);
CREATE (smith)-[:OWNS {ownershipPercentage: 40.0, startDate: "2020-11-01", sourceRef: "ACRA-SG", confidence: 1.0}]->(abc);

// Vertex Group Hierarchy & Offshore Web
CREATE (chen)-[:DIRECTS {role: "Executive Director", appointmentDate: "2015-08-12", sourceRef: "ACRA-SG"}]->(vertex_sg);
CREATE (vertex_bvi)-[:SUBSIDIARY_OF {controlPct: 100.0, jurisdiction: "BVI", ACRAVerified: true}]->(vertex_sg);
CREATE (vertex_bvi)-[:OWNS {ownershipPercentage: 100.0, startDate: "2016-01-15", sourceRef: "BVI Registry", confidence: 0.95}]->(vertex_sg);

CREATE (vertex_cayman)-[:OWNS {ownershipPercentage: 85.0, startDate: "2016-03-20", sourceRef: "Cayman CIMA", confidence: 0.90}]->(vertex_bvi);
CREATE (ivanov)-[:OWNS {ownershipPercentage: 72.0, startDate: "2017-09-01", sourceRef: "Panama Papers / Offshore Leaks", confidence: 0.88}]->(vertex_cayman);
CREATE (ivanov)-[:BENEFICIAL_OWNER {effectiveOwnershipPct: 61.2, calculatedVia: "GraphTraversal", auditId: "EVID-UBO-9921"}]->(vertex_sg);

// Sanctions Connection
CREATE (ivanov)-[:SANCTIONED_BY {riskLevel: "CRITICAL", matchConfidence: 0.98}]->(ofac_list);

// ============================================================================
// VERIFICATION CYPHER QUERY:
// MATCH path = (p:Person)-[*1..4]-(o:Organization) RETURN path LIMIT 25;
// ============================================================================
